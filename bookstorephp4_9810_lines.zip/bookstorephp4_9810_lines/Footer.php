<?

//********************************************************************************


function Footer_Show()
{
global $styles;




?>
  <table style="">
  
  <tr>
  
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Default.php"><font style="font-size: 10pt; color: #000000">Home</font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Registration.php"><font style="font-size: 10pt; color: #000000">Registration</font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="ShoppingCart.php"><font style="font-size: 10pt; color: #000000">Shopping Cart</font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Login.php"><font style="font-size: 10pt; color: #000000">Sign In</font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="AdminMenu.php"><font style="font-size: 10pt; color: #000000">Administration</font></a></td>
  </tr>
  </table>
<?

}

?>