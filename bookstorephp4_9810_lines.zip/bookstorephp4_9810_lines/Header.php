<?

//********************************************************************************


function Menu_Show()
{
global $styles;




?>
  <table style="">
  
  <tr>
  
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Default.php"><font style="font-size: 10pt; color: #000000"><img src="images/Logo_bookstore.gif" border="0"></font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Default.php"><font style="font-size: 10pt; color: #000000"><img src="images/icon_home.gif" border="0"></font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Registration.php"><font style="font-size: 10pt; color: #000000"><img src="images/icon_reg.gif" border="0"></font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="ShoppingCart.php"><font style="font-size: 10pt; color: #000000"><img src="images/icon_shop.gif" border="0"></font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="Login.php"><font style="font-size: 10pt; color: #000000"><img src="images/icon_sign.gif" border="0"></font></a></td>
    <td style="background-color: #FFFFFF; border-width: 1"><a href="AdminMenu.php"><font style="font-size: 10pt; color: #000000"><img src="images/icon_admin.gif" border="0"></font></a></td>
  </tr>
  </table>
<?

}

?>