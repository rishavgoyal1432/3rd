<?php
$eva['inserir'][] ="

--
-- Extraindo dados da tabela `{bdprefixo}_eva_bloco`
--
TRUNCATE `{bdprefixo}_eva_bloco`;
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (18, 5, 'c', 'a', 'Parab�ns!', 1, 5, 's:646:\"&lt;font size=&quot;2&quot; style=&quot;font-weight: bold; color: #ff0000&quot;&gt; Parab&amp;eacute;ns&lt;/font&gt;&lt;br /&gt;&lt;br /&gt;Voc&amp;ecirc; acaba de instalar o EVA cms com sucesso! Agora que possui uma vers&amp;atilde;o do EVA instalado, n&amp;atilde;o deixe de conferir as atualiza&amp;ccedil;&amp;otilde;es no site www.evacms.com.br.&lt;br /&gt;&lt;br /&gt;Contribua desenvolvendo m&amp;oacute;dulos! Tenha em seu curr&amp;uacute;culo a autoria de c&amp;oacute;digos utilizados a n&amp;iacute;vel nacional enviando suas sugest&amp;otilde;es para os m&amp;oacute;dulos j&amp;aacute; desenvolvidos ou criando novas funcionalidades.\";', 'html', 'bloco_centro.htm', '2', 'v', 1, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (0, 5, 'c', 'a', 'Modulo', 0, 0, '', '', 'vazio', '', 't', 0, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (11, 5, 'r', 'a', 'Rodap�', 0, 15, 's:19:\"CopyLeft - GNU LGPL\";', 'texto', 'bloco_rodape.htm', '1;2;3;4;5;6;7;8', 't', 0, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (12, 5, 't', 'a', 'Topo', 0, 16, 's:120:\"ZWNobyAmcXVvdDsmbHQ7YSBocmVmPVwnaW5kZXgucGhwXCcmZ3Q7JnF1b3Q7LiRjb25maWdbXCd0aXR1bG9cJ10uJnF1b3Q7Jmx0Oy9hJmd0OyZxdW90Ozs=\";', 'php', 'bloco_topo.htm', '1;2;3;4;5;6;7;8', 't', 0, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (13, 4, 'e', 'a', 'Login', 1, 17, 'a:13:{i:0;s:0:\"\";i:1;s:1:\"s\";i:2;s:1:\"n\";i:3;s:1:\"s\";i:4;s:1:\"s\";i:5;s:3:\"Ol�\";i:6;s:0:\"\";i:7;s:2:\"10\";i:8;s:0:\"\";i:9;s:1:\"v\";i:10;s:1:\"s\";i:11;s:5:\"login\";i:12;s:6:\"Nenhum\";}', 'login', 'bloco_centro.htm', '1;2;3;4;5;6;7;8', 't', 1, 0, 150, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (14, 6, 't', 'a', 'Menu', 0, 18, 'a:4:{s:4:\"menu\";s:1:\"1\";s:4:\"tipo\";s:4:\"menu\";s:7:\"sentido\";s:10:\"horizontal\";s:6:\"estilo\";s:0:\"\";}', 'menu', 'bloco_menu.htm', '1;2;3;4;5;6;7;8', 't', 0, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (15, 8, 'c', 'a', 'Conteudo', 1, 19, 'a:12:{s:4:\"tipo\";s:5:\"banco\";s:5:\"secao\";a:1:{i:0;s:1:\"0\";}s:9:\"num_itens\";s:1:\"3\";s:17:\"texto_veja_tambem\";s:12:\"TGVpYSBNYWlz\";s:11:\"num_colunas\";s:1:\"1\";s:17:\"tamanho_descricao\";s:0:\"\";s:15:\"utilizar_modelo\";s:0:\"\";s:11:\"ordenar_por\";s:23:\"co_data_publicacao desc\";s:12:\"formato_data\";s:0:\"\";s:14:\"separador_data\";s:0:\"\";s:14:\"destacar_bloco\";s:1:\"n\";s:20:\"exibir_mais_noticias\";s:0:\"\";}', 'lista_conteudo', 'bloco_centro.htm', '2', 't', 1, 0, 0, '');
INSERT INTO `{bdprefixo}_eva_bloco` VALUES (16, 1, 'e', 'a', 'M�dulos', 1, 20, 'a:0:{}', 'listamodulos', 'bloco_centro.htm', '1;2;3;4;5;6;7;8', '', 1, 0, 150, '');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_bloco_grupo`
--
TRUNCATE `{bdprefixo}_eva_bloco_grupo`;
INSERT INTO `{bdprefixo}_eva_bloco_grupo` VALUES (4, 4, 1);
INSERT INTO `{bdprefixo}_eva_bloco_grupo` VALUES (6, 7, 1);
INSERT INTO `{bdprefixo}_eva_bloco_grupo` VALUES (7, 16, 1);


--
-- Extraindo dados da tabela `{bdprefixo}_eva_conteudo`
--
TRUNCATE `{bdprefixo}_eva_conteudo`;
INSERT INTO `{bdprefixo}_eva_conteudo` VALUES (1, 3, 'ZEND PHP Certified Engineer', '&lt;img vspace=&quot;3&quot; hspace=&quot;5&quot; border=&quot;0&quot; align=&quot;left&quot; alt=&quot;zend_60px.PNG&quot; src=&quot;imagens/logos/php_med_trans.png&quot; /&gt;O EVA cms foi criado pelos primeiros profissionais da Am&amp;eacute;rica Latina a conquistarem a certifica&amp;ccedil;&amp;atilde;o &amp;quot;ZEND PHP Certified Engineer&amp;quot;  &lt;span style=&quot;visibility: visible&quot; class=&quot;camada_bloco&quot;&gt; Os membros que comp&amp;otilde;em a equipe EVA cms, &lt;a title=&quot;http:zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&quot; target=&quot;_blank&quot; href=&quot;http:zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&quot;&gt;Alessandro do Valle Nunes&lt;/a&gt; e &lt;a title=&quot;http:zend.comzce.php?c=ZEND001318&amp;amp;r=209210010&quot; target=&quot;_blank&quot; href=&quot;http:zend.comzce.php?c=ZEND001318&amp;amp;r=209210010&quot;&gt;Daniel de Oliveira Santos&lt;/a&gt;&lt;a&gt;, foram os primeiros profissionais da Am&amp;eacute;rica Latina a receberem o certificado PHP &amp;quot;Zend Certified Enginee&amp;quot; a certifica&amp;ccedil;&amp;atilde;o oficial da linguagem de programa&amp;ccedil;&amp;atilde;o mais utilizada na Internet.&lt;br /&gt; &lt;/a&gt;&lt;/span&gt;', '&lt;span class=&quot;camada_bloco&quot; style=&quot;visibility: visible&quot;&gt; Os membros que comp&amp;otilde;em a equipe EVA cms, &lt;a href=&quot;http://zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&quot;&gt;Alessandro do Valle Nunes&lt;/a&gt; e &lt;a href=&quot;http://zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&quot;&gt;Daniel de Oliveira Santos&lt;/a&gt;, foram os primeiros profissionais da Am&amp;eacute;rica Latina a receberem o certificado PHP &amp;quot;Zend Certified Enginee&amp;quot; a certifica&amp;ccedil;&amp;atilde;o oficial da linguagem de programa&amp;ccedil;&amp;atilde;o mais utilizada na Internet.&lt;br /&gt; &lt;br /&gt; &lt;img width=&quot;60&quot; vspace=&quot;3&quot; hspace=&quot;5&quot; height=&quot;38&quot; border=&quot;0&quot; align=&quot;left&quot; alt=&quot;zend_60px.PNG&quot; src=&quot;imagens/logos/zend_60px.png&quot; /&gt;Daniel de Oliveira Santos Neto &lt;br /&gt; Zend PHP Certification - Authentication&lt;br /&gt; &lt;a href=&quot;http://zend.comzce.php?c=ZEND001318&amp;amp;r=209210010&quot;&gt;http://zend.comzce.php?c=ZEND001318&amp;amp;r=209210010&lt;/a&gt; &lt;br /&gt; &lt;br /&gt; &lt;img width=&quot;60&quot; vspace=&quot;3&quot; hspace=&quot;5&quot; height=&quot;38&quot; border=&quot;0&quot; align=&quot;left&quot; alt=&quot;zend_60px.PNG&quot; src=&quot;imagens/logos/zend_60px.png&quot; /&gt; Alessandro do Valle Nunes &lt;br /&gt; Zend PHP Certification - Authentication&lt;br /&gt; &lt;a href=&quot;http://zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&quot;&gt;http://zend.comzce.php?c=ZEND001289&amp;amp;r=210256171&lt;/a&gt;&lt;br /&gt; &lt;/span&gt;', '', '', NULL, 1108387980, 1156280399, 0, '', NULL, NULL);
INSERT INTO `{bdprefixo}_eva_conteudo` VALUES (2, 3, 'Um projeto nacional, 100% Software Livre!', '&lt;img vspace=&quot;5&quot; hspace=&quot;5&quot; border=&quot;0&quot; align=&quot;left&quot; alt=&quot;folder.png&quot; src=&quot;imagens/logos/eva_64x64.png&quot; /&gt;Conhe&amp;ccedil;a o EVA, uma plataforma de desenvolvimento de sistemas escrita em PHP, totalmente em portugu&amp;ecirc;s. Textos, imagens, downloads, f&amp;oacute;rum, bate-papo e muito mais nesta ferramenta desenvolvida por membros da comunidade brasileira de software livre.&lt;br /&gt;EVA cms &amp;eacute; um programa de c&amp;oacute;digo aberto distribuido sob os termos da GNU General Public Licence.', '&lt;p style=&quot;text-align: justify&quot;&gt;Precisa gerenciar o seu site de forma din&amp;acirc;mica? Desenvolver novas ferramentas? &lt;br /&gt;&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p style=&quot;text-align: justify&quot;&gt;Conhe&amp;ccedil;a o EVA, uma plataforma de desenvolvimento de sistemas escrita em PHP, totalmente em portugu&amp;ecirc;s. Textos, imagens, downloads, f&amp;oacute;rum, bate-papo e muito mais nesta ferramenta desenvolvida por membros da comunidade brasileira de software livre.&lt;br /&gt;&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt;EVA cms &amp;eacute; um programa de c&amp;oacute;digo aberto distribuido sob os termos da GNU General Public Licence.&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt; &lt;/p&gt;', '', '', NULL, 1108409400, 1156280375, 0, '', NULL, NULL);
INSERT INTO `{bdprefixo}_eva_conteudo` VALUES (3, 3, 'Exemplo de conte�do', 'Descri&amp;ccedil;&amp;atilde;o do conte&amp;uacute;do. Aqui voc&amp;ecirc; ir&amp;aacute; descrever a manchete da mat&amp;eacute;ria, ou o chamado para o texto, se o mesmo for exibido em um bloco.', 'Texto do conte&amp;uacute;do. Aqui voc&amp;ecirc; ir&amp;aacute; inserir o texto principal. Poder&amp;aacute; adicionar imagens, links e formatar o texto atrav&amp;eacute;s dos bot&amp;otilde;es acima', 'O autor do conte�do', 'Fonte, caso deseje indicar de onde foi retirado o conte�do', 'Palavras-chave, para uma melhor busca e integra��o entre conte�dos', 1093296540, 1156332638, 0, 'Coment�rios - S� ser�o exibidos para os Administradores.', NULL, NULL);

--
-- Extraindo dados da tabela `{bdprefixo}_eva_grupo`
--
TRUNCATE `{bdprefixo}_eva_grupo`;
INSERT INTO `{bdprefixo}_eva_grupo` VALUES (1, 'Super User', 'Grupo de SU', '@@@@@@@@@@', 'a', 1132588063, 2);

--
-- Extraindo dados da tabela `{bdprefixo}_eva_grupo_site`
--
TRUNCATE `{bdprefixo}_eva_grupo_site`;
INSERT INTO `{bdprefixo}_eva_grupo_site` VALUES (1, 1, '@@@@@@@@@@');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_menu`
--
TRUNCATE `{bdprefixo}_eva_menu`;
INSERT INTO `{bdprefixo}_eva_menu` VALUES (1, 'Menu Principal', 'Menu Topo');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_menu_item`
--
TRUNCATE `{bdprefixo}_eva_menu_item`;
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (3, 3, 1, 'Altere o Menu', '', '', 't', 7, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (9, 3, 1, 'Novo menu', '', 'index.php?s=1&m=eva_menu&a=cadastrar', 't', 8, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (10, 3, 1, 'Adicionar Itens', '', 'index.php?s=1&m=eva_menu&a=cadastrar_item', 't', 9, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (11, 3, 1, 'Listar Itens', '', 'index.php?s=1&m=eva_menu&a=listar', 't', 10, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (12, 12, 1, 'Blocos', '', '', 't', 2, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (13, 13, 1, 'M�dulos', '', '', 't', 5, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (14, 12, 1, 'Novo Bloco', '', 'index.php?s=1&m=eva_bloco&a=cadastrar', 't', 3, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (15, 12, 1, 'Listar/Editar', '', 'index.php?s=1&m=eva_bloco', 't', 4, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (16, 13, 1, 'Listar/Editar', '', 'index.php?s=1&m=eva_modulo', 't', 6, '_self');
INSERT INTO `{bdprefixo}_eva_menu_item` VALUES (18, 18, 1, 'Home', '', 'index.php?s=1', 't', 1, '_self');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_menu_item_grupo`
--
TRUNCATE `{bdprefixo}_eva_menu_item_grupo`;
INSERT INTO `{bdprefixo}_eva_menu_item_grupo` VALUES (12, 1);
INSERT INTO `{bdprefixo}_eva_menu_item_grupo` VALUES (13, 1);

--
-- Extraindo dados da tabela `{bdprefixo}_eva_modulo`
--
TRUNCATE `{bdprefixo}_eva_modulo`;
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (1, 'M�dulos', 'Sistema de Gerenciamento de M�dulos do EVA', 'eva_modulo', '1', 'a', 'bloco_centro.htm', '');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (2, 'Index', 'P�gina de Inicial', 'eva_index', '1.0', 'a', 'bloco_centro.htm', 's:0:\"\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (3, 'Configura��o', 'Instala��o do EVA', 'eva_config', '1', 'a', 'bloco_centro.htm', 's:7:\"s:0:\"\";\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (4, 'Usu�rios', 'Gerenciamento de Usu�rios e Grupos de Acesso', 'eva_usuario', '1', 'a', 'bloco_centro.htm', 's:14:\"s:7:\"s:0:\"\";\";\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (5, 'Blocos', 'Administra��o de blocos', 'eva_bloco', '1.0', 'a', 'bloco_centro.htm', 's:22:\"s:14:\"s:7:\"s:0:\"\";\";\";\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (6, 'Menu', 'Administra��o de Menus', 'eva_menu', '1', 'a', 'bloco_centro.htm', 's:30:\"s:22:\"s:14:\"s:7:\"s:0:\"\";\";\";\";\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (7, 'Site', 'MAdministra��o de Sites', 'eva_site', '1', 'a', 'bloco_centro.htm', 's:38:\"s:30:\"s:22:\"s:14:\"s:7:\"s:0:\"\";\";\";\";\";\";');
INSERT INTO `{bdprefixo}_eva_modulo` VALUES (8, 'Conte�do', 'Not�cias e Conte�do', 'eva_conteudo', '1', 'a', 'bloco_centro.htm', 's:46:\"s:38:\"s:30:\"s:22:\"s:14:\"s:7:\"s:0:\"\";\";\";\";\";\";\";');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_secao`
--
TRUNCATE `{bdprefixo}_eva_secao`;
INSERT INTO `{bdprefixo}_eva_secao` VALUES (1, 1, 7, 'Principal', 'Se��o principal', 't;v;u;1', '', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `{bdprefixo}_eva_secao` VALUES (2, 1, 7, 'Not�cias', 'Mat�rias e Not�cias', 't', 'right', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `{bdprefixo}_eva_secao` VALUES (3, 3, 8, 'Principal', 'Se��o Principal', 't', NULL, NULL, NULL, 1, 0, 0, 0, '0', 0);

--
-- Extraindo dados da tabela `{bdprefixo}_eva_site`
--
TRUNCATE `{bdprefixo}_eva_site`;
INSERT INTO `{bdprefixo}_eva_site` VALUES (1, 'Teste EVAcms', 'Site de Teste', 'eva_tema', 'http://localhost:80/evainstall', 'Daniel', 'a');

--
-- Extraindo dados da tabela `{bdprefixo}_eva_site_bloco`
--
TRUNCATE `{bdprefixo}_eva_site_bloco`;
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 11);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 12);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 13);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 14);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 15);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 16);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 17);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 18);
INSERT INTO `{bdprefixo}_eva_site_bloco` VALUES (1, 10);

--
-- Extraindo dados da tabela `{bdprefixo}_eva_usuario_grupo`
--
TRUNCATE `{bdprefixo}_eva_usuario_grupo`;
INSERT INTO `{bdprefixo}_eva_usuario_grupo` VALUES (1, 1);

";

?>