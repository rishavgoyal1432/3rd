/* Definindo a localiza��o do HTMLArea e o idioma */
var _editor_url = "biblioteca/javascripts/tiny_mce/";
var _editor_lang = "pt_br";
var editor_html = new Array;
var eva_enter = false;
var eva_id = 0;
var eva_menu_contexto;
var in_event;

/* Verificando o tipo de navegador*/
var eva_userAgent = navigator.userAgent.toLowerCase();
var eva_isOpera = eva_userAgent.indexOf('opera 7') != -1 ? 1 : 0;
var eva_isKonq = eva_userAgent.indexOf('konq') != -1 ? 1 : 0;
var eva_isIE = !eva_isKonq && !eva_isOpera && document.all ? 1 : 0;
var eva_isIE50 = eva_isIE && eva_userAgent.indexOf('msie 5.0') != -1;
var eva_isIE55 = eva_isIE && eva_userAgent.indexOf('msie 5.5') != -1;
var eva_isIE5 = eva_isIE50 || eva_isIE55;
var eva_isIE7 = eva_isIE && eva_userAgent.indexOf('msie 7') != -1;
var eva_isGecko = eva_userAgent.indexOf('gecko') != -1 ? 1 : 0;
var eva_mouseover = eva_isIE ? 'hand' : 'pointer';

/* Predefinindo objetos para HTMLArea*/
var area1 = "";
var area2 = "";
var area3 = "";
var area4 = "";
var area5 = "";

/* 
Fun��o gerar um identificador unico
*/
function eva_id(){
	eva_id++;
	return eva_id;
};

// Executa comando e retorna a <resposta> na camada
function comando(url){
	var resposta = true;
	var objeto = '';
	var metodo = '';
	var variaveis = '';
	var funcao = '';
	
	executar_comando(metodo, url, resposta, variaveis, objeto, funcao);
}
/*
// Executa comando e retorna a <resposta> na camada
function comando_exibir(o){
	
	i = eva_item(o,'resposta');
	c = eva_item(o,'camada');
	alert(c);
	eva_html(i, c);
	
}
*/
/* 
Fun��o para pegar um item dentro de um objeto DOM XML
o = objeto, t = tag, i = item,  e = elementos, r = resposta
*/
function eva_item(o,t){	
	//if((o == '' || o=='undefined') && typeof(o)!='object') return ''; isso nao funcionou no IE
	if(t == '') t = 'resposta';
	e = o.getElementsByTagName(t);
	rs = '';
	try{
		if(e.length > 0){
			for (i=0; i<(e.length); i++){
				rs += " "+ e[i].childNodes[0].nodeValue;
			};
		}else{
			rs = o.childNodes[0].nodeValue;
		};
	}catch(b){
		// alert(b);
	}
	if(rs == null) rs = '';
	return rs;
};

/* Retorna o objeto de id i */
function eva_elem(i){
		return document.getElementById(i);	
}

/* Retorna o valor do objeto de id i */
function eva_valor(i){
		return eva_elem(i).value;	
}

/* Retorna o conteudo do objeto de id i */
function eva_conteudo(i){
		return eva_elem(i).innerHTML;	
}

/* Atribui um conteudo c ao objeto de id i */
function eva_html(i, c){
		eva_elem(i).innerHTML = c;
}

/* Atribui um conteudo c ao objeto de id i */
function eva_add_html(i, c){
		eva_elem(i).innerHTML += c;
}

/* Oculta/exibe o objeto de id i */
function eva_ocultar(i){
		eva_elem(i).style.display = "none";
		eva_elem(i).style.visibility = "hidden";
}
function eva_exibir(i){
		eva_elem(i).style.display = "block";
		eva_elem(i).style.visibility = "";
		//eva_elem(i).style.visibility = "visible";
}

function eva_ocultar_exibir(i){
		if(eva_elem(i).style.display == "none")
			eva_exibir(i);
		else
			eva_ocultar(i);
}

function eva_exibir_ocultar(i){
	if (eva_elem(i).style.visibility == "hidden"){
		eva_exibir(i);
	}else{
		eva_ocultar(i);
	}
}

/* Verifica se a tecla digitada foi Enter
function enter(e){
	if (window.event){
		x = window.event.keyCode;
	alert(x);
	}else if(e){
		x = e.which;
	alert(x);
	}else{
		x = null;
	};
	if(x == 13){
		return true;
	};
	return false;
}; */

function enter(e){ //e is event object passed from function invocation
	try{
		var characterCode; //literal character code will be stored in this variable
		if(e && e.which){ //if which property of event object is supported (NN4)
			e = e;
			characterCode = e.which; //character code is contained in NN4's which property
		}else if(e){
			e = event;
			characterCode = e.keyCode; //character code is contained in IE's keyCode property
		}else if (window.event){
			characterCode = window.event.keyCode;
		}
		if(characterCode == 13){
			return true;
		}else{
			return false;
		}
	}catch(er){}
}




/* Insere linhas na tabela com um campo imput para arquivos*/
function insRow(tabela, campo, linha){
	var o=document.getElementById(tabela);
	var x=o.insertRow(linha);
	var y=x.insertCell(0);
	var z=x.insertCell(1);
	y.innerHTML='';
	z.innerHTML='<input type="file" name="'+campo+'[]" size="50"/>';
};

/*insere linhas na tabela com os campos - usada no modulo de enquete*/
function insereLinhaResposta(tabela, campo,campo2){
	var o=document.getElementById(tabela);
	var x=o.insertRow(o.rows.length);
	var y=x.insertCell(0);
	var z=x.insertCell(1);
	var w=x.insertCell(2);	
	y.align = 'center'; z.align = 'center'; w.align = 'center'; 
	y.innerHTML='<input type="text" name="'+campo+'[]" id="'+campo+'[]" size="50" maxlength="45"/>';
	z.innerHTML='<input type="text" name="'+campo2+'[]" id="'+campo2+'[]" size="3" maxlength="2"/>';	
};

function Get_Cookie(name) {
    var start = document.cookie.indexOf(name+"=");
    var len = start+name.length+1;
    if ((!start) && (name != document.cookie.substring(0,name.length))) return null;
    if (start == -1) return null;
    var end = document.cookie.indexOf(";",len);
    if (end == -1) end = document.cookie.length;
    return unescape(document.cookie.substring(len,end));
};

function Set_Cookie(name,value,expires,path,domain,secure) {
    document.cookie = name + "=" +escape(value) +
        ( (expires) ? ";expires=" + expires.toGMTString() : "") +
        ( (path) ? ";path=" + path : "") + 
        ( (domain) ? ";domain=" + domain : "") +
        ( (secure) ? ";secure" : "");
};

function Delete_Cookie(name,path,domain) {
    if (Get_Cookie(name)) document.cookie = name + "=" +
        ( (path) ? ";path=" + path : "") +
        ( (domain) ? ";domain=" + domain : "") +
        ";expires=Thu, 01-Jan-1970 00:00:01 GMT";
};

var blocos_visiveis = new Array();
if (blocos_visiveis_srting = Get_Cookie("blocos_visiveis")){
	blocos_visiveis = blocos_visiveis_srting.split(",");
};

function mostrar_apagar_bloco(num, imagem){	
	bloco = document.getElementById("bloco"+num);
	if (bloco.style.visibility == "hidden"){
		bloco.style.display = "block";
		bloco.style.visibility = "";
		//bloco.style.visibility = "visible";
		blocos_visiveis[num]="visible";
		imagem.className = "botao_minimizar";
	}else{
		bloco.style.display = "none";
		bloco.style.visibility = "hidden";
		blocos_visiveis[num]="hidden";
		imagem.className = "botao_restaurar";
	};
	document.cookie = "blocos_visiveis="+blocos_visiveis;
};


/* Fun�ao para efeito da cor do BG  que substituir� a funcao acima*/
var classe_antiga = "destaque_branco";
var classe_destaque = "destaque_cinza";
function destacar(x){
	if(x.className !=  classe_destaque){
		classe_antiga = x.className;
		x.className = classe_destaque;
	}else{
		x.className = classe_antiga;
	};
};

function confirma(mensagem){
	if (confirm(unescape(mensagem)))
	{
		return true;
	};
	return false;
};


var padrao_menu_botoes = /^menu_botoes/;
function menu_botoes_mouseover(td,alt,alt_id,tipo,event){
	td.style.cursor = eva_mouseover;
	if(alt != "" && tipo != "camada"){
		espaco = " ";
		document.getElementById(alt_id).innerHTML = espaco+alt+espaco;
	};
	return true;
};
function menu_botoes_mousedown(td){
	if(padrao_menu_botoes.test(td.className)){
		td.className="menu_botoes_mousedown";
	}
};

function validar_form(form_id){
	for (var x = 0; x < editor_html.length; x++){
		try{
			eval(editor_html[x]+"._textArea.value = "+editor_html[x]+".getHTML()");
			eval(editor_html[x]+"._textArea.value = "+editor_html[x]+"._textArea.value.trim()");
		}catch(e){}
	}
	
	form = document.getElementById(form_id);
	
	eval("var campo_ok = typeof "+form_id+"_campo");
	if(campo_ok != 'undefined'){
		eval("campo = "+form_id+"_campo");
		eval("alerta = "+form_id+"_alerta");
		eval("tipo = "+form_id+"_tipo");
		if(campo.length > 0){
			for (var x = 0; x < campo.length; x++){
				try{
					eval("campo_form = form."+campo[x]);
					var padrao = tipo[x];
					if(campo_form.type == "select-one"){
						var index = campo_form.selectedIndex;
						if (campo_form.options[index].value == "" || campo_form.options[index].value == "0"){
							alert(alerta[x]);
							campo_classe = campo_form.className;
							campo_form.className = "alerta_campo";
							campo_form.focus();
							campo_form.onkeydown = function(ef){
								campo_form.className = campo_classe;
							};
							return false;
						};
					};
					if (!padrao.test(campo_form.value)) {
					alert(alerta[x]);
					campo_classe = campo_form.className;
					campo_form.className = "alerta_campo";
					campo_form.focus();
					campo_form.onkeydown = function(ef){
						campo_form.className = campo_classe;
					};
					return false;
				};
				}catch(e){}
			};
			
		};
	};
	return true;
}

function menu_botoes_mouseup(td, confirma, action, url, funcao, form_id, target, ajax){
	if(padrao_menu_botoes.test(td.className)){
		td.className="menu_botoes_mouseover";
	}
	if(confirma=="" || confirm(unescape(confirma))){
		if (action != ""){	
			if(!validar_form(form_id))
				return false;
			// ajax
			if(ajax){
				if(!ajax_obj)
					ajax_obj = criar_objeto_xmlhttp();
				executar_comando('POST', action, true, pegar_elementos_form(form_id), ajax_obj, '');	
			}
			if(target != ""){
				form.target=target;
			}
			form.action=action;
			//alert(form_id+' - '+form+' - '+form.action);return;
			form.submit();
		}else if(target != ""){
			window.open(url,target);
		}else if(url != ""){
			document.location = url;
		}else if(funcao != ""){
			if(!validar_form(form_id))
				return false;
			eval(funcao);
		};
	};
};

/* Fun��o para tratar a visibilidade de camadas sobre outros objetos*/
function ocultar_objetos(camada){
	/* Baseado no c�digo do JSCookMenu*/
	if (document.all)	/*it is IE*/ 
	{
		if (!camada.cmOverlap)
			camada.cmOverlap = new Array ();
		/*@cc_on @*/
		/*@if (@_jscript_version >= 5.5)
		@else @*/
		cmHideControl ("IFRAME", camada);
		/*@end @*/
		cmHideControl ("SELECT", camada);
		cmHideControl ("OBJECT", camada);
	};
};

/* Fun��o de navega��o do GRID*/
function goToPage(delta,nome){
	var count = nome.getProperty("row/pageCount");
	var number = nome.getProperty("row/pageNumber");
	number += delta;
	if (number < 0) {number = 0};
	if (number > count-1) {number = count-1};
	grade_pagina = nome.getId();
	eval("obj = document.getElementById('pagina_"+grade_pagina+"')");
	obj.innerHTML = "P�gina " + (number + 1) + " de " + count + " ";
	nome.setProperty("row/pageNumber", number);
	nome.refresh();	
};
/* Supress�o de erros na pagina */
function silentHandler() {
	return true
};

/* Fun��o para montar menu de contexto*/
function montar_menu_contexto(menu_contexto_itens){
	cmDraw ('menu_contexto', menu_contexto_itens, 'vbr', cmTheme, 'padrao', '');
}
function comando_contexto(menu_resposta){
	contexto_itens = eva_item(menu_resposta,'menu');
	eval(contexto_itens);
	eva_menu_contexto = menu_contexto_itens;
	montar_menu_contexto(menu_contexto_itens);
}
function precarregar_contexto(menu_resposta){
	contexto_itens = eva_item(menu_resposta,'menu');
	eval(contexto_itens);
	eva_menu_contexto = menu_contexto_itens;
}
/* 
Fun��o que gera um checkbox que seleciona todos os itens de um formul�rio via java script
i = id base, o = objeto, t = total 
*/
var selecionar_checkbox = true;
function selecionar_todos(o,i,t){
	if(selecionar_checkbox){
		selecionar_checkbox = false;
	}else{
		selecionar_checkbox = true;
	}
	for (j=0;j<=t;j++){
		if(checkbox = document.getElementById(i+''+j)){
			checkbox.checked = !selecionar_checkbox;
		}
	}
}

// outra op�ao pra selecionar checkbox field = document.nomedoform
function checkAll(field) {
	if (field[0].checked) {			
		status_primeiro = true;
	} else {
		status_primeiro = false;
	}
  	for (i = 0; i < field.length; i++) {
  		if (status_primeiro) {	
			field[i].checked = false;
		} else {
			field[i].checked = true;
		}
	}
}

// outra op�ao pra selecionar checkbox field = document.nomedoform
function selectAll(field) {
	field = eva_elem(field);
	if (field.options[0].selected) {			
		status_primeiro = true;
	} else {
		status_primeiro = false;
	}
  	for (i = 0; i < field.length; i++) {
  		if (status_primeiro) {	
			field.options[i].selected = false;
		} else {
			field.options[i].selected = true;
		}
	}
}

// checa ou descheca tudo
function unchAll(field, val) {	
  	for (i = 0; i < field.length; i++) {	
		field[i].checked = val;		
	}
}

// checa ou descheca o elemento
function check_uncheck(field) {	
	ch_elem = eva_elem(field);
	if(ch_elem.type=="radio"){
		ch_elem.checked=true;
	}else
  		ch_elem.checked=!ch_elem.checked;
}

function findPosX(obj) {
    var curtop = 0;
	  if (obj.offsetParent) {
		    while (obj.offsetParent) {
			       curtop += obj.offsetLeft;
			       obj = obj.offsetParent;
		    };
    }else if (obj.x) curtop += obj.x;
	  return curtop;
};

function findPosY(obj) {
    var curtop = 0;
	  if (obj.offsetParent) {
		    while (obj.offsetParent) {
			       curtop += obj.offsetTop;
			       obj = obj.offsetParent;
		    };
    }else if (obj.y) curtop += obj.y;
	  return curtop;
};

String.prototype.trim = function() {
	return this.replace(/(^\s*)|(\s*$)/g,"");
};

/*
pega todos os elementos de um form e retorna na estrutura de get nome=valor&nome2=valor2&nome3=valor3
*/
function pegar_elementos_form(form_nome){
	if(form_nome=="" || form_nome=="undefined")return "";
	f=document.getElementById(form_nome);
	if(!f)return "";
	form_post="";
	for(i=0;i<f.length;i++){
		if(f.elements[i].name && (f.elements[i].type!='checkbox' || f.elements[i].checked) && (f.elements[i].type!='radio' || f.elements[i].checked)){
			if(f.elements[i].type=='select-multiple' && f.elements[i].multiple==true){
				/* for para pegar multiple select */
				for(j=0;j<f.elements[i].length;j++){
					if(f.elements[i].options[j].selected == true)
						form_post+=f.elements[i].name+"="+f.elements[i].options[j].value+"&";
				}
			}else{
				form_post+=f.elements[i].name+"="+f.elements[i].value+"&";
			}
		}
	};
	return form_post;	
};

/* 
Executar Comandos
*/
function eva_xmlhttp(){
	eva_ajax['valor'] *= 1;
	if(eva_ajax['resposta']){
		clearTimeout(eva_ajax['resposta']);
	};
	if(eva_ajax['limpar']){
		clearTimeout(eva_ajax['limpar']);
	};
	
	if(eva_ajax['valor']<eva_ajax['total']){
		try{
			eval('eva_ajax_recarrega=eva_ajax_'+eva_ajax['valor']);
			if(eva_ajax['func'][eva_ajax['valor']]){
				executar_comando('GET', eva_ajax['src'][eva_ajax['valor']], true, '', eva_ajax_recarrega, eva_ajax['func'][eva_ajax['valor']++]);
			}else{		
				executar_comando('GET', eva_ajax['src'][eva_ajax['valor']++], true, '', eva_ajax_recarrega, 'eva_xmlhttp');
			};
		}catch(e){
			//eva_ajax['valor']++
		};							
	}else{
		eva_ajax['valor']=0;
	}
	eva_ajax['limpar'] = setTimeout('eva_xmlhttp();', eva_ajax['repetir']);
}

function criar_objeto_xmlhttp(){
	var a=null;
	if (window.XMLHttpRequest){
		// IE7, Mozilla, Safari, etc: browsers decentes
		a = new XMLHttpRequest()
	}else{
		if (window.ActiveXObject){
			// �outro jeito, usando o ActiveX para IE5.x e IE6
			//a = new ActiveXObject("Microsoft.XMLHTTP");		
			try{
				a=new ActiveXObject("Msxml2.XMLHTTP");
			}catch(c){
				try{
					a=new ActiveXObject("Microsoft.XMLHTTP");
				}catch(b){
					a=null;
				};
			};
		}
	}
	return a;
};

eva_ajax_obj = criar_objeto_xmlhttp();
var eva_ajax_resposta;

// Executa requisicao Ajax
function executar_comando(metodo, url, resposta, variavel_post, objeto, funcao){
	//alert(metodo+"\n"+url+"\n"+resposta+"\n"+variavel_post+"\n"+objeto+"\n"+funcao);
	//alert(typeof(metodo)+"\n"+typeof(url)+"\n"+typeof(resposta)+"\n"+typeof(variavel_post)+"\n"+typeof(objeto)+"\n"+typeof(funcao));
	
	oldcss = false;
	/* loading pra todas as requisicoes, mas nao funciona direito no IE*/
	if(camada = getget("camada", url)){
		c = eva_elem(camada);
		// se ja estiver com o estilo carregando
		var re = /carregando/; 
		if(!re.test(c.innerHTML)){		
			// a posicao tem que ser relativa
			oldcss = c.style.cssText;
			var re = /position: relative/; 
			if(!re.test(oldcss))
				c.style.cssText += "position: relative;";
			d = document.createElement("div");
			d.className = "wait";
			d.innerHTML = "<br><br><br><br><br><br>";
			c.appendChild(d);
		}
	}
	
	da=eva_elem('debug_ajax');
	
	if(da)
		da.innerHTML+='<a href="'+url+'">'+url+'</a><hr>';
	document.body.style.cursor = 'wait';
	objeto = (typeof(objeto)=="string")? eva_ajax_obj : objeto;
	metodo = (metodo == '')? 'GET' : metodo;	
	variavel_post = (variavel_post == "")? null : variavel_post;
	if(objeto){	
		try{
			objeto.open(metodo,url,resposta);
			if(variavel_post){
				//objeto.setRequestHeader('Content-Type','text/html; charset=iso-8859-1;' );
				objeto.setRequestHeader('Content-Type','application/x-www-form-urlencoded;' );
				objeto.setRequestHeader("Method", "POST "+url+" HTTP/1.1");
			};
			objeto.send(variavel_post);
		}catch(e){};
			/* pegar resposta do xmlhttprequest */
			objeto.onreadystatechange=function() {
				/* quando o obj estiver pronto */
				if (objeto.readyState==4) {
					if (objeto.status==200){
						if(obj_xml=objeto.responseXML){
							/* pega o no de alerta */
							alerta=obj_xml.getElementsByTagName("alerta");
							texto_alerta="";
							for(i=0;i<alerta.length;i++){
								img=alerta[i].getElementsByTagName("img");
								texto=alerta[i].getElementsByTagName("texto");
								img=(img[0].childNodes[0].nodeValue=="")?"":tag_imagem.replace("eva_imagem.png",img[0].childNodes[0].nodeValue);
								texto=texto[0].childNodes[0].nodeValue==""?"<br>":texto[0].childNodes[0].nodeValue+"<br>";
								texto_alerta=texto_alerta+img+'<span style="white-space:nowrap">'+texto+'</span>';
							};
							if(texto_alerta!=""){
								stm(["", eva_alerta_modelo1+texto_alerta+eva_alerta_modelo3],["","","","","","","","","","","","float","","","","",2,2,(window_size("w")-(+5)),10,"","","","",""], this, false, 0, 0, "");
							};
							var js_sessao = obj_xml.getElementsByTagName("js_sessao");	
							var eva_xml_css = obj_xml.getElementsByTagName("eva_xml_css");
							resposta=obj_xml.getElementsByTagName("resposta");
						};
					};
					
					var camada = obj_xml.getElementsByTagName("camada");
					if(camada.length){
						camada_id = camada[0].childNodes[0].nodeValue;
						var conteudo = eva_item(resposta[0],'resposta');
						try{
							if(tag = obj_xml.getElementsByTagName("resposta_tag")){
								if(tag[0].childNodes[0].nodeValue)
									var conteudo = eva_item(resposta[0], tag[0].childNodes[0].nodeValue);
								//alert(conteudo);
							}
						}catch(e){}
						if(camada[0].getAttribute("substituir") == 'false'){
							conteudo = eva_conteudo(camada_id) + '' + conteudo;
						}
						eva_html(camada_id, conteudo);
						if(oldcss!==false){
							camada = getget("camada", url)
							//eva_elem(camada).innerHTML += "<div class=\"wait\"></div>";
							c = eva_elem(camada);
							// a posicao tem que ser relativa
							c.style.cssText = oldcss;
						}
					};					
					if(funcao){
						try{
							if(resposta.length){
								eval(funcao+'(resposta[0])');
							}else{
								eval(funcao+'()');
							};
						}catch(e){};
					};
					if(js_sessao.length){
						for(i=0;i<js_sessao.length;i++){
							js_sessao_comando = js_sessao[i].childNodes[0].nodeValue;
							var script = document.createElement('script');
							script.type = 'text/javascript';
							script.src = js_sessao_comando;
							head = document.getElementsByTagName('head');
							// dettect if there is already this script
							_script = document.getElementsByTagName('script');
							_append = 1;
							for(j=0;j<_script.length;j++){
								if(script.src==_script[j].src && !ereg(/&comando_tipo=js_sessao/, _script[j].src)){									
									_append = 0;// there is already a script like this
									break;
								}
							}
							if(_append){
								head[0].appendChild(script);
							}
						}
					};
					/**/
					if(eva_xml_css.length){
						for(i=0;i<eva_xml_css.length;i++){
							eva_xml_css_comando = eva_xml_css[i].childNodes[0].nodeValue;
							var script = document.createElement('link');
							script.type = 'text/css';
							script.href = eva_xml_css_comando;
							script.rel = "StyleSheet";
							head = document.getElementsByTagName('head');
							// dettect if there is already this script
							_script = document.getElementsByTagName('link');
							_append = 1;
							for(j=0;j<_script.length;j++){
								if(script.href==_script[j].href){									
									_append = 0;// there is already a script like this
									break;
								}
							}
							if(_append){
								head[0].appendChild(script);
							}
						}
					};	
					
				};
		};
	};
	document.body.style.cursor = 'default';
};

function ereg(reTipo, pVal){
	return reTipo.test(pVal);
}

function in_array(palavra, vetor){
	for(i=0; i<vetor.length; i++){
		//alert(palavra+" == "+vetor[i]);
		if(palavra == vetor[i])
			return true;
	}	
	return false;
}

/* Atualiza o conte�do de um objeto atrav�s do innerHTML */
function atualizar_html(conteudo_html, id_objeto){
		sinal = true;
		document.getElementById(id_objeto).innerHTML = conteudo_html;
};

/* Fun��o para contar caracteres em um campo de formul�rio */
function contar_caracteres(objeto, valorMaximo, contador) {
	if(objeto.value.length>valorMaximo) {
		objeto.value = objeto.value.substring(0,valorMaximo);
	};
	x = document.getElementById(contador);
	x.innerHTML = objeto.value.length;
};

/* funcao que retorna o tamanho da janela passa-se w para width e h para height */
function window_size(tipo) {
  var myWidth = 0, myHeight = 0;
  if( typeof( window.innerWidth ) == 'number' ) {
    myWidth = window.innerWidth;
    myHeight = window.innerHeight;
  } else if( document.documentElement &&
      ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    /*IE 6+ in 'standards compliant mode' */
    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    /*IE 4 compatible*/
    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;
  };
  if(tipo=='w'){
  	return myWidth;
  }else if(tipo=='h'){
  	return myHeight;
  };
};

/*
InStr(strSearch, charSearchFor) : Returns the first location a substring (SearchForStr)
                           was found in the string str.  (If the character is not
                           found, -1 is returned.)
                           
Requires use of:
	Mid function
	Len function
*/
function InStr(strSearch, charSearchFor)
{
	for (i=0; i < Len(strSearch); i++)
	{
	    if (charSearchFor == Mid(strSearch, i, 1))
	    {
			return i;
	    }
	}
	return -1;
}
/***
		IN: str - the string we are LEFTing
			start - our string's starting position (0 based!!)
			len - how many characters from start we want to get

		RETVAL: The substring from start to start+len
***/
function Mid(str, start, len){
		// Make sure start and len are within proper bounds
		if (start < 0 || len < 0) return "";

		var iEnd, iLen = String(str).length;
		if (start + len > iLen)
				iEnd = iLen;
		else
				iEnd = start + len;

		return String(str).substring(start,iEnd);
}

// IN: str - the string whose length we are interested in
//RETVAL: The number of characters in the string
function Len(str){  
	return String(str).length;
}

function rand (inicio, fim){
  return ( Math.floor ( Math.random ( ) * fim + inicio ) );
}

function _GET(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  } 
  //alert('Query Variable ' + variable + ' not found');
  return false;
}

function getget(variable, url) {
  var vars = url.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  } 
  //alert('Query Variable ' + variable + ' not found');
  return false;
}

function empty(_var){
	return (typeof(_var) == "undefined" || _var==null || _var==0 || _var.trim()=='' );
}

Set_Cookie("eva_height",window_size('h'));
Set_Cookie("eva_width",window_size('w'));
/*Para liberar o Onload*/
var eva_javascript = true;