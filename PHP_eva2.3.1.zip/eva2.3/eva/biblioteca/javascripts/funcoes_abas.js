/**
* @package evacms
* @copyleft (cc) 2004-2006 EVAcms. Alguns direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

function mostrar_aba(aba_url, num,aba_total,cont_aba,sentido,modulo){
	for(i_aba=aba_total;i_aba < cont_aba;i_aba++){
		//alert("aba"+modulo+i_aba);
		aba_antiga = document.getElementById("aba"+modulo+i_aba);
		aba_antiga.style.display = "none";
		aba_antiga.style.visibility = "hidden";
		muda_classe("td"+modulo+i_aba,"aba_"+sentido+"_normal");
		muda_classe("td"+modulo+i_aba+"_2","aba_"+sentido+"_normal_2");
	};
	nova_aba = document.getElementById("aba"+modulo+num);	
	nova_aba.style.display = "block";	
	nova_aba.style.visibility = "visible";
	muda_classe("td"+modulo+num,"aba_"+sentido+"_selecionada");
	muda_classe("td"+modulo+num+"_2","aba_"+sentido+"_selecionada_2");
	Set_Cookie(modulo+aba_total,num);
};
function recarregar_aba(aba_url,num,aba_total,cont_aba,sentido,modulo){
	if(confirm(eva_alerta_aba)){
		Set_Cookie(modulo+aba_total,num);
		document.location = aba_url;
	};
};

function muda_classe(obj_id,obj_class){	
obj = document.getElementById(obj_id);
obj.className = obj_class;
}

function aba_sobre(aba_obj,sentido,tipo){
	if(tipo == "sobre"){
		aba_obj.style.cursor=eva_mouseover;
	};
	aba1 = eva_elem(aba_obj.id);
	aba2 = eva_elem(aba_obj.id+"_2");
	if(aba1.className != "aba_"+sentido+"_selecionada"){
		//alert("aba_"+sentido+"_"+tipo);
		aba1.className =  "aba_"+sentido+"_"+tipo;
		aba2.className =  "aba_"+sentido+"_"+tipo+"_2";
	};
};

function carrega_aba(url, aba_id, lista_abas){
	if(eval("!in_array(aba_id, "+lista_abas+")")){
		//eval("eva_html('"+aba_id+"', '<div class=\"carregando\"></div>')");
		eval(lista_abas+"["+lista_abas+".length] = aba_id");
		//comando(url+'&camada='+aba_id);
		novo_obj = criar_objeto_xmlhttp();
		url+='&camada='+aba_id;
		executar_comando('GET', url, true, '', novo_obj, '');
	}
}