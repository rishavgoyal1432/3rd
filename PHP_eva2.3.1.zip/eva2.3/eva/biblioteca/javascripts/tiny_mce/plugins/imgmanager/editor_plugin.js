/* Import theme specific language pack */
tinyMCE.importPluginLanguagePack('imgmanager', 'en,de,pl');

function TinyMCE_imgmanager_getControlHTML(control_name) {
    switch (control_name) {
        case "imgmanager":
            return '<img id="{$editor_id}_imgmanager" src="{$pluginurl}/../../themes/advanced/images/image.gif" title="{$lang_insert_imgmanager}" width="20" height="20" class="mceButtonNormal" onmouseover="tinyMCE.switchClass(this,\'mceButtonOver\');" onmouseout="tinyMCE.restoreClass(this);" onmousedown="tinyMCE.restoreAndSwitchClass(this,\'mceButtonDown\');" onclick="tinyMCE.execInstanceCommand(\'{$editor_id}\',\'mceimgmanager\');" />';
    }
    return "";
}

/**
 * Executes the mceimgmanager command.
 */
function TinyMCE_imgmanager_execCommand(editor_id, element, command, user_interface, value) {
    // Handle commands
    switch (command) {
        case "mceimgmanager":
            var template = new Array();
           /*EVA*/
		   // template['file']   = '../../plugins/imgmanager/InsertFile/insert_file.php'; // Relative to theme
            template['file']   = '../../plugins/imgmanager/ImageManager/manager.php'; // Relative to theme
            template['width']  = 660;
            template['height'] = 500;

            tinyMCE.openWindow(template, {editor_id : editor_id});
       return true;
   }
   // Pass to next handler in chain
   return false;
}
