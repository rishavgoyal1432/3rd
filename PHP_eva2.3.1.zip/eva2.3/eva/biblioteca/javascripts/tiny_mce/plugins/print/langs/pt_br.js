// pt_BR lang variables

tinyMCE.addToLang('',{
print_desc : 'Imprimir'
});
