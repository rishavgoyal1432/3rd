// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Geral',
tab_appearance : 'Apar�ncia',
tab_advanced : 'Avan�ado',
general : 'Geral',
title : 'Titulo',
preview : 'Preview',
constrain_proportions : 'For�ar propor��es',
langdir : 'Dire��o do Idioma',
langcode : 'C�digo do Idioma',
long_desc : 'Descri��o longa do Link',
style : 'Estilo',
classes : 'Classes',
ltr : 'Esquerda para a direita',
rtl : 'Direita para a Esquerda',
id : 'Id',
image_map : 'Image map',
swap_image : 'Trocar Imagem',
alt_image : 'Imagem alternativa',
mouseover : 'Para mouse over',
mouseout : 'Para mouse out',
misc : 'Miscellaneous',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : 'Are you sure you want to continue without including an Image Description? Without  it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.'
});