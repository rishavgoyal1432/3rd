// UK lang variables

tinyMCELang['lang_insert_filemanager'] = 'Insert File Link';