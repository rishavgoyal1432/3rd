// UK lang variables

tinyMCELang['lang_insert_filemanager'] = 'Inserir um link para um arquivo';