// pt_BR lang variables

tinyMCE.addToLang('flash',{
title : 'Inserir / editar Arquivo Flash',
desc : 'Inserir / editar Arquivo Flash',
file : 'Arquivo Flash (.swf)',
size : 'Tamanho',
list : 'Lista de arquivos Flash',
props : 'Propriedades Flash',
general : 'Geral'
});
