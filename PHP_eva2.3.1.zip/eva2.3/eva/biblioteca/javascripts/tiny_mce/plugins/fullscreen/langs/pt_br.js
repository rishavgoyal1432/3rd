// UK lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Modo Tela Cheia',
fullscreen_desc : 'Mudar Modo Tela cheia'
});
