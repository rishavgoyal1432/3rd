// UK lang variables

tinyMCELang['lang_insert_image_desc']   			= 'Insert image'
tinyMCELang['lang_insert_pagebreak_desc']    = 'Insert pagebreak';
tinyMCELang['lang_insert_pagebreak_title']   = 'Settings for pagebreak';
tinyMCELang['lang_insert_pagebreak_atext']   = 'Page Title';
tinyMCELang['lang_insert_pagebreak_ctext']   = 'Table of Contents';
tinyMCELang['lang_insert_pagebreak_title']   = 'pagebreak elements plugin';
