// UK lang variables

tinyMCELang['lang_insert_image_desc']   	= 'Inserir imagem'
tinyMCELang['lang_insert_pagebreak_desc']    = 'Inserir Quebra de P�gina';
tinyMCELang['lang_insert_pagebreak_title']   = 'Configura��es para quebra de p�gina';
tinyMCELang['lang_insert_pagebreak_atext']   = 'T�tulo da p�gina';
tinyMCELang['lang_insert_pagebreak_ctext']   = 'Sum�rio';
tinyMCELang['lang_insert_pagebreak_title']   = 'Elementos para quebra de p�gina';
