/* Import theme specific language pack */
tinyMCE.importPluginLanguagePack('pagebreak', 'en,de,pl');

function TinyMCE_pagebreak_getControlHTML(control_name) {
    switch (control_name) {
        case "pagebreak":
            return '<img id="{$editor_id}_pagebreak" src="{$pluginurl}/images/pagebreak.gif" title="{$lang_insert_pagebreak_desc}" width="20" height="20" class="mceButtonNormal" onmouseover="tinyMCE.switchClass(this,\'mceButtonOver\');" onmouseout="tinyMCE.restoreClass(this);" onmousedown="tinyMCE.restoreAndSwitchClass(this,\'mceButtonDown\');" onclick="tinyMCE.execInstanceCommand(\'{$editor_id}\',\'mcepagebreak\');" />';
    }
    return "";
}

function TinyMCE_pagebreak_execCommand(editor_id, element, command, user_interface, value) {
    // Handle commands
    switch (command) {
        case "mcepagebreak":
		var html = '<hr id="pagebreak" style="border-top: 1px dashed #f00; border-bottom: 0px solid #f00; color: #fff; background-color: #fff; height: 4px; page-break-after:always" />';
		tinyMCE.execCommand("mceInsertContent",true,html);
       return true;
   }
   // Pass to next handler in chain
   return false;
}
