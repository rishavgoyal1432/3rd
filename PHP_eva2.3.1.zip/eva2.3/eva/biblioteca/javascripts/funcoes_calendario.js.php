<?php
/**
* @package evacms
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html  LGPL License
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
?><?php
require("../classes/eva_javascript.php");
$eva['javascript'] = new eva_javascript;
$eva['javascript']->config("inicio");
$eva["arquivo"]->retirar_espacos($idioma);
?>
Calendar._DN = new Array
("<?php echo $idioma['dia_domingo']?>",
 "<?php echo $idioma['dia_segunda']?>",
 "<?php echo $idioma['dia_terca']?>",
 "<?php echo $idioma['dia_quarta']?>",
 "<?php echo $idioma['dia_quinta']?>",
 "<?php echo $idioma['dia_sexta']?>",
 "<?php echo $idioma['dia_sabado']?>",
 "<?php echo $idioma['dia_domingo']?>");
Calendar._SDN = new Array
("<?php echo $idioma['dia_domingo_menor']?>",
 "<?php echo $idioma['dia_segunda_menor']?>",
 "<?php echo $idioma['dia_terca_menor']?>",
 "<?php echo $idioma['dia_quarta_menor']?>",
 "<?php echo $idioma['dia_quinta_menor']?>",
 "<?php echo $idioma['dia_sexta_menor']?>",
 "<?php echo $idioma['dia_sabado_menor']?>",
 "<?php echo $idioma['dia_domingo_menor']?>");
Calendar._FD = 0;
Calendar._MN = new Array
("<?php echo $idioma['mes_janeiro']?>",
 "<?php echo $idioma['mes_fevereiro']?>",
 "<?php echo $idioma['mes_marco']?>",
 "<?php echo $idioma['mes_abril']?>",
 "<?php echo $idioma['mes_maio']?>",
 "<?php echo $idioma['mes_junho']?>",
 "<?php echo $idioma['mes_julho']?>",
 "<?php echo $idioma['mes_agosto']?>",
 "<?php echo $idioma['mes_setembro']?>",
 "<?php echo $idioma['mes_outubro']?>",
 "<?php echo $idioma['mes_novembro']?>",
 "<?php echo $idioma['mes_dezembro']?>");
 
Calendar._SMN = new Array
("<?php echo $idioma['mes_janeiro_menor']?>",
 "<?php echo $idioma['mes_fevereiro_menor']?>",
 "<?php echo $idioma['mes_marco_menor']?>",
 "<?php echo $idioma['mes_abril_menor']?>",
 "<?php echo $idioma['mes_maio_menor']?>",
 "<?php echo $idioma['mes_junho_menor']?>",
 "<?php echo $idioma['mes_julho_menor']?>",
 "<?php echo $idioma['mes_agosto_menor']?>",
 "<?php echo $idioma['mes_setembro_menor']?>",
 "<?php echo $idioma['mes_outubro_menor']?>",
 "<?php echo $idioma['mes_novembro_menor']?>",
 "<?php echo $idioma['mes_dezembro_menor']?>");

Calendar._TT = {};
Calendar._TT["INFO"] = "<?php echo $idioma['info_calendario']?>";

Calendar._TT["ABOUT"] = "<?php echo $idioma['sobre_calendario']?>";

Calendar._TT["ABOUT_TIME"] = "<?php echo $idioma['sobre_hora']?>";

Calendar._TT["PREV_YEAR"] = "<?php $idioma["ano_anterior"]?>";
Calendar._TT["PREV_MONTH"] = "<?php echo $idioma["mes_anterior"]?>";
Calendar._TT["GO_TODAY"] = "<?php echo $idioma["data_atual"]?>";
Calendar._TT["NEXT_MONTH"] = "<?php echo $idioma["proximo_mes"]?>";
Calendar._TT["NEXT_YEAR"] = "<?php echo $idioma["proximo_ano"]?>";
Calendar._TT["SEL_DATE"] = "<?php echo $idioma["selecione_data"]?>";
Calendar._TT["DRAG_TO_MOVE"] = "<?php echo $idioma["clique_para_mover"]?>";
Calendar._TT["PART_TODAY"] = " <?php echo $idioma["dia_hoje"]?>";

Calendar._TT["DAY_FIRST"] = "<?php echo $idioma["exibir_primeiro"]?>";

Calendar._TT["WEEKEND"] = "<?php echo $idioma["semana_inicio"]?>";

Calendar._TT["CLOSE"] = "<?php echo $idioma["fechar"]?>";
Calendar._TT["TODAY"] = "<?php echo $idioma["hoje"]?>";
Calendar._TT["TIME_PART"] = "<?php echo $idioma["mudar_hora"]?>";

Calendar._TT["DEF_DATE_FORMAT"] = "<?php echo $idioma['formato_data_calendar']?>";
Calendar._TT["TT_DATE_FORMAT"] = "<?php echo $idioma['formato_data_desc_calendar']?>";

Calendar._TT["WK"] = "<?php echo $idioma["semana_menor"]?>";
Calendar._TT["TIME"] = "<?php echo $idioma["hora"]?>";

<?php
$eva['javascript']->config("fim");
?>