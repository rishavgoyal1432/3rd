<?php
/**
* @package evacms
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html  LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
?><?php
require("../classes/eva_javascript.php");
$eva['javascript'] = new eva_javascript;
$eva['javascript']->config("inicio");
?>
/* TinyMCE */
tinyMCE.init({
	mode : "textareas",
	editor_selector : "mceEditor",
	theme : "advanced",	
	language : "<?php echo (empty($config['idioma_padrao'])||$config['idioma_padrao']=="br")?"pt_br":$config['idioma_padrao'];?>",
<?php
	if(empty($_GET['tipo'])){
?>
	plugins : "table,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,flash,searchreplace,print,paste,fullscreen,contextmenu,filemanager,imgmanager,pagebreak",
	theme_advanced_buttons1 : "undo,redo,separator,cut,copy,paste,pastetext,pasteword,separator,search,replace,separator,newdocument,cleanup,removeformat,separator,charmap,insertdate,inserttime,emotions,advhr",
	theme_advanced_buttons2 : "iespell,separator,help,code,visualaid,separator,print,preview,fullscreen,justifyleft,justifycenter,justifyright,justifyfull,separator,bullist,numlist,separator,outdent,indent,separator,bold,italic,underline,strikethrough",
	theme_advanced_buttons3 : "tablecontrols,separator,pagebreak,imgmanager,flash,filemanager,separator,link,unlink,anchor",
	theme_advanced_buttons4 : "sub,sup,separator,forecolor,backcolor,separator,formatselect,fontselect,fontsizeselect",
<?php
	// tipo simples ver eva_form.php linha 510 e eva_javascript.php linha 54
	}else{
?>
	plugins : "",
	theme_advanced_buttons1 : "undo,redo,separator,cut,copy,paste,pastetext,pasteword,separator,newdocument,cleanup,removeformat,separator,charmap,insertdate,inserttime,emotions,advhr,separator,bold,italic,underline,strikethrough",
	theme_advanced_buttons2 : "",
	theme_advanced_buttons3 : "",
	theme_advanced_buttons4 : "",
<?php
	}
?>
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	plugin_insertdate_dateFormat : "%Y-%m-%d",
	plugin_insertdate_timeFormat : "%H:%M:%S",
	extended_valid_elements : "hr[class|width|size|noshade]",
	external_link_list_url : "example_link_list.js",
	external_image_list_url : "example_image_list.js",
	flash_external_list_url : "example_flash_list.js",
	file_browser_callback : "fileBrowserCallBack",
	theme_advanced_statusbar_location : "bottom",
	auto_reset_designmode : true,
	theme_advanced_resizing : true,	
	theme_advanced_resize_horizontal : true,
	theme_advanced_source_editor_width : "700"
});

/* Opcoes removidas

	theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",	
	paste_use_dialog : false,
	auto_resize : true,
	plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,flash,searchreplace,print,paste,directionality,fullscreen,noneditable,contextmenu,filemanager,imgmanager",
	
	// Estilo do conteudo
	
	// Para corrigir falhas em abas
	
	// Armazena os dados caso saia da pagina (nao funciona...)
	add_unload_trigger : true,
	
	// Para carregar mais rapido, mas nao funciona com alguns Doctypes
	button_tile_map : true,

*/

function fileBrowserCallBack(field_name, url, type, win) {
	// This is where you insert your custom filebrowser logic
	alert("Example of filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);
	var template = new Array();
	template['file']   = '../../plugins/filemanager/insertfile/insert_file.php'; // Relative to theme
	template['width']  = 660;
	template['height'] = 500;

	tinyMCE.openWindow(template, {field_name : field_name});
	
	// Insert new URL, this would normaly be done in a popup
	win.document.forms[0].elements[field_name].value = "someurl.htm";
}
/* TinyMCE */
<?php
$eva['javascript']->config("fim");
?>