<?php
/**
* @package evacms
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html  LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
?>
// Plugins
HTMLArea.loadPlugin("ImageManager");
HTMLArea.loadPlugin("TableOperations");
HTMLArea.loadPlugin("ListType");
HTMLArea.loadPlugin("InsertFile");

// Configura��o padr�o para os editores
var config = new HTMLArea.Config();

config.height = '300px';
config.width = '380px';
config.sizeIncludesToolbar = false; 
config.pageStyle =
	'body { background-color: #F5F5F5; color: black; font-family: verdana,sans-serif; font-size: 11px } ' +
	'p { font-width: bold; } ';
config.statusBar = false;
config.killWordOnPaste = true;
config.toolbar = [  
	[ 'forecolor','hilitecolor', 'separator','copy', 'cut', 'paste', 'separator', 'undo', 'redo',
	'separator', 'htmlmode', 'separator',
	'createlink', 'inserttable', 'inserthorizontalrule','insertimage',
	],
	[ 'justifyleft',
	'justifycenter', 'justifyright','justifyfull', 'separator', 
	'outdent', 'indent', 'orderedlist', 'unorderedlist'
	],
	[ 'bold', 'italic', 'underline', 'strikethrough', 'separator', 'subscript', 'superscript', 
	'separator', 'space', 'fontname', 'space', 'fontsize', 'space'], 
	];