function _gel(a){
	return document.getElementById(a);
}
function _uc(a){
	return a.toUpperCase();
}
function _esc(a){
	return escape(a);
}
function _uhc(a,c){
	_gel(a).value=c;
	_gel(a).disabled=false;
}

var k=[];
var p=0;
var n=null;

function h(){
	if(!n){
		n=document.createElement("DIV");
		n.style.display="none";
		n.style.position="absolute";
		n.style.cursor="move";
		n.style.border="2px solid #999999";
		document.body.appendChild(n);
	}
	return n
}

var m={
	"obj":null,
	"init":function(a){
		a.onmousedown=m.start;
		if(isNaN(parseInt(h().style.left)))h().style.left="0px";
		if(isNaN(parseInt(h().style.top)))h().style.top="0px";
		a.onDragStart=new Function();
		a.onDragEnd=new Function();
		a.onDrag=new Function()
	},
	"start":function(a){
		var c=m.obj=this;
		a=m.fixE(a);
		var b=parseInt(h().style.top);
		var e=parseInt(h().style.left);
		c.onDragStart(e,b,a.clientX,a.clientY);
		c.lastMouseX=a.clientX;
		c.lastMouseY=a.clientY;
		document.onmousemove=m.drag;
		document.onmouseup=m.end;
		return false
	},
	"drag":function(a){
		a=m.fixE(a);
		var c=m.obj;
		var b=a.clientY;
		var e=a.clientX;
		var f=parseInt(h().style.top);
		var i=parseInt(h().style.left);
		var j,g;
		j=i+e-c.lastMouseX;
		g=f+b-c.lastMouseY;
		h().style.left=j+"px";
		h().style.top=g+"px";
		c.lastMouseX=e;
		c.lastMouseY=b;
		c.onDrag(j,g,a.clientX,a.clientY);
		return false
	},
	"end":function(){
		document.onmousemove=null;
		document.onmouseup=null;
		m.obj.onDragEnd(parseInt(h().style.left),parseInt(h().style.top));
		m.obj=null
	},
	"fixE":function(a){
		if(typeof a=="undefined")a=window.event;
		if(typeof a.layerX=="undefined")a.layerX=a.offsetX;
		if(typeof a.layerY=="undefined")a.layerY=a.offsetY;
		return a
	}
};
function _initDrag(a){
	k=a;
	for(var c=0;c<k.length;c++){
		for(var b=0;b<k[c].childNodes.length-1;	b++){
			var e=k[c].childNodes[b];
			if(e.id){
				var f=document.getElementById(e.id+"_h");
				f.module=e;
				m.init(f);
				f.onDragStart=function(i,j){
					clearInterval(p);
					var g=this.module;
					r(g);
					g.origNextSibling=g.nextSibling;
					var l=h();
					l.style.left=o(g,true);
					l.style.top=o(g,false);
					l.style.height=g.offsetHeight;
					l.style.width=g.offsetWidth;
					l.style.display="block";
					this.dragged=false;
				};
				f.onDrag=function(i,j){
					t(this.module,i,j);
					this.dragged=true;
				};
				f.onDragEnd=function(i,j){
					if(this.dragged){
						p=s(this.module,150,15);
					}else{
						q();
					}
					if(this.module.nextSibling!=this.module.origNextSibling){
						v();
					}
				}
			}
		}
	}
}
function q(){
	h().style.display="none";
}
function s(a,c,b){
	var e=parseInt(h().style.left);
	var f=parseInt(h().style.top);
	var i=(e-o(a,true))/b;
	var j=(f-o(a,false))/b;
	return setInterval(function(){
		if(b<1){
			clearInterval(p);
			q();
			return
		}
		b--;
		e-=i;
		f-=j;
		h().style.left=parseInt(e)+"px";
		h().style.top=parseInt(f)+"px"
	},c/b)
}
function r(a){
	for(var c=0;c<k.length;c++){
		var b=0;
		for(var e=0;e<k[c].childNodes.length;e++){
			var f=k[c].childNodes[e];
			if(f==a)b=f.offsetHeight;
				f.pagePosLeft=o(f,true);
				f.pagePosTop=o(f,false)-b
			}
		}
	}
	function o(a,c){
		var b=0;
		while(a!=null){
			b+=a["offset"+(c?"Left":"Top")];
			a=a.offsetParent
		}
		return b
	}
	function t(a,c,b){
		var e=null;
		var f=100000000;
		for(var i=0;i<k.length;i++){
			for(var j=0;j<k[i].childNodes.length;j++){
				var g=k[i].childNodes[j];
				if(g==a)continue;
				var l=Math.sqrt(Math.pow(c-g.pagePosLeft,2)+Math.pow(b-g.pagePosTop,2));
				if(isNaN(l))continue;
				if(l<f){
					f=l;
					e=g
				}
			}
		}
		if(e!=null&&a.nextSibling!=e){
			e.parentNode.insertBefore(a,e);
			u(a)
		}
	}
	function u(a){
		a.parentNode.style.display="none";
		a.parentNode.style.display=""
	}
	var _et="";
	function v(){
		var a="";
		// variaveis q eu criei
		eva_pos="";
		eva_ord="";
		eva_id="";
		for(var c=0;c<k.length;c++){			
			for(var b=0;b<k[c].childNodes.length-1;b++){				
				var e=k[c].childNodes[b];				
					if(e.id){
						a+=a!=""?":":"";
						a+=e.id.substring(2)+"_"+e.parentNode.id.substring(0,1);
						// muda o id do objeto
						// se a posicao for igual e a ordem do bloco for menor que a do anterior fa�a o update
						eva=e.id.split("_");
						eva[2]*=1;
						if(e.parentNode.id==eva_pos && eva[2]<eva_ord){
							e2=document.getElementById(eva_id);
							eva2=eva_id.split("_");							
							document.getElementById(e.id).id="m_"+eva[1]+"_"+eva2[2];
							titulo=document.getElementById("t_"+eva[1]+"_"+eva[2]);
							titulo2 = titulo.innerHTML.split("[");
							titulo.innerHTML = titulo2[0]+"["+eva[1]+"_"+eva2[2]+"]";
							titulo.id="t_"+eva[1]+"_"+eva2[2];
							document.getElementById(eva_id).id="m_"+eva2[1]+"_"+eva[2];
							titulo=document.getElementById("t_"+eva2[1]+"_"+eva2[2]);
							titulo2 = titulo.innerHTML.split("[");
							titulo.innerHTML = titulo2[0]+"["+eva2[1]+"_"+eva[2]+"]";
							titulo.id="t_"+eva2[1]+"_"+eva[2];
							eva[2]=eva_ord;
						}
						eva_pos=e.parentNode.id;
						eva_ord=eva[2];
						eva_id=e.id;
						//acaba aqui
					}
					
			}
		}
		executar_comando('GET', "index.php?modulo=eva_bloco&comando=mover_bloco_xmlhttpr&lista_blocos="+a, true, '', '', '');					
	}
	function _ListApp(){
	
	}
	_ListApp.prototype.init=function(a,c,b,e,f,i,j,g){
		this.items=a;
		this.items.id="r";
		this.ditems=c;
		this.ditems.id="d";
		this.module_id=b;
		this.variable_name=e;
		this.item_name_prefix="m_"+b+"_li_";
		this.display_area=f;
		this.value_input_field=i;
		this.add_button=j;
		this.max_items=g
	};
	_ListApp.prototype.sort=function(a,c){
		var b=_uc(a[0]);
		var e=_uc(c[0]);
		if(b<e)return-1;if(b>e)return 1;return 0
	};
	_ListApp.prototype.num_enabled=function(a){
		var c=0;
		for(var b=0;b<a.length;b++){
			if(a[b][2]){
				c++;
			}
		}
		return c
	};
	_ListApp.prototype.disable_unchecked_items=function(a,c){
		for(var b=0;b<a.length;b++){
			_gel(this.item_name_prefix+a.id+b).disabled=c&&!a[b][2]
		}
	};
	_ListApp.prototype.refresh_h=function(a){
		var c="";for(var b=0;b<a.length;b++){
		var e=a[b][0];
		var f=a[b][1];
		var i=a[b][2];
		var j=a[b][3];
		var g=this.item_name_prefix+a.id+b;
		var l=_esc(this.item_name_prefix+e);
		if(j){
			c+='<input type=hidden name="'+l+'" value="'+(i?_esc(f):"")+'">';
		}
		c+="<input type=checkbox id="+g+(i?" checked":"")+' onClick="'+this.variable_name+".update('"+g+"')\">"+e.replace(/</g,"&lt;").replace(/>/g,"&gt;")+"<br>";
	}
	return c;
};
_ListApp.prototype.refresh=function(){
	this.items.sort(this.sort);this.ditems.sort(this.sort);this.display_area.innerHTML="<font size=-1>"+this.refresh_h(this.items)+this.refresh_h(this.ditems)+"</font>";var a=this.num_enabled(this.items)+this.num_enabled(this.ditems)>=this.max_items;this.value_input_field.disabled=a;this.add_button.disabled=a;this.disable_unchecked_items(this.items,a);this.disable_unchecked_items(this.ditems,a)
};
_ListApp.prototype.add_h=function(a,c){
	for(var b=0;b<a.length;b++){
		if(_uc(a[b][1])==_uc(c)){
			a[b][1]=c;a[b][2]=1;a[b][3]=1;return true
		}
	}
	return false
};
_ListApp.prototype.add=function(){
	var a=this.value_input_field.value.replace(/^\s*|\s*$/g,"");
	if(a=="")return;
	if(!this.add_h(this.ditems,a)){
		if(!this.add_h(this.items,a)){
			this.items[this.items.length]=[a,a,1,1]
		}
	}
	this.refresh();
	this.value_input_field.value="";
	this.value_input_field.focus();
	d(this.module_id)
};
_ListApp.prototype.update_h=function(a,c){
	for(var b=0;b<a.length;b++){
		if(this.item_name_prefix+a.id+b==c){
			a[b][2]=_gel(c).checked?1:0;a[b][3]=1
		}
	}
};
_ListApp.prototype.update=function(a){
	this.update_h(this.ditems,a);
	this.update_h(this.items,a);
	this.refresh();
	d(this.module_id)
}