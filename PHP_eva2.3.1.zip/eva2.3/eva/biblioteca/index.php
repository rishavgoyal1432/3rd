<?php
/*	
+-----------------------------------------------------------------------------+
| EVA - Sistema Gerenciador de Conte�do                                       |
| Copyright (c) 2004 EVA CMS (www.evacms.com.br)                              |
+-----------------------------------------------------------------------------+
| Este programa � de c�digo livre e pode ser redistribu�do ou modificado      |
| sob os termos da GNU General Public License como publicado pela Free        |
| Software Foundation; segundo a vers�o 2 da licen�a ou vers�o atualizada.    |
+-----------------------------------------------------------------------------+
| PHP vers�o 4.3.7                                                            |
+-----------------------------------------------------------------------------+
| Data de Cria��o: Julho de 2004                                              |
| Autores:                                                                    |
| - Alessandro Nunes (alessandro@evacms.com.br, alessandro.rpgrock.net)       |
| - Daniel Neto (daniel@evacms.com.br, www.danielneto.com)                    |
+-----------------------------------------------------------------------------+
| Arquivo: index.php                                                          |
| Descri��o: Arquivo para bloquear o acesso � listagem de arquivos da pasta.  |
+-----------------------------------------------------------------------------+
*/
?>