<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_usuario_online{
	
	function usuarios_online($tipo="online", $quantidade=20, $usuario_cod=""){
		global $config;
		global $eva;
		$tempo_limite = 60; // tempo em segundos
		//$tempo_limite = $config['tempo_limite']; // tempo em minutos
		// para saber se o usu�rio est� online
		
		if($usuario_cod != ""){
			$sql = "SELECT us_cod
				FROM 
					".$config['bdprefixo']."_eva_usuario
				WHERE
					us_cod = ".intval($usuario_cod)."
				AND
					us_ultimo_clique > ".(mktime()-($tempo_limite));
			$rs = $eva['sql']->executar($sql);
			if($rs->RecordCount()){
				return true;
			}
			return false;
		}
		$usuarios = array();
		
		if($tipo=="sessoes"){
			// varre as sessoes e ve as ultimas sessoes criadas
			if ($handle = opendir(ini_get("session.save_path"))) {
				$usuarios=0;
				if (eregi( "/", ini_get("session.save_path"))){
					$separador_diretorio = "/";
				}else{
					$separador_diretorio = "\\";
				}
				while (false !== ($file = readdir($handle))) {
					if(mktime()-@fileatime(ini_get("session.save_path").$separador_diretorio.$file)<$tempo_limite and $file!="." and $file!=".."){
						$usuarios++;
						//echo "<br> = ".ini_get("session.save_path").$separador_diretorio.$file;
					}
				}
				closedir($handle);
			}
		}else{
			if($tipo=="online"){
				$sinal=">";
				$limite=" ORDER BY  us_nomecom DESC";
			}else{
				$sinal="<";
				$limite="ORDER BY us_ultimo_clique DESC";
			}
			// SQL para listar os usuarios cadastrados	
			$sql = "SELECT DISTINCT
					us_cod, us_nomecom, us_nome, us_sobrenome, us_ultimo_clique
				FROM 
					".$config['bdprefixo']."_eva_usuario
				WHERE
					us_cod != ".intval($_SESSION['us_cod'])."
				AND
					us_ultimo_clique {$sinal} ".(mktime()-($tempo_limite))."
				{$limite}";
			$rs = $eva['sql']->executar($sql,false,$quantidade);
			if($rs){
				while ($linha = $rs->FetchRow()){
					$usuarios[]=$linha;
				}
			}
		}
		return $usuarios;
	}
	
	// Retorna informa��es de um usuario online especifico
	function usuario_info($us_cod){	
		global $config;
		$sql = "SELECT 
				*
			FROM 
				".$config['bdprefixo']."_eva_usuario
			WHERE
				us_cod = ".$us_cod;
		$rs = $eva['sql']->executar($sql);
		if($rs){
			if ($linha = $rs->FetchRow()){
				return $linha;
			}
		}
		return false;
	}
	
	function desconectar_usuario_online($us_cod, $mensagem = ""){
		global $config;
		$usuario = usuario_info($us_cod);
		if ($usuario){
			if ($usuario['US_SESSAO_NOME'] != session_id()){			
				if (eregi( "/", ini_get("session.save_path"))){
					$separador_diretorio = "/";
				}else{
					$separador_diretorio = "\\";
				}
				$apagar = @unlink(ini_get("session.save_path").$separador_diretorio."sess_".$usuario['US_SESSAO_NOME']);
				if($mensagem != "" and $apagar){
					$data_validade = mktime()+3600;
					$me_cod = $eva['sql']->selecionar_maior("eva_mensagem","me_cod");
					$grupos = "";
					$sql = "INSERT INTO ".$config['bdprefixo']."_eva_mensagem
						(me_cod, 
						me_us_cod,
						me_autor_us_cod,
						me_remetente,
						me_mensagem,
						me_grupo, 
						me_data,
						me_data_validade) 
					VALUES 
						('".$me_cod."',
						'".$us_cod."',
						NULL,
						'Administrador',
						'".$eva['seguranca']->tratar_seguranca($mensagem)."',
						'".$grupos."',
						'".mktime()."',
						".$data_validade.")";
					$rs = $eva['sql']->executar($sql);
				}
			}
		}
	}
} //eva_usuario_online
?>