<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_incluir{
	/**
	 * Inclui e cria uma classe se ela ainda nao existe
	 *
	 */
	function incluir(){
		global $eva;
		$arg_lista = func_get_args();
		for ($i = 0; $i < count($arg_lista); $i++) {
			// coloquei isso pq tinha alguns modulos que estavam chamando isso nao sei pq
			if($arg_lista[$i]=="modulo") continue;
			// se nao tiver sido inicializado o objeto inicia-se agora
			if(!isset($eva[$arg_lista[$i]]) or !is_object($eva[$arg_lista[$i]])){
				$eva[$arg_lista[$i]]=$this->incluir_new($arg_lista[$i]);
			}
		}
	}
	
	/**
	 * Inclui e cria uma nova instancia
	 *
	 */
	function incluir_new($classe){
		global $eva;
		$arq="eva_".$classe;
		require_once($arq.".php");
		// eval("unset(\$eva[\$arg_lista[\$i]]);");
		eval("\$t=new {$arq}();");
		return $t;
	}
	
	/**
	 * Inclui a classe de um modulo
	 *
	 */
	function incluir_modulo(){
		global $eva, $config, $idioma;
		$arg_lista = func_get_args();
		for ($i = 0; $i < count($arg_lista); $i++) {
			// se nao tiver sido inicializado o objeto inicia-se agora
			if(!isset($eva[$arg_lista[$i]]) or !is_object($eva[$arg_lista[$i]])){				
				$eva['modulo_'.$arg_lista[$i]]=$this->incluir_modulo_new($arg_lista[$i]);				
			}
		}
	}
	
	/**
	 * Inclui uma nova instancia da classe de um modulo
	 *
	 */
	function incluir_modulo_new($classe){	
		global $eva, $config, $idioma;	
		$arq="modulos/".$classe."/eva_classe.php";
		@chdir($eva['caminho_eva']);
		if(file_exists($arq)){
			require_once($arq);
			if(empty($config['idioma_padrao'])) $config['idioma_padrao']="en";
			require("modulos/".$classe."/idiomas/{$config['idioma_padrao']}.php");	
			eval("\$t=new {$classe}();");
			return $t;
		}			
	}
}
?>
