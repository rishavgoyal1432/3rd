<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

$eva['incluir']->incluir("geral");

class eva_busca{
	var $total;
	/**
	 * construtor
	 *
	 * @return eva_busca
	 */
	function eva_busca(){
		$this->total = 0;
	}
	/**
	 * exibe busca
	 *
	 * @param array $array
	 * @return string
	 */
	function exibir(&$array){
		global $eva_busca_global;
		global $e_busca;
		global $eva;
		global $idioma;
		$resposta=false;
		if($array['total'] > 0){
			// esta variavel define se a busca foi feita
			$e_busca=true;
			$resposta="<div style=\"width:100%\">
						<div class=\"formulario_titulo\">
							<div style=\"float: right\">
								".$idioma['total'].": ".$array['total']."
							</div>
							<img src=\"{$eva_busca_global['mo_icone']}\" border=\"0\" align=\"middle\" hspace=\"5\"> <strong>{$eva_busca_global['mo_nome']}</strong>
						</div>
						<div class=\"formulario_titulo\" width=\"100%\"><br />";
			unset($array['total']);
			unset($array['mo_nome']);
			unset($array['mo_desc']);
			$linha = $eva['geral']->alterna_linha("linha1");
			for($i=0;$i<count($array['url']);$i++){
				$this->total ++;
				$resposta.="<table class=\"".$eva['geral']->alterna_linha()."\" width=\"100%\"><tr><td>
								<a href=\"{$array['url'][$i]}\">".$array['titulo'][$i]."</a>
								<div class=\"font_texto\">
									".$array['descricao'][$i]."
								</div>
								<br />
							</td></tr></table>";
			}
			$resposta.="</div></div>";
		}
		$array=array();
		return $resposta;
	}
}
?>
<div style=" display:inline-table"></div>