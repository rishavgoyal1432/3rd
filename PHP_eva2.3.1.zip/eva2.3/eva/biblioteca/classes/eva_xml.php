<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
 * classe domit para gerar o xml
 *
 */
include_once('domit/xml_domit_include.php');


/**
 * Classe do Eva usando o domit para parse xml
 *
 */
class eva_xml extends DOMIT_Document {	
	/**
	 * Objeto contendo o XML na instancia
	 *
	 * @var unknown_type
	 */
	var $xml;
	/**
	 * Para codificar UTF-8
	 *
	 * @var unknown_type
	 */
	var $codificar;
	
	/**
	 * Construtor
	 *
	 * @return eva_xml
	 */
	function eva_xml(){
		parent::DOMIT_Document();
		$this->codificar = true;
	}
	
	/**
	 * Gera vetor
	 *
	 * @return array
	 */
	function gerar_vetor(){
		$vetor = $this->toArray();
		return (isset($vetor['#document'][0]))? $vetor['#document'][0] : array();
		//return DOMIT_Lite_Document::toArray();
	}
	
	/**
	 * apaga o item do xml
	 *
	 */
	function apagar(){
		while($this->documentElement->childCount > 0){
			$this->documentElement->firstChild;
			$this->documentElement->removeChild($this->documentElement->firstChild);
		}
	}
	
	/**
	 * pega a tag solicitada pela variavel
	 *
	 * @param string $tag
	 * @return eva_xml
	 */
	function pegar_elemento($tag){
		return $this->getElementsByTagName($tag);
	}
	
	/**
	 * Verifica a cria��o do objeto eva_xml e configura codificacao
	 *
	 */
	function verificar_obj($tag='<eva_xml></eva_xml>'){		
		if(!isset($this->documentElement) || $this->documentElement == null || $tag!='<eva_xml></eva_xml>'){
			if( $tag!='<eva_xml></eva_xml>'){
				//$this = new eva_xml;
			}
			$this->parseXML($tag, true);
		}
	}
	/**
	 * se vai codificar UTF-8 ou nao
	 *
	 * @param bool $codificar
	 */
	function codificar($codificar = true){
		$this->codificar = $codificar;
	}
	
	/**
	 * retorna uma string com o xml
	 *
	 * @return string
	 */
	function exibir(){
		return $this->toString();
	}
	
	/**
	 * Faz o parse em um rss
	 *
	 * @param int $total
	 * @return array
	 */
	function pegar_rss($total){
		// pega todos os itens
		global $eva;
		$itens=$this->getElementsByTagName("item");
		$total_itens = $itens->getLength();
		$arr_rss = array();
		for($i=0;($i<$total_itens and $i<$total); $i++){
			$item=$itens->item($i);
			// pega os itens do rss
			$x_titulo = $item->getElementsByTagName("title");			
			$x_links = $item->getElementsByTagName("link");			
			$x_desc = $item->getElementsByTagName("description");
			$x_data = $item->getElementsByTagName("pubDate");
			$x_autor = $item->getElementsByTagName("author");				
			
			if($x_titulo->getLength()){
				$i_titulo=$x_titulo->item(0);
				$arr_rss[$i]['titulo'] = $eva['geral']->utf8($i_titulo->getText());
			}else{$titulo = "";}
			if($x_links->getLength()){
				$i_links = $x_links->item(0);
				$arr_rss[$i]['link'] = $eva['geral']->utf8($i_links->getText());
			}else{$link = "";}
			if($x_titulo->getLength()){
				$i_desc = $x_desc->item(0);
				$arr_rss[$i]['desc'] = $eva['geral']->utf8($i_desc->getText());
			}else{$titulo = "";}
			if($x_data->getLength()){
				$i_data = $x_data->item(0);
				$arr_rss[$i]['data'] =$eva['geral']->utf8($i_data->getText());
			}else{$data = "";}
			if($x_autor->getLength()){
				$i_autor = $x_autor->item(0);
				$arr_rss[$i]['autor'] = $eva['geral']->utf8($i_autor->getText());				
			}else{$autor = "";}
		}
		return $arr_rss;
	}
	
	/**
	 * Cria elemento com o nome indicado caso a variavel texto nao seja vazia associa o valor ao elemento criado
	 *
	 * @param string_type $nome
	 * @param string $texto
	 * @return object
	 */
	function criar_elemento($nome, $texto=""){
		global $eva;
		$obj = $this->createElement($nome);
		if(!empty($texto)){
			$eva['seguranca']->codificar_get_eva($texto);
			$texto = ($this->codificar)? utf8_encode($this->remover_xml_especial_char($texto)) : $texto;
			$obj->setText($texto);
		}
		return $obj;
	}
	
	/**
	 * Cria elemento com o nome indicado caso a variavel texto nao seja vazia associa o valor ao elemento criado e ja associa ao pai
	 *
	 * @param string $nome
	 * @param string $texto
	 * @param object $pai
	 * @return object
	 */
	function criar_elemento_com_pai($nome, $texto="", &$pai){
		$obj=$this->criar_elemento($nome, $texto);
		if(is_object ($pai)){
			$pai->appendChild($obj);
		}
		return $obj;
	}
	
	/**
	 * Colocar atributo 
	 *
	 * @param string $nome nome do atributo
	 * @param string $valor valor do atributo
	 * @param object $elemento objeto do elemento
	 */
	function colocar_atributo($nome, $valor, &$elemento){
		global $eva;
		$eva['seguranca']->codificar_get_eva($valor);
		$valor = ($this->codificar)? utf8_encode($this->remover_xml_especial_char($valor)) : $valor;
		$elemento->setAttribute($nome, $valor);
	}
	
	/**
	 * coloca o elemento como filho do pai
	 *
	 * @param object $elemento
	 * @param object $pai
	 */
	function colocar_no_pai(&$elemento, &$pai){
		if(is_object ($pai)){
			$pai->appendChild($elemento);
		}
	}
	
	/**
	 * coloca o item no root do xml
	 *
	 * @param object $filho
	 */
	function colocar_no_root(&$filho){
		global $eva;
		// coloca site dentro do body eva_xml
		$this->documentElement->appendChild($filho);
	}
	
	/**
	 * carrega o xml de um arquivo
	 *
	 * @param string $arquivo endere�o do arquivo
	 * @return eva_xml
	 */
	function carregar_xml($arquivo){	
		return $this->loadXML($arquivo);
	}
	
	/**
	 * Conta quantos filhos tem
	 *
	 * @return object
	 */
	function conta_elementos_filho(){
		return $this->documentElement->childCount;
	}
	
	
	/**
	 * Cria uma resposta XML no root, a resposta � dividida em tags menores para concertar um bug do ajax no Firefox
	 *
	 * @param string $resp
	 * @param string $tag
	 */
	function criar_resposta($resp, $tag = "r"){
		if (!empty($resp))
			$r = explode("[)(]", $this->preserve_wordwrap($resp, 2000, "[)(]"));
		else
			$r=array();
		$xml2 = $this->criar_elemento("resposta");
		for($i=0; $i<count($r); $i++){//echo $r[$i];
			if(!empty($r[$i]))
				$this->criar_elemento_com_pai($tag , $r[$i], $xml2);
		}
		$this->colocar_no_root($xml2);
		$xml3 = $this->criar_elemento("resposta_tag", $tag);
		$this->colocar_no_root($xml3);
	}
	
	/**
	 * Cria uma resposta XML apartir do include de um arquivo
	 *
	 * @param string $arquivo
	 * @param string $tag
	 * @param string $pasta_arquivos
	 */
	function criar_resposta_include($arquivo, $tag = "r", $pasta_arquivos=false){
		global $eva, $config, $idioma;
		//ob_clean();
		@ob_end_clean();
		 $eva['seguranca']->inicia_ob_start(false);
		 
		 @chdir($eva['caminho_eva']);
		//echo getcwd();	
		//echo $arquivo;
		
		//var_dump($arquivo);exit;
		if($pasta_arquivos)
			@chdir($eva['caminho']);		
		
		require($arquivo);
		
		if($pasta_arquivos)
			@chdir($eva['caminho_eva']);
		
		$resp = ob_get_contents();
		ob_clean();
		 $eva['seguranca']->inicia_ob_start(false);
		//ob_end_clean();
		//var_dump($resp);exit;
		$this->criar_resposta($resp, $tag);
	}
	
	/**
	 * If you attempt to wordwrap() lines that already contain some line-breaks that you want to maintain
	 *
	 * @param string $tstr
	 * @param int $len
	 * @param string $br
	 * @return string
	 */
	function preserve_wordwrap($tstr, $len = 75, $br = '\n') {
		 $tstr = str_replace( "<img", $br."<img", $tstr);	
		 $strs = explode($br, $tstr);
		 $retstr = "";
		 foreach ($strs as $str) {
			 $retstr .= wordwrap($str,$len,$br) . $br;
		 }
		// echo $tstr;
		 return $retstr;
	}
	
	/**
	 * Limpa o xml
	 *
	 * @param string $html_replace
	 * @return string
	 */
	function remover_xml_especial_char($html_replace){
		global $eva;
		//$chars = array("&","<", ">", '"', chr(27)); // chr(27); escape charactere
		$chars = array("&","<", ">", '"');
		$entit = array("&amp;","&lt;", "&gt;", "&quot;");
		$eva['incluir']->incluir("carregar");	
		$html_replace = ereg_replace("[^".chr(31)."-".chr(255)."]"," ",$html_replace); // remove qq caractere q nao seja ascii
		$eva['carregar']->tratar_exibir($html_replace);
		$html_replace = str_replace($chars, $entit, $html_replace);
		//$html_replace = ereg_replace("[^([:alnum:]||;|,|'|&|\s)+]","",$html_replace);
		//return trim(str_replace($chars, $entit, $html_replace));
		return $html_replace;
		//return trim(htmlentities($html_replace, ENT_QUOTES));
	}
}
?>
