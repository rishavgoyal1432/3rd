<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

$eva['incluir']->incluir("aba");
$eva['incluir']->incluir_modulo("eva_menu");

class eva_grade{
	/**
	 * Fun��o para criar grades em javascripts
	 *
	 * @param array $grade
	 * @return string
	 */
	function grade(&$grade){
		return $this->grade_tabela($grade);
	}
	
	/**
	 * Limpa o html para colocar na grade
	 *
	 * @param string $msg
	 * @return string
	 */
	function grade_html($msg){
	
		$msg = addslashes($msg);
		$msg = str_replace("\n", "\\n", $msg);
		$msg = str_replace("\r", "\\r", $msg);
		//$msg = htmlspecialchars($msg);
	
		return $msg;
	}
	
	/**
	 * Cria uma grade usando tabelas html
	 *
	 * @param array $grade
	 * @return string
	 */
	function grade_tabela(&$grade, $nenhum_item=true){
		global $idioma;
		global $eva;
		
		$num = $eva['contador']++;
		$grade['dados']           = (isset($grade['dados']))           ? $grade['dados']:array();
		$grade['campos']          = (isset($grade['campos']))          ? $grade['campos']:array();
		$grade['altura']          = (isset($grade['altura']))          ? $grade['altura']:"";
		$grade['selecionar']      = (isset($grade['selecionar']))      ? $grade['selecionar']:false;
		$grade['selecionar_tipo'] = (isset($grade['selecionar_tipo'])) ? $grade['selecionar_tipo']:"radio";
		$grade['menu']            = (isset($grade['menu']))            ? $grade['menu']:array();
		$grade['onchange']        = (isset($grade['onchange']))        ? $grade['onchange']:"";
        $grade['exibe_cabecalho'] = (isset($grade['exibe_cabecalho'])) ? $grade['exibe_cabecalho'] : 1;

		$colunas_num = count($grade['campos']);
		$linhas_num  = count($grade['dados']);
		$largura     = array();
		$linhas_max  = 0;
		
		$html = '<!-- grade_tabela --><table width="100%" border="0" cellpadding="3" cellspacing="0">';
		if ($grade['exibe_cabecalho'] == 1) {
		  	$html .= '<tr class="linha_destaque" style="font-weight:bold ">';
			// Imprime os titulos
			for($i=0;$i<$colunas_num;$i++){				
				$onmouseover = '';
				$onclick = '';
				$onmouseout = '';
				if(is_array($grade['campos'][$i])){
					
					$get = $_GET;
					//replace the mktime from the end and add a new mktime, this is to make an unique url and allways run the javascript
					$get['mktime'] = mktime();
					$get['orderby'] = $grade['campos'][$i][1];
					$get['orderby_direction'] = (!empty($get['orderby_direction'])&&$get['orderby_direction']=="ASC")?"DESC":"ASC";
					$img = "";
					if(!empty($_GET['orderby']) && $_GET['orderby'] == $get['orderby']){
						$img = '<img src="imagens/sort_'.((!empty($get['orderby_direction'])&&$get['orderby_direction']=="ASC")?"up":"dw").'.gif" border="0" hspace="10" width="8" height="7" />';
						$sort = true;
					}else{
						$img = '<img src="imagens/sort.gif" border="0" hspace="10" width="8" height="7" />';
						$sort = false;
					}
					
					$get_novo = $eva['geral']->http_build_query($get);
					
					$onmouseout = 'this.className="'.(empty($sort)?'grid_title_normal':'grid_title_selecionado').'"';				
					if(!empty($_GET['ajax_funcao'])){
						$campo = "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td nowrap=\"nowrap\"><b>{$grade['campos'][$i][0]}</b></td><td>{$img}</td></tr></table>";						
						$onmouseover = 'this.style.cursor=eva_mouseover;this.className="grid_title_sobre"';
						$onclick = 'javascript: '.$_GET['ajax_funcao'].'("index.php?'.$get_novo.'");return false;';
					}else{
						$campo = "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td nowrap=\"nowrap\">".'<a href="index.php?'.$get_novo.'"><b>'.$grade['campos'][$i][0].'</b></a>'."</td><td>{$img}</td></tr></table>";
						$onmouseover = 'this.style.cursor=eva_mouseover;';
						$onclick = 'javascript: this.location = "index.php?'.$get_novo.'"';
					}
				}else{
					$campo = $grade['campos'][$i];
				}
				$width = !empty($grade['largura'][$i])?"width=\"{$grade['largura'][$i]}\"":"";
				$html .= "<td $width class='".(empty($sort)?'grid_title_normal':'grid_title_selecionado')."' onMouseOver='{$onmouseover}' onclick='{$onclick}' onmouseout='{$onmouseout}' >{$campo}</td>";
				$img = "";
			}
			$html .= '</tr>';
                }
		// imprime o conteudo
		$checked = $grade['selecionar_tipo']=="radio"?"checked":"";
		$itens_cont=0;
		$id_extra = rand(1, 100);// porque no comando nao tem como saber quantas grades existem
		for($i=0;$i<$linhas_num;$i++){
			$linha_id=$grade['selecionar']."_".$i."_".$num."_".$id_extra;
			$html .= "<tr class=\"linha".(($i%2)+1)."\" onmouseover=\"destacar(this);\" onmouseout=\"destacar(this);\" height=\"{$grade['altura']}\">";			
			$tdscript = "";
			for($j=0;$j<$colunas_num;$j++){
				if(isset($grade['selecionar']) && $grade['selecionar'] && $j==0 && !empty($grade['dados'][$i][$j])){
					//$tdscript = "onMouseUp=\"eva_elem('$linha_id').checked=!eva_elem('$linha_id').checked\"";
					if($grade['selecionar_tipo']!="radio")
						$checked = (!empty($grade['selecionados']) && in_array($grade['dados'][$i][$j], $grade['selecionados']))?"checked":"";
					$tdscript = "onMouseUp=\"check_uncheck('$linha_id');{$grade['onchange']}\"";
					$grade['dados'][$i][$j] = "<input type=\"".$grade['selecionar_tipo']."\" id=\"$linha_id\" name=\"".$grade['selecionar'].($grade['selecionar_tipo']!="radio"?"[]":"")."\" value=\"".$grade['dados'][$i][$j]."\" {$checked} ".(empty($grade['onchange'])?"":" onchange=\"{$grade['onchange']}\" ")." />";
					$checked="";
				}
				$html .= "<td ".(($j)?$tdscript:"").">{$grade['dados'][$i][$j]}</td>";
				$itens_cont++;
			}
			$html .= '</tr>';
		}
		$html .= '</table><!-- FIM grade_tabela -->';
				
		$grade = array();
		
		return ($itens_cont)?$html:(($nenhum_item)?$idioma['nenhum_item']:"");
	}
	
}
?>

