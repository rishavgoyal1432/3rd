<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_alerta{

	// Lista de alertas
	var $lista = array();
	
	/**
	 * Exibi��o de alertas e avisos
	 *
	 * @param string $imagem
	 * @param string $texto
	 * @param string $tipo
	 * @param int $tempo
	 * @param int $width
	 * @param int $height
	 * @param string $aleta_tipo
	 * @param int $manter
	 * @param string $evento
	 * @return string
	 */
	function exibir($imagem, $texto = "", $tipo = "float", $tempo = 60000, $width="", $height="", $aleta_tipo="onload", $manter=0, $evento=""){
		global $eva;
		global $config;
		global $eva_alerta_modelo;
		global $idioma;
		
		$codigo = empty($eva['phpshell'])?intval(microtime()*mktime()):0;
		$tipo = ($tipo == "")? "float" : $tipo;
		$this->verifica_imagem_texto($imagem,$texto);
		
		// coloca o valor do texto e da imagem na variavel $alerta reutilizando-a
		$alerta=$imagem.$texto;
		$eva['arquivo']->retirar_espacos($alerta);
		$alerta = addslashes($alerta);
		
		$esquerda=10;
		$topo=10;
		// tipo topo_direita, que aparece no canto superior direito da pag
		if($tipo=="float"){
			$esquerda='(window_size("w")-('.$width.'+5))';
		}
				
		// substitua onde tiver $ pela variavel javascript
		$pattern='/\$([a-z0-9_]+)/';
		preg_match_all($pattern,$alerta,$x);
		for($i=0;$i<count($x[0]);$i++){
			$alerta=str_replace($x[0][$i],'"+'.$x[1][$i].'+"',$alerta);	
		}
		$eva_alerta_modelo2 = ($tipo == "float" || $tipo == "sticky")? "eva_alerta_modelo3" : "eva_alerta_modelo2";
		$eva_alerta_modelo1 = "eva_alerta_modelo1";
		$stm='stm(["", '.$eva_alerta_modelo1.'+"'.$alerta.'"+'.$eva_alerta_modelo2.'],["","","","","","","","","","","","'.$tipo.'","","","'.$width.'","'.$height.'",2,2,'.$esquerda.','.$topo.',"","","","",""]';
		//echo "\n<br>$tipo\n<br>";
		if($tipo == "move"){
			if(empty($_GET['comando'])){
				if(!isset($eva['include'])) $eva['include'] = "";			
				$eva['include'] .= " toolman ";
				//se nao foi passado nenhum evento pegue o evento padr�o
				$evento=empty($evento)?"event":$evento;
				//$eva['onload'][] = 'var group;	var drag = ToolMan.drag(); group = drag.createSimpleGroup(document.getElementById("TipLayer"), document.getElementById("alerta_barra_titulo"));';
				$eva['script'][] = 'var group;	var drag = ToolMan.drag();';
				$eva['script'][] = '
					var old_t_top;
					var old_t_left;
					var old_div;
					var old_div_zindex = -1;
					function zindex_top(div){
						t = eva_elem(div);
						if(old_div_zindex>=0){
							old_div.style.zIndex = old_div_zindex;
						}
						old_div = t;
						old_div_zindex = t.style.zIndex;
						t.style.zIndex = 1100;
						
					}
					function div_max(div, btn){
						if(btn.className == "botao_maximizar"){
							btn.className = "botao_restaurar";
							d = eva_elem(div+"_tb");
							t = eva_elem(div);
							old_t_top = t.style.top;
							t.style.top = 0;
							old_t_left = t.style.left;
							t.style.left = 0;
							d.style.width = window_size(\'w\')-40;
							d.style.height = window_size(\'h\')-40;
						}else{
							btn.className = "botao_maximizar";
							d = eva_elem(div+"_tb");
							t = eva_elem(div);
							t.style.top = old_t_top;
							t.style.left = old_t_left;
							d.style.width = "";
							d.style.height = "";
						}
					}
					function div_min(div){
						d = eva_elem(div+"_msg");
						if(d.style.display != "none"){
							d.style.display = "none";
							d.style.visibility = "hidden";
						}else{
							d.style.display = "block";
							d.style.visibility = "";
						}
					}				
					function div_close(div){
						document.body.removeChild(eva_elem(div));
					}
					';
				$eva['script'][] = '			
					function div_mov_exec(d_msg, nm){	
						if(!(d_div = eva_elem(nm))){
							var d_div = document.createElement("div");
							d_div.id = nm;
							d_div.style.position="absolute";
							d_div.style.zIndex = 1000;
							d_div.style.top = 0;					
							d_body = document.getElementsByTagName("body");
							d_body[0].appendChild(d_div);
						}
						d_div.innerHTML = \'<table border="0" cellpadding="2" cellspacing="0" width="0"><tbody><tr><td><table border="0" cellpadding="2" cellspacing="0" width="100%" id="\'+nm+\'_tb" ><tbody><tr><td valign="top"><div class="alerta_barra_titulo" id="\'+nm+\'_bt" onclick="zindex_top(\\\'\'+nm+\'\\\')" ><table border="0" cellpadding="0" cellspacing="0" align="right"><tr><td><img src="eva/imagens/transparente.gif" width="16" height="16" /></td><td><div class="botao_minimizar" onMouseOver="this.style.cursor=eva_mouseover;" onclick="div_min(\\\'\'+nm+\'\\\', this);"></div></td><td><div class="botao_maximizar" onMouseOver="this.style.cursor=eva_mouseover;" onclick="div_max(\\\'\'+nm+\'\\\', this);"></div></td><td><div class="alerta_fechar" onMouseOver="this.style.cursor=eva_mouseover;" onclick="div_close(\\\'\'+nm+\'\\\');"></div></td></tr></table></div><div id="\'+nm+\'_msg">\'+d_msg+\'</div></td></tr></tbody></table></td></tr></tbody></table>\';
						group = drag.createSimpleGroup(d_div, eva_elem(nm+"_bt"));
						return nm;
					}
				';
			}
			return 'div_mov_exec('.$eva_alerta_modelo1.'+"'.$alerta.'"+'.$eva_alerta_modelo2.', "tip_div'.(rand(0,100)).'");';// nao lembro pq usei rand, mas acho q devia ser outra coisa
		}else if($tipo == "fixo"){
			$id = mktime()."alert".($eva['contador']++);
			$eva['script'][] = "eva_html('{$id}',eva_alerta_modelo1+'".stripslashes($eva['exibir']->corrigir_url_img($alerta))."'+eva_alerta_modelo2);";
			return "<div id='{$id}'>{$texto}</div>";
		}elseif($aleta_tipo=="onload"){
			//se nao foi passado nenhum evento pegue o evento padr�o
			$evento=($evento=="")?"false":$evento;
			$eva['onload'][] = "
				{$stm}, this, {$evento}, {$manter},{$tempo}, \"\");
				MoveTip(eva);";
		}else if($aleta_tipo=="retornar"){
			//se nao foi passado nenhum evento pegue o evento padr�o
			$evento=($evento=="")?"event":$evento;
			return $stm.", this, {$evento}, {$manter},{$tempo}, \"\");";
		}else if($tipo == "retornafixo"){
			return "<script>document.write(eva_alerta_modelo1+'".stripslashes($alerta)."'+eva_alerta_modelo2);</script>";
		}else{
			//se nao foi passado nenhum evento pegue o evento padr�o
			$evento=($evento=="")?"event":$evento;
			// o mesmo cima
			return $stm.", this, {$evento}, {$manter},{$tempo}, \"\");";
		}
	}
	 
	/**
	 * Fun��o que gera o vetor de alertas
	 *
	 * @param string $imagem
	 * @param string $texto
	 */
	function adicionar($imagem,$texto = ""){
		global $eva;
		$this->lista[] = array($imagem,$texto);
	}
	 
	/**
	 * Fun��o que gera o vetor de alertas
	 *
	 */
	function monta_alerta(){
		global $eva;
		$alerta = "";
		
		switch ($_GET['popup_alerta']){
			case "greenled":
				$this->adicionar("greenled");
			break;
			case "redled":
				$this->adicionar("redled");
			break;
			default:
				if(!empty($_GET['popup_alerta']))
					$this->adicionar("imagens/16x16/apps/important.png", urldecode($_GET['popup_alerta']));
			break;
		}
		$this->lista = array_unique($this->lista);
		while(list($cod,$item) = each($this->lista)){
			$this->verifica_imagem_texto($item[0],$item[1]);
			$alerta .= "<div>".$item[0].$item[1]."</div>";
		}
		if($alerta != ""){
			if(!empty($_GET['comando_tipo']) && $_GET['comando_tipo'] == "xml"){
				// cria a tag alerta
				$xml_alerta = $eva['xml']->criar_elemento("alerta");
				// cria a tag img
				$eva['xml']->criar_elemento_com_pai("img", "imagens/16x16/apps/important.png", $xml_alerta);	
				// cria a tag texto
				$eva['xml']->criar_elemento_com_pai("texto", $alerta, $xml_alerta);								
				$eva['xml']->colocar_no_root($xml_alerta);
			}else{
				echo $this->exibir("",$alerta);
			}
		}
	}
	
	/**
	 * Cria imagem para o alerta
	 *
	 * @param string $imagem
	 * @param string $texto
	 */
	function verifica_imagem_texto(&$imagem,&$texto){
		global $idioma, $eva;
		switch ($imagem){
			case "greenled":
				$imagem = "imagens/16x16/actions/greenled.png";
				$texto = (trim($texto) == "")? $idioma['operacao_sucesso'] : $texto;
			break;
			case "yellowled":
				$imagem = "imagens/16x16/actions/yellowled.png";
				$texto = (trim($texto) == "")? $idioma['operacao_falha'] : $texto;
			break;
			case "redled":
				$imagem = "imagens/16x16/actions/redled.png";
				$texto = (trim($texto) == "")? $idioma['operacao_falha'] : $texto;
			break;
		}
		//if(!eregi("http://",$imagem) && !eregi($eva['url_eva'],$imagem))		
			//$imagem = $eva['url_eva'].$imagem;
		if($imagem != ""){
			$imagem = "<img src=\"{$imagem}\" border=\"0\" align=\"middle\" align=\"right\" hspace=\"3\">";
		}else{
			$imagem = "";
		}
	}
}
?>
