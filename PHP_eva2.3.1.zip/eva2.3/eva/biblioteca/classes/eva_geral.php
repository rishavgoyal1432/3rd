<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
class eva_geral{

	// Classe da linha atual
	var $linha;
	var $id = 0;
	
	/**
	 * Cria um identificador unico
	 *
	 * @return int
	 */
	function id(){
		return ++$this->id;
	}
	
	/**
	 * Criar a tag de imagem com parametros de icones
	 *
	 * @param string $src
	 * @param bool $tamanho
	 * @return string
	 */
	function icone($src,$tamanho = true){
		$icones = 'imagens/16x16';
		return '<img src="'.$icones.'/'.$src.'" border="0" '.(($tamanho)?  'width="16" height="16"' : '').' align="middle" vspace="1" hspace="1">';
	}
	
	/**
	 * Fun��o administra e organiza as requisicoes da pagina para ajax
	 *
	 * @param string $exibir
	 */
	function recarregar_eva_xmlhttp(&$exibir){
		global $eva;
		
		if(!isset($_GET['recarregar_eva_xmlhttp'])){
			$f="";
			for($i=0;$i < count($eva['ajax']);$i++){
				if(($eva['ajax'][$i])!=""){
					$h=explode(":",$eva['ajax'][$i]);
					if(isset($h[0])){
						$f.="
						eva_ajax['src'][{$i}]=\"{$h[0]}\";";
					}
					if(isset($h[1])){
						$f.="
						eva_ajax['func'][{$i}]=\"{$h[1]}\";";
					}
				}
			}
			$f.="
			eva_ajax['total']=".(count($eva['ajax'])).";";
			$xml_objetos="";
			for($i=0;$i < count($eva['ajax']);$i++){
				$xml_objetos.="
				eva_ajax_{$i}=criar_objeto_xmlhttp();";
			}			
			if(trim($f)!=""){
				$eva['script'][] = "
					var eva_ajax = new Array();
					eva_ajax['src'] = new Array();
					eva_ajax['func'] = new Array();
					eva_ajax['total'] = new Array();
					eva_ajax['resposta'] = false;
					eva_ajax['valor'] = 0;
					eva_ajax['repetir'] = 30000;
					eva_ajax['limpar'] = false;
					".$xml_objetos."									
					".$f;
				$eva['onload'][] = "setTimeout('eva_xmlhttp();', 500);";
			}
		}
	}
	
	/**
	 * pega os milesegundos
	 *
	 * @return float
	 */
	function getmicrotime(){
	   list($usec, $sec) = explode(" ", microtime());
	   return ((float)$usec + (float)$sec);
	}
	
	/**
	 * Retorna a classe css para alternar a cor de uma linha de uma tabela
	 *
	 * @param string $tipo
	 * @return string
	 */
	function alterna_linha($tipo=""){
		if ($tipo == "linha2"){
			$this->linha = 2;
			return "linha1"; 		
		}else if ($tipo == "linha1"){
			$this->linha = 1;
			return "linha2";
		}else if ($tipo == "destaque"){
			return "linha_destaque";
		}else if ($this->linha == 1){
			$this->linha = 2;
			return "linha1"; 		
		}else{
			$this->linha = 1;
			return "linha2";
		}
	}	
	
	/**
	 * Fun��o para imprimir o Java script de navega��o
	 *
	 * @param string $sentido
	 */
	function exibir_navegacao($sentido) {
		global $idioma;
		global $eva;
		$eva['incluir']->incluir_modulo("eva_menu");
		$menu['fundo']= false;
		if ($sentido > 0){
			$menu[0]['img']="imagens/16x16/actions/forward.png";
			$menu[0]['alt']=$idioma['avancar'];
		}else if ($sentido < 0){ 
			$menu[0]['img']="imagens/16x16/actions/back.png";
			$menu[0]['alt']=$idioma['voltar'];
		}else{
			$menu[0]['img']="imagens/16x16/actions/reload_page.png";
			$menu[0]['alt']=$idioma['atualizar'];
		}
		$menu[0]['url']="javascript:history.go(".$sentido.")";
		echo $eva['modulo_eva_menu']->criar_menu($menu);
	}
	
	/**
	 * formata para data mktime uma data em string
	 *
	 * @param srting $string
	 * @param string $formato
	 * @return string
	 */
	function formatar_data($string, $formato = ""){
		if(!eregi("/|\/" , $string))return $string;
		global $idioma;
		if(empty($string)) return mktime();
		if(empty($formato))
			$formato = strtolower($idioma['formato_data_e_seg_mktime']);
		$data = array();
		$hora = array();
		if(intval($string) < 1) return 0;
		$pedacos = explode(" ", $string);
		for ($i=0; $i<2; $i++){
			if(isset($pedacos[$i])){
				if (eregi("/", $pedacos[$i])){
					$data = explode("/", $pedacos[$i]);
				}else{
					$hora = explode(":", $pedacos[$i]);
				}
			}
		}
		$pedacos = array_merge($data , $hora);
		$formato = str_replace("/", "", $formato);
		$formato = str_replace(":", "", $formato);
		$formato = str_replace(" ", "", $formato);
		
		for ($i=0; $i<strlen($formato); $i++){
			$char = substr($formato, $i, 1);
			if(!isset($pedacos[$i])) $pedacos[$i] = 0;
			$pedacos[$char] = intval($pedacos[$i]);
		}
		$mktime = @mktime($pedacos['h'], $pedacos['i'], $pedacos['s'], $pedacos['m'], $pedacos['d'], $pedacos['y']);
		if ($mktime<0){$mktime=0;}
		return $mktime;
	}
	 
	/**
	 * Formata para data dd/mm/aa uma data em mktime
	 *
	 * @param string $mkdata
	 * @return string
	 */
	function formatar_dia_data_hora($mkdata){
		if(empty($mkdata)) return "";
		$semana = array("Domingo", "Segunda", "Ter�a", "Quarta", "Quinta", "Sexta", "S�bado"); 
		$arrMes = array("", "Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro");
		$dia = date("j", $mkdata);
		$mes = $arrMes[date("n", $mkdata)];
		$ano = date("Y", $mkdata);
		$dia_semana = $semana[date("w", $mkdata)];
		$hora = date("H", $mkdata);
		$min = date("i", $mkdata);
		return $dia_semana.", ".$dia." de ".$mes." de ".$ano.", ".$hora."h".$min;
	}
	
	/**
	 * Envia e-mail utilizando um dos modelos dispon�veis no tema
	 *
	 * @param string $destinatario;  Either a comma-seperated list of recipients (RFC822 compliant), or an array of recipients, each RFC822 valid. This may contain recipients not specified in the headers, for Bcc:, resending messages, etc.
	 * @param string $assunto
	 * @param string $mensagem
	 * @param string $remetente
	 * @param string $modelo
	 * @param string $copia
	 * @param string $copia_oculta
	 * @return bool
	 */
	function enviar_email($destinatario,$assunto,$mensagem,$remetente,$modelo='',$copia='',$copia_oculta=''){
		global $config;
		global $eva;
		
		$procura[]="{usuario}";
		$procura[]="{senha}";
		$procura[]="{cod_confirm}";
		$procura[]="{nome}";
		$substitui[]=@$_POST['US_LOGIN'];
		$substitui[]=@$_POST['US_SENHA'];
		$substitui[]=@$_POST['US_OBS'];
		$substitui[]=@$_POST['US_NOMECOM'];
		$mensagem=str_replace($procura, $substitui, $mensagem);
		
		$eva['incluir']->incluir("carregar");		
		$modelo = $eva['caminho'].$modelo;
		if(empty($modelo) or $modelo == $eva['caminho'] or !file_exists($modelo)){
			$modelo = "{bloco}";
		}else{
			$modelo = @file_get_contents($modelo);
			//$modelo = str_replace("background=\"", "background=\"".$eva['config']['url'],$modelo);
			//$modelo = str_replace("src=\"", "src=\"".$eva['config']['url'],$modelo);	
			$eva['incluir']->incluir("carregar");
			$modelo=$eva['carregar']->tratar_src($modelo);
		}
				 
		$modelo = str_replace("{bloco}", $mensagem,$modelo);
		$modelo = str_replace("{titulo}", $assunto,$modelo);
		$modelo = str_replace("{fechar}", "",$modelo);

		ini_set("max_execution_time","180");
		$modelo = $eva['carregar']->tratar_src($modelo,"");
		
		// if pear is installed use the pear mail
		if($this->pear_isntalled()){
			require_once("pear/Mail.php");
			require_once('pear/Mail/mime.php');
			$crlf = "\n";
			$hdrs = array(
				'From'    => $remetente,
				'Subject' => $assunto,
				);
			$mime = new Mail_mime($crlf);
			$mime->setHTMLBody($modelo);
			//$mime->addAttachment($this->text, 'message/rfc822', $this->subject . '.msg', FALSE, 'raw');	
			$body = $mime->get();
			$hdrs = $mime->headers($hdrs);
			$mail = Mail::factory('mail');
			$status = $mail->send($destinatario, $hdrs, $body);
			//$status = mail($destinatario, $assunto, $modelo,$headers);
		}else{			
			if(is_array($destinatario)) $destinatario = implode(", ",$destinatario);
			$headers  = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			//$headers .= "To: {$destinatario}\r\n";
			$headers .= "From: {$remetente}\r\n";
			$headers .= (!empty($copia))? "Cc: {$copia}\r\n" : "";
			$headers .= (!empty($copia_oculta))? "Bcc: ".$copia_oculta."\r\n" : "";
			$headers .= "Reply-To: {$remetente}\r\n";		
			//var_dump($destinatario);exit;
			$status = mail($destinatario, $assunto, $modelo,$headers);
			//echo __LINE__;exit;
		}
		
		return $status;
	}
	
	/**
	 * funcao para escolher cor
	 *
	 * @param string $cor_inicial
	 * @param string $nome
	 * @param string $id
	 * @return string
	 */
	function selecionar_cor($cor_inicial, $nome, $id = ""){
		// Isto � necess�rio para poder usar as cores
		//include_once("biblioteca/javascripts/pegar_cor_js.php"); 
		global $eva;
		$eva['incluir']->incluir("alerta");
		/*
		$eva['head'][] = "<script type=\"text/javascript\" src=\"biblioteca/javascripts/funcoes_tabela_de_cores.js.php\"></script>\n";	
		*/
		$pega_cor = "<!-- tabela_de_cores --><table width=\"10\" border=\"0\" cellspacing=\"2\" cellpadding=\"0\"><tr><td><input name=\"{nome}\" type=\"text\" id=\"{id}\" value=\"{cor}\" size=\"7\" maxlength=\"7\"  onchange=\"ajustar_cor_tabela(this.value, '{id}');\" onblur=\"validar_cor_hexa(this)\"></td><td><table width=\"16\" height=\"15\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"background-color: {cor};border: 2px solid #CCCCCC\" id=\"tabela_cor{id}\" onClick='redefinir_id(\"{id}\", this);".$eva['alerta']->exibir("", '$eva_tabela_cores'."<img src=\"{$eva['url_eva']}imagens/colors.gif\" width=\"289\" height=\"67\" border=\"0\" usemap=\"#colorMap\">", "move", 0, 0, "", "retornar", 6000)."' onMouseOver=\"this.style.cursor=eva_mouseover;\"><tr><td>&nbsp;</td></tr></table></td></tr></table>";
		$pega_cor = str_replace( "{cor}", $cor_inicial, $pega_cor);
		$pega_cor = str_replace( "{id}", $id, $pega_cor);
		$pega_cor = str_replace( "{nome}", $nome, $pega_cor);
		return $pega_cor;
	}
	
	/**
	 * funcao para remover os acentos de uma string
	 *
	 * @param string $string
	 * @return string
	 */
	function retirar_acentos($string){
	
	  $array1 = array(   "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�"
						 , "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�", "�" );
	  $array2 = array(   "a", "a", "a", "a", "a", "e", "e", "e", "e", "i", "i", "i", "i", "o", "o", "o", "o", "o", "u", "u", "u", "u", "c"
						 , "A", "A", "A", "A", "A", "E", "E", "E", "E", "I", "I", "I", "I", "O", "O", "O", "O", "O", "U", "U", "U", "U", "C" );
	  return str_replace( $array1, $array2, $string);
	
	} 
	
	/**
	 * Remove um array de strings de um texto
	 *
	 * @param array $array
	 * @param string $texto
	 * @return string
	 */
	function retirar_palavras($array,$texto)
	{
	  foreach($array as $i => $valor)
		$texto = eregi_replace($valor,"",$texto);
	
	  return $texto;
	}
	
	/**
	 * Recebe como parametro Mozilla, Firefox, IE, Opera, Netscape, Outros
	 *
	 * @param string $navegador
	 * @return string
	 */
	function detectar_navegador($navegador = ""){
		if(!isset($_SERVER['HTTP_USER_AGENT'])) return false;
		if ( strpos($_SERVER['HTTP_USER_AGENT'], 'Gecko') ){
		   if ( strpos($_SERVER['HTTP_USER_AGENT'], 'Netscape') )   {
			 $browser = 'Netscape (Gecko/Netscape)';
			 if($navegador=="Netscape")return true;
		   }else if ( strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') ){
			 $browser = 'Mozilla Firefox (Gecko/Firefox)';
			 if($navegador=="Firefox")return true;
		   }else{
			 $browser = 'Mozilla (Gecko/Mozilla)';
			 if($navegador=="Mozilla")return true;
		   }
		}else if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') ){
		   if ( strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') ){
			 $browser = 'Opera (MSIE/Opera/Compatible)';
			 if($navegador=="Opera")return true;
		   }else{
			 $browser = 'Internet Explorer (MSIE/Compatible)';
			 if($navegador=="IE")return true;
		   }
		}else{
		   $browser = 'Others browsers';
		   if($navegador=="Outros")return true;
		}
		if($navegador==""){
			return $browser;
		}else{
			return false;
		}
	}
	
	/**
	 * Check if the string or URL is UTF 8 encoded
	 *
	 * @param string $string
	 * @return boolean
	 */
	function is_utf8($string){
		if(strlen($string) < 255 && eregi('^http', $string)){
			ini_set("allow_url_fopen", "1");
			$h = array_change_key_case($this->get_headers($string, 1), CASE_LOWER);
			if(!empty($h['content-type']) && eregi('utf', $h['content-type']))
				return true;  // the original url is utf8
		   	else
				 return false; // otherwise
		}else{	
		   $string_utf8 = utf8_encode($string);
		   if( strpos($string_utf8,"?",0) !== false ) // "?" is ALT+159
				 return true;  // the original string was utf8
		   else
				 return false; // otherwise
		}
	}
	
	/**
   * @return array
   * @param string $url
   * @param int $format
   * @desc Fetches all the headers
   * @author cpurruc fh-landshut de
   * @modified by dotpointer
   * @modified by aeontech
   */
   function get_headers($url,$format=0) {
   		if(empty($url))return false;
   		if(function_exists('get_headers')) return get_headers($url,$format);
       $url_info=parse_url($url);
       $port = isset($url_info['port']) ? $url_info['port'] : 80;
       $fp=fsockopen($url_info['host'], $port, $errno, $errstr, 30);
      
       if($fp){
           $head = "HEAD ".@$url_info['path']."?".@$url_info['query']." HTTP/1.0\r\nHost: ".@$url_info['host']."\r\n\r\n";     
           fputs($fp, $head);     
           while(!feof($fp)){
               if($header=trim(fgets($fp, 1024))){
                   if($format == 1){
                       $key = array_shift(explode(':',$header));
                       // the first element is the http header type, such as HTTP 200 OK,
                       // it doesn't have a separate name, so we have to check for it.
                       if($key == $header){
                           $headers[] = $header;
                       }else{
                           $headers[$key]=substr($header,strlen($key)+2);
                       }
                       unset($key);
                   }else{
                       $headers[] = $header;
                   }
               }
           }
           return $headers;
       }else{
           return false;
       }
   }
	
	/**
	 * Encode UTF8 if the string is not encoded already
	 *
	 * @param unknown_type $string
	 * @return unknown
	 */
	function utf8($string){
	   if($this->is_utf8($string)){
			 return utf8_decode($string);  
	   }else{
			 return $string; 
		}
	}
	
	/**
	 * htmlentities reverse
	 *
	 * @param string $input
	 * @return string
	 */
	function unhtmlentities ($input) {
		$htmlEntities = array_values (get_html_translation_table (HTML_ENTITIES, ENT_QUOTES));
		$entitiesDecoded = array_keys  (get_html_translation_table (HTML_ENTITIES, ENT_QUOTES));
		$num = count ($entitiesDecoded);
		for ($u = 0; $u < $num; $u++) {
			$utf8Entities[$u] = $entitiesDecoded[$u];
		}
		return str_replace ($htmlEntities, $utf8Entities, $input);
	}
	
	/**
	  * Searches for a regex match in every value of a one-dimensional array.
	  *
	  * @param string $pattern POSIX-extended regular expression to match.
	  * @param array $haystack Array to search in.
	  * @return mixed Index of the first match, or FALSE if no match is found.
	  */
	function array_ereg($pattern, $haystack, $sensitive=true){
		foreach ($haystack as $key => $value){ 
			if($sensitive)
				$result = ereg($pattern, $value);	
			else
				$result = eregi($pattern, $value);	
			if ($result){
				//return $key;
				return true;
			}
		}
		return false;
	} 
	
	/*
	Foi feito para funcionar no php 4
	http_build_query	
	(PHP 5, PECL pecl_http:0.1.0-0.9.0)	
	http_build_query � Generate URL-encoded query string
	Descri��o
	string http_build_query ( array $formdata [, string $numeric_prefix [, string $arg_separator]] )	
	Generates a URL-encoded query string from the associative (or indexed) array provided. 
	Par�metros	
	formdata	
		May be an array or object containing properties.	
		The array form may be a simple one-dimensional structure, or an array of arrays (who in turn may contain other arrays). 
	numeric_prefix	
		If numeric indices are used in the base array and this parameter is provided, it will be prepended to the numeric index for elements in the base array only.	
		This is meant to allow for legal variable names when the data is decoded by PHP or another CGI application later on. 
	arg_separator	
		arg_separator.output is used to separate arguments, unless this parameter is specified, and is then used. 	
	Valores de retornado	
	Returns a URL-encoded string. 
	*/	
	function http_build_query( $formdata, $numeric_prefix = null, $key = null ) {
		if(function_exists('http_build_query')) return http_build_query($formdata);
		$res = array();
		foreach ((array)$formdata as $k=>$v) {
			$tmp_key = urlencode(is_int($k) ? $numeric_prefix.$k : $k);
			if ($key) {
				$tmp_key = $key.'['.$tmp_key.']';
			}
			if ( is_array($v) || is_object($v) ) {
				$res[] = $this->http_build_query($v, null, $tmp_key);
			} else {
				$res[] = $tmp_key."=".urlencode($v);
			}
		}
		return implode("&", $res);
	}
	
	function replaceLinks($text) {
	   // convert support@pogoda.in into
	   // <a href="mailto:support@pogoda.in">
	   // support@pogoda.in</a>
	   $text = ereg_replace('[-a-z0-9!#$%&\'*+/=?^_`{|}~]+@([.]?[a-zA-Z0-9_/-])*',
		   '<a href="mailto:\\0">\\0</a>',$text);
	
	   // convert http://www.pogoda.in/new_york/eng/ into
	   // <a href="http://pogoda.in/new_york/eng/">
	   // pogoda.in/new_york/eng/</a>
	   $text = ereg_replace('[a-zA-Z]+://(([.]?[a-zA-Z0-9_/-])*)',
		   '<a href="\\0">\\1</a>',$text);
	
	   // convert www.pogoda.in/new_york/eng/ into
	   // <a href="http://www.pogoda.in/new_york/eng/">
	   // www.pogoda.in/new_york/eng/</a>
	   $text = ereg_replace('(^| )(www([-]*[.]?[a-zA-Z0-9_/-?&%])*)',
		   ' <a href="http://\\2">\\2</a>',$text);
	  
	   return $text;
	}
	
	// informa se a versao do php � maior que 5
	function php5(){
		return version_compare(phpversion(), '5', '>=');
	}
	
	function pear_isntalled(){
		return eregi("pear", ini_get("include_path"));
	}
	
	// if pass a name delete specific cookie else delete all
	function delete_cookie($name = ""){
		if(!empty($name))
			setcookie ($name, "", time() - 3600);
		else if (isset($_COOKIE)) {
		   foreach ($_COOKIE as $name => $value) {
			   setcookie ($name, "", time() - 3600);
		   }
		}
	}
	
	// Faz uma busca por um argumento
	function args_search(&$args, $tipo){	
		foreach($args as $k => $v){
			if(is_array($v) && key($v) == $tipo){
				$t = $v[$tipo];
				unset($args[$k]);
				return $t;
			}
		}
		return false;
	}
	
	// coloca os valores nos argumentos
	function args_put_value(&$args, $values){	
		foreach($args as $k => $v){
			//var_dump($v);echo "<br>";
			if(is_array($v)){
				$args[$k][key($v)] = array(
										empty($v[key($v)][0])?"":$v[key($v)][0],
										empty($v[key($v)][1])?"":$v[key($v)][1], 
										@$values[strtoupper(key($v))],
										empty($v[key($v)][3])?"":$v[key($v)][3],
										empty($v[key($v)][4])?"":$v[key($v)][4],
										empty($v[key($v)][5])?"":$v[key($v)][5],
										empty($v[key($v)][6])?"":$v[key($v)][6],
										empty($v[key($v)][7])?"":$v[key($v)][7],
										empty($v[key($v)][8])?"":$v[key($v)][8]
									);
			}else{
				$args[$k] = array($v => array(
										"",
										"", 
										$values[strtoupper($v)],
										"",
										"",
										"",
										"",
										"",
										""
									));
			}
			//echo "<br>----------<br>";var_dump($args[$k]);echo "<hr>";
		}
		return false;
	}
	
	// retorna os argumentos para criar formularios
	function args_form($k, $v){
		if(is_array($v)){
			$nome 		= key($v);
			$v 			= $v[$nome];
			$titulo 	= $v[0];
			$tipo 		= !empty($v[1])?$v[1]:($k=="ps_cod"?"hidden":"text"); 
			$valor 		= !empty($v[2])?$v[2]:""; 
			$opcoes 	= !empty($v[3])?$v[3]:"";
			$alerta 	= !empty($v[4])?$v[4]:"";
			$formato	= !empty($v[5])?$v[5]:"";
			$html 		= !empty($v[6])?$v[6]:"";
			$extra 		= !empty($v[7])?$v[7]:"";
			$avancado	= !empty($v[8])?$v[8]:false;
		}else{
			$nome 		= $v;
			$titulo 	= "";
			$tipo 		= ($k=="ps_cod"?"hidden":"text"); 
			$valor 		= ""; 
			$opcoes 	= "";
			$alerta 	= "";
			$formato	= "";
			$html 		= "";
			$extra 		= "";
			$avancado	= false;
		}
		return array(
				'nome'=>$nome,
				'titulo'=>$titulo,
				'tipo'=>$tipo,
				'valor'=>$valor,
				'opcoes'=>$opcoes,
				'alerta'=>$alerta,
				'formato'=>$formato,
				'html'=>$html,
				'extra'=>$extra,
				'avancado'=>$avancado);
	}
	
	// retorna uma string reduzida ou vazio se nao tiver string
	function substr($str, $limit=100){
		if(empty($str)) return $str;
		if(strlen($str)<=$limit) return $str;
		return substr($str, 0, $limit)." ...";
	}
} //eva_geral
?>