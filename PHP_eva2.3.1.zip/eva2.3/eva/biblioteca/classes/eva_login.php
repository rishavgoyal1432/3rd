<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_login{
	/**
	 * Cria novo usu�rio com vampos padr�o
	 *
	 * @param int $us_grupo
	 * @param string $us_nome
	 * @param string $us_nomecom
	 * @param string $us_login
	 * @param string $us_senha
	 * @param string $us_datacad
	 * @param string $us_datanasc
	 * @param string $us_dataacesso
	 * @param string $us_status
	 * @param string $us_email
	 */
	function criar_usuario($us_grupo, $us_nome = "", $us_nomecom = "", $us_login, $us_senha, $us_datacad = "", $us_datanasc = "", $us_dataacesso = "", $us_status = "a", $us_email = ""){	
		global $config, $eva, $idioma;
		$eva['incluir']->incluir("sql");
		$us_cod = $eva['sql']->selecionar_maior("eva_usuario", "us_cod");
		$us_datacad = ($us_datacad != "") ? $us_datacad : mktime();
	
		$us_dataacesso = ($us_dataacesso != "") ? $us_dataacesso : mktime();
		$us_datanasc = ($us_datanasc != "") ? $us_datanasc : mktime();
		$sql="INSERT INTO ".$config['bdprefixo']."_eva_usuario (us_cod, us_nome, us_nomecom, us_login, us_senha, us_datacad, us_datanasc, us_dataacesso, us_status, us_email) VALUES (".$us_cod.", '".$us_nome."', '".$us_nomecom."', '".$us_login."', '".$us_senha."', ".$us_datacad.", ".$us_datanasc.", ".$us_dataacesso.", '".$us_status."', '".$us_email."')";
		$rs = $eva['sql']->executar($sql,false,false,false);
		if(intval($us_grupo) > 0){		
				$sql = "INSERT INTO ".$config['bdprefixo']."_eva_usuario_grupo (ug_gr_cod, ug_us_cod) VALUES (".$us_grupo.", ".$us_cod.")";
				$rs = $eva['sql']->executar($sql,false,false,false);
		}
	}
	/**
	 * Login - Autentica��o do usu�rio e cria��o de se��es
	 *
	 */
	function entrar(){
		global $config;
		global $eva;
		if (isset($_GET['eva_login'])){	
			 switch($_GET['eva_login']) {
				case 'entrar':
					if(!isset($_POST['us_login']) || !isset($_POST['us_senha'])) break;
					// Limpando vetor de sessoes
					$_SESSION = array();
					$teste_login = true;
					//echo $eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha']));exit;
					// select pra saber se � super usu�rio
					$sql="SELECT
						 us_cod, us_login, us_email, us_nomecom, us_numacessos, us_status
						FROM
						 ".$config['bdprefixo']."_eva_usuario,
						 ".$config['bdprefixo']."_eva_usuario_grupo
						WHERE
						 us_login = '".$eva['seguranca']->tratar_seguranca($_POST['us_login'])."' 
						AND
						 us_senha = '".$eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha']))."' 
						AND
						 us_status != 'i'
						AND
						  ug_gr_cod = 1
						AND
						  ug_us_cod = us_cod
						";
					//echo $sql;
					$rs = $eva['sql']->executar($sql);
					if($rs->RecordCount()>0){
						$redirecionar = (!empty($config['redirecionar_modulo'])?	("index.php?".$eva['seguranca']->codificar_get("m=".$config['redirecionar_modulo'])):(isset($config['login'][0]['url'])? $config['login'][0]['url'] : ""));
					}else if(!empty($config['login'][0]['tipo'])){
						$teste_login = false;
						for ($i =0; $i < count($config['login']); $i++){	
							if(!empty($_POST['us_dominio']) && !empty($config['login'][$i]['dominio']) && $config['login'][$i]['dominio'] != $_POST['us_dominio']){
								continue;
							}
							$config['login'][$i]['dominio'] = (!empty($config['login'][$i]['dominio']))? $config['login'][$i]['dominio'] : '';
							// Definindo informacoes de acesso
							$usuario = explode("@",$eva['seguranca']->tratar_seguranca(trim($_POST['us_login'])));
							// retirado por solicitacao de mike
							//$email = (count($usuario) < 2)? ((empty($config['login'][$i]['dominio']))?$usuario[0]:$usuario[0]."@".$config['login'][$i]['dominio']) : $usuario[0]."@".$usuario[1];
							//$email = $usuario[0]."@".$usuario[1];
							$_POST['us_login'] = $eva['seguranca']->tratar_seguranca(trim($_POST['us_login']));
							if(!eregi("@", $_POST['us_login'])){
								if(!empty($config['login'][$i]['dominio'])){
									$email = $_POST['us_login']."@".$config['login'][$i]['dominio'];
								}else{
									// nao existe email
									$email = "";
								}
							}else{
								$email = $_POST['us_login'];
							}
							
							if($config['login'][$i]['login'] == "email"){
								$login = $email;
							}else{
								$login = $usuario[0];
							}
							//var_dump($email);var_dump($usuario);var_dump($login);
							// Metodos de autenticacao: BD, POP3 e IMAP
							//var_dump($config['login'][$i]['tipo']);
							if((eregi("pop3", $config['login'][$i]['tipo']) || eregi("imap", $config['login'][$i]['tipo']))){					//echo __LINE__."<hr>";exit;				
								if(function_exists("imap_open")){
									imap_timeout(1,10);
									//echo "{". $config['login'][$i]['servidor'] . "/".$config['login'][$i]['tipo'].":".$config['login'][$i]['porta']."} ".$login.", ".$eva['seguranca']->tratar_seguranca($_POST['us_senha']);
									//echo __LINE__."<hr>";
									$inbox = @imap_open("{". $config['login'][$i]['servidor'] . "/".$config['login'][$i]['tipo'].":".$config['login'][$i]['porta']."}", $login, utf8_decode($eva['seguranca']->tratar_seguranca($_POST['us_senha'])));
									//echo __LINE__."<hr>";
									//echo "<br>".$eva['seguranca']->tratar_seguranca($_POST['us_senha'])."<br>".imap_last_error()."<br>";var_dump($inbox);exit;								
									if ($inbox){
										$teste_login = true;
										break;
									}else{
										$imap_erro = imap_errors();
										if(!empty($imap_erro))
											$eva['alerta']->adicionar("redled", "IMAP Errors: ({$config['login'][$i]['servidor']}:{$config['login'][$i]['porta']})<br> - ".implode("<br> - ", $imap_erro));
									}
								}else{
									$eva['alerta']->adicionar("redled", "Your PHP/IMAP client is not working.");
								}
							}else if($config['login'][$i]['tipo'] == "ldap" && function_exists("ldap_connect")){
								$ds = ldap_connect($config['login'][$i]['servidor'], $config['login'][$i]['porta']);
								if ($ds){
									if (ldap_bind($ds, $config['login'][$i]['bind_dn'], $config['login'][$i]['senha_bind'])) {	
										$result = ldap_search($ds, $config['login'][$i]['base_dn'], str_replace('$email', $login, $config['login'][$i]['filtro']));
										$entry = ldap_first_entry($ds, $result);
										$values = ldap_get_values($ds, $entry, $config['login'][$i]['atributo_senha']);
										//var_dump($values);
										if ($values[0] == $eva['seguranca']->tratar_seguranca($_POST['us_senha'])) {
											$teste_login = true;
											break;
										}
									}
								}								
							}else if(!empty($config['login'][$i]['bd'])){
								$bd_autenticar = new eva_sql();								
								$criptografia = (!empty($config['login'][$i]['criptografia']))? $config['login'][$i]['criptografia'] : "trim";
								$config['login'][$i]['usuario'] = (!empty($config['login'][$i]['usuario']))? $config['login'][$i]['usuario'] : $login;
								$config['login'][$i]['senha'] =  (!empty($config['login'][$i]['senha']))? stripslashes($config['login'][$i]['senha']) : $criptografia($_POST['us_senha']);
								
								//echo "\$bd_autenticar->conectar({$config['login'][$i]['tipo']}, {$config['login'][$i]['servidor']}, {$config['login'][$i]['usuario']}, {$config['login'][$i]['senha']}, {$config['login'][$i]['bd']});";exit;
								$bd_conectar = $bd_autenticar->conectar($config['login'][$i]['tipo_bd'], $config['login'][$i]['servidor_bd'], $config['login'][$i]['usuario'], $config['login'][$i]['senha'], $config['login'][$i]['bd']);
								if($bd_conectar){
									if(!empty($config['login'][$i]['sql'])){
										$config['login'][$i]['sql'] = str_replace("{login}",$login,$config['login'][$i]['sql']);							
										$config['login'][$i]['sql'] = str_replace("{senha}",$criptografia($_POST['us_senha']),$config['login'][$i]['sql']);								
										$rs = $bd_autenticar->executar($config['login'][$i]['sql']);
										if($rs){				
											if($rs->RecordCount() > 0){
												$teste_login = true;
												break;
											}
											//else{echo $config['login'][$i]['sql'];exit;}
										}
									}else{
										$teste_login = true;
										break;
									}
								}
								
							}
						}
						
						if($teste_login){
							$sites = !empty($config['login'][$i]['site'])?explode(',',$config['login'][$i]['site']):array();
							$redirecionar = (!empty($config['redirecionar_modulo'])?	("index.php?".$eva['seguranca']->codificar_get("m=".$config['redirecionar_modulo'])):(isset($config['login'][0]['url'])? $config['login'][0]['url'] : ""));
							//$redirecionar = !empty($config['redirecionar_modulo'])?$config['redirecionar_modulo']:((isset($config['login'][0]['url']))? $config['login'][0]['url'] : "");
							//$_POST['us_login'] = $login;
							$login = $_POST['us_login'];
							
							$_SESSION["us_chave"] =  base64_encode($_POST['us_senha']);
							$sql="SELECT us_cod FROM {$config['bdprefixo']}_eva_usuario WHERE us_login = '{$login}'";
							//$x = $eva['sql']->conexao->CacheFlush();
							$rs = $eva['sql']->executar($sql);
							$usuario = $rs->FetchRow();		
							if(!($rs->RecordCount()) && !($usuario = $rs->FetchRow())){								
								$this->criar_usuario($config['login'][$i]['grupo'], $login, $login, $login, $eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha'])), mktime(), mktime(), mktime(), "a", $email);
							}else{
								$sql="SELECT us_cod FROM ".$config['bdprefixo']."_eva_usuario WHERE us_login = '".$eva['seguranca']->tratar_seguranca(trim($_POST['us_login']))."' AND us_senha = '".$eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha']))."'";	
								$rs = $eva['sql']->executar($sql);
								if (!($usuario = $rs->FetchRow())){
									$sql="UPDATE ".$config['bdprefixo']."_eva_usuario SET us_senha = '".$eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha']))."' WHERE us_login = '".$eva['seguranca']->tratar_seguranca(trim($_POST['us_login']))."'";
									$rs = $eva['sql']->executar($sql);
								}
							}
						}
					}
					$sql="SELECT
						 us_cod, us_login, us_email, us_nomecom, us_numacessos, us_status
						FROM
						 ".$config['bdprefixo']."_eva_usuario 
						WHERE
						 us_login = '".$eva['seguranca']->tratar_seguranca($_POST['us_login'])."' 
						AND
						 us_senha = '".$eva['seguranca']->tratar_seguranca($eva['seguranca']->encriptar_palavra($_POST['us_senha']))."' 
						AND
						 us_status != 'i'
						";// a = ativo | v = esperando verifica��o
					
					$rs = $eva['sql']->executar($sql);
					$usuario_login = false;
					if($teste_login){
						if ($usuario = $rs->FetchRow()){
							if($usuario['US_STATUS']=='v'){ // o usuario esta aguardando confirma��o
								$_GET['m']=$_GET['modulo']="eva_usuario";
								$_GET['a']=$_GET['acao']="confirmar_cod";
								$usuario_login = true;
							}else{
								//selecione os grupos deste usuario
								$sql = "SELECT 
								ug_gr_cod, gr_acesso 
								FROM 
								".$config['bdprefixo']."_eva_usuario_grupo ,
								".$config['bdprefixo']."_eva_grupo
								WHERE 
								ug_us_cod = ".intval($usuario['US_COD'])." 
								AND 
								gr_cod = ug_gr_cod";
								$rs_gr = $eva['sql']->executar($sql);
								$us_grupos = array();
								if($rs_gr){
									while ($arr_gr = $rs_gr->FetchRow()) {
										$us_grupos[]=$arr_gr['UG_GR_COD'];
									}
								}
								$acesso = $this->gerar_acesso($usuario['US_COD']);
								// $eva['usuario_online']->desconectar_usuario_online($usuario['US_COD'], "Seu usu�rio foi desconectado e conectado por outra m�quina\nIP da m�quina: ".$_SERVER['REMOTE_ADDR']);
								$_SESSION["us_acesso"] = $acesso;
								$_SESSION["us_cod"] = $usuario['US_COD'];
								$_SESSION["us_login"] = $usuario['US_LOGIN'];
								//$_SESSION["us_login"] = $email;
								$_SESSION["us_email"] = $usuario['US_EMAIL'];
								$_SESSION["us_nomecom"] = $usuario['US_NOMECOM'];
								$_SESSION["us_grupo"] = $us_grupos;
								$_GET['atualizar'] = 'true';
								$usuario_login = true;
								// Incrementar o n�mero de acessos do usu�rio
								$sql = "UPDATE 
											".$config['bdprefixo']."_eva_usuario 
										SET 
											us_numacessos = ".($usuario['US_NUMACESSOS']+1).", 
											us_dataacesso = ".mktime()." 
										WHERE 
											us_login = '".$_POST['us_login']."'";
								$rs = $eva['sql']->executar($sql, false, false, false, false, false);
							}
						}
					}
					if(isset($redirecionar) && $redirecionar != ""){
						//echo $redirecionar;exit;
						header("Location: ".$redirecionar);
					}
					if(!$usuario_login){
						$usuario_login = false;				
						$_GET['modulo'] = "eva_usuario";
						$_GET['acao'] = "recuperar_senha";
						$_GET['erro'] = 1;
						if(!empty($_SERVER['HTTP_REFERER']))
							header("Location: ".$_SERVER['HTTP_REFERER'].(eregi("\?", $_SERVER['HTTP_REFERER'])?"&":"?")."login_msg=login_erro");
					}
				break;
				case 'sair':				
					session_unset();
					session_destroy();
					$eva['geral']->delete_cookie();
					header("Location: index.php?s=".$_GET['site']);
					$_GET = array();
					$_GET['site'] = $eva['site']['site'];
				break;
			}
		}
	}
	
	/**
	 * fun�ao que soma as strings de acesso
	 *
	 * @param int $us_cod
	 * @return string
	 */
	function gerar_acesso($us_cod){
		global $config;
		global $eva;
		
		$acesso_site = array();
		//selecione os grupos deste usuario para cada site
		$sql = "SELECT si_cod FROM ".$config['bdprefixo']."_eva_site";
		$rs = $eva['sql']->executar($sql);		
		while ($linha = $rs->FetchRow()){
			$sql = "SELECT 
			ug_gr_cod, gr_acesso, gs_acesso
			FROM 
				".$config['bdprefixo']."_eva_usuario_grupo ,
				".$config['bdprefixo']."_eva_grupo LEFT JOIN
				".$config['bdprefixo']."_eva_grupo_site
				ON gr_cod = gs_gr_cod
				AND	gs_si_cod = ".$linha['SI_COD']."
			WHERE 
				ug_us_cod = ".intval($us_cod)." 
			AND 
			gr_cod = ug_gr_cod";
			$rs_gr = $eva['sql']->executar($sql);
			if($rs_gr){
				$acesso = array();
				while ($arr_gr = $rs_gr->FetchRow()) {
					for ($i=0;$i<strlen($arr_gr['GS_ACESSO']);$i++){
						$acesso[$i] = (isset($acesso[$i]))? $acesso[$i] : 0;
						$valor = ord(substr($arr_gr['GS_ACESSO'], $i, 1));
						if (!((intval($valor) & intval($acesso[$i]))==intval($valor)) || $valor == 0){
							$acesso[$i]+=$valor;
						}
					}
				}
			}
			$acesso = array_map("chr", $acesso);
			$acesso_site["{$linha['SI_COD']}"] = implode("", $acesso);
		}
		return $acesso_site;
	}
}
?>