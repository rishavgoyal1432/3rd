<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
 * Classe de usu�rios
 *
 */
class eva_usuario{
	/**
	 * Retorna quas sao os valores e tipos das extensoes criadas para os grupos deste usuario
	 *
	 * @param int $us_cod
	 * @param int $gr_cod
	 * @return array
	 */
	function usuario_extensao_campos($us_cod="", $gr_cod=""){
		if(empty($us_cod) && empty($gr_cod))
			return false;
		global $eva, $config;
		$grupos=array();
		if(!empty($us_cod)){
			$sql = "SELECT ug_gr_cod
				FROM 
					".$config['bdprefixo']."_eva_usuario_grupo
				WHERE
					ug_us_cod = ".intval($us_cod)."
				";
			$rs = $eva['sql']->executar($sql);
			while($linha = $rs->FetchRow()){
				$grupos[] = $linha['UG_GR_COD'];
			}
		}
		if(!empty($gr_cod)){
			if(!is_array($gr_cod))
				$gr_cod=explode(",", $gr_cod);
			$grupos = array_merge_recursive($grupos, $gr_cod);
		}
		$grupos = array_unique($grupos);
		sort($grupos);
		$campos=array();
		for($i=0;$i<count($grupos);$i++){
			$sql = "SELECT ex_cod, ex_gr_cod, ex_tipo, ex_validador, ex_editar, en_nome, ex_en_cod
				FROM 
					".$config['bdprefixo']."_eva_us_extensao,
					".$config['bdprefixo']."_eva_us_extensao_nome
				WHERE
					ex_gr_cod = ".intval($grupos[$i])."
				AND
					en_cod = ex_en_cod
				";
			$rs = $eva['sql']->executar($sql);
			while($linha = $rs->FetchRow()){
				if(intval($linha['EX_EDITAR']) || $eva['seguranca']->verificar_acesso('admin', "eva_usuario"))
					$campos[]  = $linha;
			}
		}
		//$campos = array_unique($campos);
		return $campos;
	}
	
	/**
	 * coloca na classe form os itens de extensao do usuario que foram configuradas no grupo
	 *
	 * @param int $us_cod
	 * @param int $gr_cod
	 * @param bool $avancado
	 */
	function extensao_form_dados($us_cod="", $gr_cod="", $avancado = false){
		global $eva, $config;
		//$dados = "";
		if($campos = $this->usuario_extensao_campos($us_cod, $gr_cod)){	
			$temp_arr = array();			
			for($i=0;$i<count($campos);$i++){
				$valor = "";
				if(!empty($us_cod)){
					$valor = $this->extensao_valor($us_cod, $campos[$i]['EX_COD'], $campos[$i]['EX_TIPO']);
				}
				// verifica se o nome do campo esta duplicado pois pode ter 2 grupos pedindo a mesma coisa, se ja foi preenchido o valor de algum destes grupos este permanece
				if(isset($temp_arr[$campos[$i]['EX_EN_COD']])){					
					$eva['form']->alterar_campo(
					"ex_cod_{$temp_arr[$campos[$i]['EX_EN_COD']]['cod']}_{$temp_arr[$campos[$i]['EX_EN_COD']]['tipo']}",
					"ex_cod_{$temp_arr[$campos[$i]['EX_EN_COD']]['cod']}-{$campos[$i]['EX_COD']}_{$temp_arr[$campos[$i]['EX_EN_COD']]['tipo']}-{$campos[$i]['EX_TIPO']}",
					"","", $valor, "", "", $campos[$i]['EX_VALIDADOR']);
					$temp_arr[$campos[$i]['EX_EN_COD']]['cod'].="-".$campos[$i]['EX_COD'];
					$temp_arr[$campos[$i]['EX_EN_COD']]['tipo'].="-".$campos[$i]['EX_TIPO'];
					continue;
				}
				$temp_arr[$campos[$i]['EX_EN_COD']]['cod'] = $campos[$i]['EX_COD'];
				$temp_arr[$campos[$i]['EX_EN_COD']]['tipo'] = $campos[$i]['EX_TIPO'];
				$eva['form']->campo(
				"ex_cod_{$campos[$i]['EX_COD']}_{$campos[$i]['EX_TIPO']}",
				(($campos[$i]['EX_TIPO']=="c")?"":$campos[$i]['EN_NOME']),
				(($campos[$i]['EX_TIPO']=="c")?"checkbox":"text"), // se for to tipo c coloque um checkbox
				(($campos[$i]['EX_TIPO']=="c")?array($valor):$valor), 
				(($campos[$i]['EX_TIPO']=="c")?array("1"=>$campos[$i]['EN_NOME']):""), 
				"", 
				$campos[$i]['EX_VALIDADOR'],
				"",
				"",
				$avancado
				);				
			}
		}
		//return $dados;
	}
	/**
	 * Retorna o valor de uma extensao
	 *
	 * @param int $us_cod
	 * @param int $ex_cod
	 * @param string $tipo
	 * @return string
	 */
	function extensao_valor($us_cod, $ex_cod, $tipo){
		global $eva, $config;
		$this->set_tipo($tipo);		
		$sql = "SELECT e{$this->ex_tipo}_valor
			FROM 
				".$config['bdprefixo']."_eva_us_extensao_{$this->ex_tipo_tabela}
			WHERE
				e{$this->ex_tipo}_us_cod = ".intval($us_cod)."
			AND
				e{$this->ex_tipo}_ex_cod = ".intval($ex_cod)."
			";
		$rs = $eva['sql']->executar($sql);
		if($linha = $rs->FetchRow()){
			return ($tipo=='n')?number_format($linha[strtoupper("E{$this->ex_tipo}_VALOR")], 4, ',', ''):$linha[strtoupper("E{$this->ex_tipo}_VALOR")];
		}
		return "";
	}	
	/**
	 * salva as extensoes
	 *
	 * @param int $us_cod
	 */
	function extensao_salvar($us_cod){
		global $eva, $config;
		// pega todos os valores posts e identifica qual � da extensao
		while(list($nome, $valor)=each($_POST)){
			if(eregi( "^ex_cod_",$nome)){
				//echo $nome."<br>";
				$ex = explode("_", $nome);
				$ex[2] = explode("-", $ex[2]);
				$ex[3] = explode("-", $ex[3]);
				for($i=0;$i<count($ex[2]);$i++){
					$this->set_tipo($ex[3][$i]);
					$sql = "SELECT e{$this->ex_tipo}_cod
					FROM 
						".$config['bdprefixo']."_eva_us_extensao_{$this->ex_tipo_tabela}
					WHERE
						e{$this->ex_tipo}_us_cod = ".intval($us_cod)."
					AND
						e{$this->ex_tipo}_ex_cod = ".intval($ex[2][$i])."
					";
					$rs = $eva['sql']->executar($sql);
					$ex_cod = 0;
					//var_dump($sql);echo "<hr>";
					if($linha = $rs->FetchRow()){
						$ex_cod = intval($linha[strtoupper("e{$this->ex_tipo}_cod")]);
					}
					if(intval($ex_cod)==0){
						$ex_cod = $eva['sql']->selecionar_maior("eva_us_extensao_{$this->ex_tipo_tabela}","e{$this->ex_tipo}_cod");
						$sql = "INSERT INTO 
								".$config['bdprefixo']."_eva_us_extensao_{$this->ex_tipo_tabela}
									(
									e{$this->ex_tipo}_cod, 
									e{$this->ex_tipo}_ex_cod, 
									e{$this->ex_tipo}_us_cod,
									e{$this->ex_tipo}_valor
									)
								VALUES
									(
									$ex_cod,
									{$ex[2][$i]},
									$us_cod,
									'$valor'
									)";
					}else{
						$sql = "UPDATE
									".$config['bdprefixo']."_eva_us_extensao_{$this->ex_tipo_tabela}
								SET 
									e{$this->ex_tipo}_valor = '$valor'
								WHERE
									e{$this->ex_tipo}_cod = $ex_cod";
					}
					if($eva['sql']->executar($sql)){
						//echo "$sql<br>";
					}
				}
			}
		}
	}
	/**
	 * Ajusta o tipo da extensao
	 *
	 * @param string $tipo
	 */
	function set_tipo($tipo){
		if($tipo=='n' || $tipo=='c'){
			$this->ex_tipo=$tipo;
			$this->ex_tipo_tabela="numero";	
		}
		else if($tipo=='v'){
			$this->ex_tipo=$tipo;
			$this->ex_tipo_tabela="varchar";			
		}else{
			$this->ex_tipo=$tipo;
			$this->ex_tipo_tabela="texto";		
		}
	}
} //eva_usuario
?>