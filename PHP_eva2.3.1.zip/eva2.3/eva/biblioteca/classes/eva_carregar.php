<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
* Classe com as funcoes principais para carregar o site
*/
class eva_carregar{
	
	var $total_img_ol;
	
	function eva_carregar(){
	}
	
	/**
	* Seleciona o site a ser exibido
	* @global String Define um array de variaveis globais para $eva['site']
	*/
	function site(){
		global $config;
		global $idioma;
		global $eva;
		$eva['site']["separador"] = " &bull; ";
			
		$sql = "SELECT si_nome, si_desc, si_tema, si_contato FROM ".$config['bdprefixo']."_eva_site WHERE si_cod = ".intval($eva['site']["site"]);
		$rs = $eva['sql']->executar($sql);		
		if ($rs && $rs->RecordCount() > 0){
			$lista = $rs->FetchRow();
			$eva['site']["si_desc"] = $lista['SI_DESC'];
			$eva['site']["si_nome"] = $lista['SI_NOME'];
			$eva['site']["titulo"] = $config['titulo'].$eva['site']["separador"].$lista['SI_NOME'].$eva['site']["separador"].$lista['SI_DESC'];
			$eva['site']["tema"] = $lista['SI_TEMA'];
			$eva['site']["contato"] = $lista['SI_CONTATO'];
		}elseif(isset($config['site']) && intval($config['site']) > 0){
			$sql = "SELECT si_cod, si_nome, si_desc, si_tema, si_contato FROM ".$config['bdprefixo']."_eva_site WHERE si_cod = ".intval($config['site']);
			$rs = $eva['sql']->executar($sql);
			if ($rs && $rs->RecordCount()){
				if ($lista = $rs->FetchRow()){
					$site = $lista['SI_COD'];
					$_GET['site'] = $lista['SI_COD'];
					$eva['site']["site"] = $config['site'];
					$eva['site']["si_desc"] = $lista['SI_DESC'];
					$eva['site']["si_nome"] = $lista['SI_NOME'];
					$eva['site']["titulo"] = $config['titulo'].$eva['site']["separador"].$lista['SI_NOME'].$eva['site']["separador"].$lista['SI_DESC'];
					$eva['site']["tema"] = $lista['SI_TEMA'];
					$eva['site']["contato"] = $lista['SI_CONTATO'];
				}
			}else{
				echo $idioma['erro_site'];
				exit;
			}
		}else{
			$sql = "SELECT si_cod, si_nome, si_desc, si_tema, si_contato FROM ".$config['bdprefixo']."_eva_site";
			$rs = $eva['sql']->executar($sql);
			if ($rs && $rs->RecordCount() > 0){
				$lista = $rs->FetchRow();
				$site = $lista['SI_COD'];
				$_GET['site'] = $lista['SI_COD'];
				$eva['site']["site"] = $lista['SI_COD'];
				$eva['site']["si_desc"] = $lista['SI_DESC'];
				$eva['site']["si_nome"] = $lista['SI_NOME'];
				$eva['site']["titulo"] = $config['titulo'].$eva['site']["separador"].$lista['SI_NOME'].$eva['site']["separador"].$lista['SI_DESC'];
				$eva['site']["tema"] = $lista['SI_TEMA'];
				$eva['site']["contato"] = $lista['SI_CONTATO'];
			}else{
				echo $idioma['erro_site'];
				exit;
			}
		}
	}// site
	
	
	/**
	 * Carrega o tema aqui que a variavel $exibir criada
	 *
	 * @return unknown
	 */
	function tema(){
		/**
		* $exibir = variavel que armazenna o cdigo html que serÃ¡ tratado antes da exibiÃ§Ã£o
		*/
		global $config;
		global $eva;
		
		if(isset($_GET['comando'])){
			$exibir = '{centro}';
		}elseif(isset($_GET['popup']) && $_GET['popup']=="true"){
			$exibir = "<html><head><title>{titulo}</title><link href=\"css/estilo.css\" rel=\"stylesheet\" type=\"text/css\" /><link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\"></head><body>{".implode("}{",$config['blocos'])."}</body></html>";		
		}else if(!empty($eva['site']['tema'])){
			$exibir = @file_get_contents($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/index.htm");
		}else{
			$exibir = "<html><head><title>{titulo}</title><link href=\"".$eva['url_eva']."modulos/eva_config/estilo.css\" rel=\"stylesheet\" type=\"text/css\" /><link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\"></head><body>{".implode("}{",$config['blocos'])."}</body></html>";	
		}		
		if(!$exibir){
			$exibir .= '<html><head><title>{titulo}</title><link href="../../../modulos/eva_config/estilo.css" rel="stylesheet" type="text/css" /><link rel="shortcut icon" href="favicon.ico" type="image/x-icon"></head><body><table width="780" height="100%" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF"><tr><td>{topo}</td></tr><tr><td height="100%" valign="top"><table width="100%" height="100%" cellpadding="0" cellspacing="0"><tr><td height="100%" align="center" valign="top"> {esquerda}</td><td width="100%" height="100%" valign="top"><table width="100%" cellspacing="0" cellpadding="0"><tr><td>{centro}</td></tr></table></td><td align="right" valign="top">{direita}</td></tr></table></td></tr><tr><td>{rodape}</td></tr></table></body></html>';
		}
		if($eva['seguranca']->verificar_acesso('SU') && !empty($_GET['erro'])){
			$exibir = str_replace("</body>", '<div id="debug_ajax" style="height:100px; overflow:auto; border-color:#CCCCCC; border-width:thin; border-style:solid;"></div></body>', $exibir);
		}
		
		// to fix Button Width in IE
		if($eva['geral']->detectar_navegador("IE")){
			$eva['head_css'][] = "
			button{
				border-width: 0px; 
				background-color: transparent; 
				cursor: pointer;
				width:1pt;
				overflow:visible;
				margin:0;
				padding:0 .75em 0 .75em;
			}
			";
		}else{
			$eva['head_css'][] = "
			button{
				border-width: 0px; 
				background-color: transparent; 
				cursor: pointer;
			}
			";
		}
		
		
		// tratar src !=  http
		$exibir = $this->tratar_src($exibir);
		return $exibir;
	}// tema
	
	/**
	* Carrega os Blocos
	* @param string nome do mÃ³dulo
	* @param string endereÃ§o de memÃ³ria para a String Exibir
	* @param int CÃ³digo do Bloco
	*/
	function blocos($exibir = "", $bloco = "", $mo_diretorio = ""){
		global $config;	
		global $eva;
		global $bd;
		$eva['tempo_blocos'] = 0;
		
		if($exibir == ""){
			$exibir = "{".implode("}{",$config['blocos'])."}";
		}
		
		// Configura a variavel $eva_modulo_ok=false pois se nao for achado o bloco '0' este Ã© criado no final do while
		$eva_modulo_ok = false;
		
		// Variaveis do modulo
		$mo_cod = 0;
		$mo_nome = "";
		$mo_atributos = "";
		$componente = array();
		
		// Seleciona o codigo do modulo para depois selecionar os blocos
		if($mo_diretorio != ""){			
			$sql = "SELECT 
				mo_cod, mo_nome, mo_atributos, mo_modelo
				FROM ".$config['bdprefixo']."_eva_modulo 
				WHERE 
				mo_diretorio = '".$mo_diretorio."' 
				AND
				mo_status = 'a'";
			$rs = $eva['sql']->executar($sql);
			if($modulo = $rs->FetchRow()){
				// pega os atributos do modulo atual
				$mo_cod = $modulo['MO_COD'];
				$mo_nome = $modulo['MO_NOME'];
				$mo_atributos = $modulo['MO_ATRIBUTOS'];
				$mo_modelo = $modulo['MO_MODELO'];
			}
			// Caso nÃ£o seja um mÃ³dulo cadastrado, redireciona para o index
			//var_dump($modulo);exit;
			if((isset($modulo['MO_COD']) && intval($modulo['MO_COD']) == 0) || !isset($modulo['MO_COD'])) header("Location: index.php");
		
		}
		
		// Monta um SQL para selecionar todos os grupos que podem ser exibidos
		$or_sql="";
		if(isset($_SESSION["us_grupo"])){
			for($i=0;$i<count($_SESSION["us_grupo"]);$i++){
				$or_sql[]= "bg_gr_cod = ".intval($_SESSION["us_grupo"][$i])."";
			}
		}
		if ($or_sql!=""){
			$or_sql="(".implode(" OR ", $or_sql).") OR";
		}
		$or_sql2=" bl_grupo = 't'";
		if($eva['seguranca']->verificar_acesso()){
			$or_sql2.=" OR bl_grupo = 'u'";
			$or_sql2.=" OR bl_grupo = 'e'";
		}else{
			$or_sql2.=" OR bl_grupo = 'v'";
			$or_sql2.=" OR bl_grupo = 'e'";
		}
		
		// Carrega Blocos
		$gel = "";
		for ($i =0; $i < count($config['blocos']); $i++){
			$posicoes[substr($config['blocos'][$i],0,1)] = $config['blocos'][$i];
			if(isset($_SESSION['eva_blocos']) && $_SESSION['eva_blocos'] === true && ((!isset($_GET['popup']) or $_GET['popup']=="false"))){
				$exibir = str_replace("{".$config['blocos'][$i]."}","<table width=\"100%\" height=\"30\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td id=\"".$config['blocos'][$i]."\">{".$config['blocos'][$i]."}</td></tr></table>",$exibir);
				$gel .= "_gel(\"".$config['blocos'][$i]."\"),";
			}
		}
		if(isset($_SESSION['eva_blocos']) && $_SESSION['eva_blocos'] === true){
			// inclui tabelas para poder mover camadas		
			$eva['onload'][] = "_initDrag([".substr($gel, 0, -1)."]);";
			$eva['head'][] = "<script type=\"text/javascript\" src=\"index.php?comando=jsmini&url={$eva['url_eva']}biblioteca/javascripts/mover_camadas.js\"></script>\n";
		}
		$sql = "SELECT 
					mo_cod,
					mo_nome,
					mo_diretorio, 
					mo_atributos,
					mo_modelo,
					bl_cod,
					bl_posicao,
					bl_titulo,
					bl_exibe,
					bl_ordem,
					bl_atributos,
					bl_tipo,
					bl_modelo,
					bl_modulo_exibe,
					bl_grupo,
					bl_fechar,
					bl_altura,
					bl_largura,
					bl_estouro
				FROM 
					".$config['bdprefixo']."_eva_bloco
					LEFT OUTER JOIN 
					".$config['bdprefixo']."_eva_bloco_grupo
					ON bl_cod = bg_bl_cod
					LEFT OUTER JOIN 			
					".$config['bdprefixo']."_eva_site_bloco 
					ON bl_cod = sb_bl_cod,
					".$config['bdprefixo']."_eva_modulo					
				WHERE";
		if($bloco == 0){
			$sql .= "
					(sb_si_cod = ".intval($eva['site']['site'])." OR bl_cod = 0)
				AND";
		}
		$sql .= "
					bl_mo_cod = mo_cod
				";
		if($_GET['bloco'] > 0 && $bloco == 0){
			$sql .= "
				AND 
					bl_posicao != 'c'";
		}
		if(!((isset($_GET['popup']) && $_GET['popup']=="true") && $eva['seguranca']->verificar_acesso("SU","eva_bloco"))){
			$sql .= "
				AND 
					bl_ativo = 'a'";
		}
		$sql .= "
				AND
					mo_status = 'a'
				AND
					({$or_sql}  {$or_sql2})";
		$eva_modulo_ok = false;
		if($bloco > 0 || (isset($_GET['popup']) and $_GET['popup']=="true")){
			$sql .= "
				AND 
					bl_cod = ".$bloco;
			$eva_modulo_ok = true;
		}
		$sql .= "
				ORDER BY 
					bl_ordem";
		$rs = $eva['sql']->executar($sql);
		
		if($rs && $rs->RecordCount() > 0){
			while ($eva_bloco = $rs->FetchRow()) {
				// Caso o bloco seja definido mas nao seja o atual do loop
				if($bloco > 0 && $bloco != $eva_bloco['BL_COD']) continue;
								
				// Inicializando componente para montagem de blocos
				$componente = array();
				
				// Simulando DISTINCT - bloco so aparecera uma vez			
				if((!isset($eva['multiplo']) || (isset($eva['multiplo']) && $eva['multiplo'] == false)) && isset($eva['lista_blocos']) && in_array($eva_bloco['BL_COD'],$eva['lista_blocos'])) continue;
				$eva['lista_blocos'][] = $eva_bloco['BL_COD'];
				$componente = array();
				$componente['tempo'] = $eva['geral']->getmicrotime();
				$bl_modulo_exibe = explode(";", $eva_bloco['BL_MODULO_EXIBE']);
			
								
				if(in_array($mo_cod, $bl_modulo_exibe) || $eva_bloco['BL_COD'] == 0 || $eva_bloco['BL_COD'] == $bloco){
					// verifica se esta no modulo de conteudo e se a se��o � compativel
					// verifica se passou o GET co_cod e pega a se��o ou se_cod
					$se_cod = 0;
					if(!empty($_GET['se_cod'])){
						$se_cod = $_GET['se_cod'];
					}else if(!empty($_GET['co_cod'])){
						//pega a secao deste conteudo 
						$eva['incluir']->incluir_modulo("eva_conteudo");
						$secao = $eva['modulo_eva_conteudo']->secao($_GET['co_cod']);
						$se_cod = $secao['SE_COD'];
					}
					//verifica se o cod da secao esta na listagem	
					$eva['incluir']->incluir("geral");			
					// empty($_GET['a']) � para so exibir o bloco quando estiver exibindo o conteudo nao nas outras operacoes
					/*	 DEBUG
					echo "<hr>";
					echo $eva_bloco['BL_TITULO']."<br>";
					var_dump($bl_modulo_exibe);echo "<br>";
					var_dump($se_cod);echo "<br>";
					var_dump(!empty($se_cod));echo "<br>";
					var_dump(!empty($_GET['a']));echo "<br>";
					var_dump(!in_array("s".$se_cod, $bl_modulo_exibe));echo "<br>";
					var_dump($eva['geral']->array_ereg("s[0-9]+", $bl_modulo_exibe));echo "<br>";echo "<br>";
					var_dump(!empty($se_cod)); 
					var_dump(!empty($_GET['a']) || !in_array("s".$se_cod, $bl_modulo_exibe));
					var_dump($eva['geral']->array_ereg("s[0-9]+", $bl_modulo_exibe));
					echo "<br>";
					*/
					if((!empty($se_cod) || !empty($_GET['bloco']) || $_GET['acao'] == 'conteudo')&& (!empty($_GET['acao']) || !in_array("s".$se_cod, $bl_modulo_exibe)) && $eva['geral']->array_ereg("s[0-9]+", $bl_modulo_exibe)){
					//se nao estiver marque continue e nao monte o bloco
						continue;
					}
					// termina verifica��o de secao
					$componente['mo_cod'] = $eva_bloco['MO_COD'];
					$componente['bl_atributos'] = stripslashes($eva_bloco['BL_ATRIBUTOS']);
					//var_dump($componente['bl_atributos']);echo "<br>";var_dump($eva_bloco['BL_ATRIBUTOS']);echo "<br>".__LINE__."<hr>";
					$componente['mo_atributos'] = $eva_bloco['MO_ATRIBUTOS'];
					$componente['bl_cod'] = $eva_bloco['BL_COD'];
					$componente['bloco'] = $bloco;
					$componente['estouro'] = $eva_bloco['BL_ESTOURO'];
					$componente['largura'] = $eva_bloco['BL_LARGURA'];
					$componente['altura'] = $eva_bloco['BL_ALTURA'];
					$componente['fechar'] = $eva_bloco['BL_FECHAR'];
					$componente['posicao'] = $posicoes[$eva_bloco['BL_POSICAO']];
					$componente['ordem'] = $eva_bloco['BL_ORDEM'];
					$componente['tipo'] = (isset($_GET['bl_tipo']) && $_GET['bl_tipo'] != "") ? $_GET['bl_tipo'] : trim($eva_bloco['BL_TIPO']);
					if($eva_bloco['BL_COD'] == 0 and !isset($_GET['bl_tipo'])){
						$eva_modulo_ok = true;
						if($mo_diretorio == "eva_index"){
							continue;
						}
						$componente['mo_atributos'] = $mo_atributos;
						$componente['mo_cod'] = $mo_cod;
						$componente['modulo'] = $mo_diretorio;
						$componente['titulo_nome'] = $mo_nome;
						$componente['titulo'] = $mo_nome;
						$componente['modelo'] = $mo_modelo;
						$componente['arquivo'] = "index.php";
						$componente['fechar'] = (isset($_GET['popup']) && $_GET['popup']=="true")? 0 : $eva_bloco['BL_FECHAR'];
						$eva['site']["titulo"] = $eva['site']["titulo"].$eva['site']["separador"].$componente['titulo_nome'];
					}else{
						$componente['modulo'] = $eva_bloco['MO_DIRETORIO'];
						$componente['titulo'] = (intval($eva_bloco['BL_EXIBE'])) ? $eva_bloco['BL_TITULO'] : "";
						$componente['titulo_nome'] = $eva_bloco['BL_TITULO'];
						$componente['modelo'] = $eva_bloco['BL_MODELO'];
						$componente['arquivo'] = "eva_blocos.php";
						$componente['fechar'] = (isset($_GET['popup']) && $_GET['popup']=="true")? 0 : $eva_bloco['BL_FECHAR'];
					}
					
					if($bloco == $eva_bloco['BL_COD']){
						$componente['posicao'] = "centro";
						$componente['ordem'] = "1";					
					}		
					
					if(isset($_GET['popup']) && $_GET['popup']=="true"){
						$componente['titulo'] = (isset($_GET['titulo']) && trim($_GET['titulo']) == "vazio")? "" : $componente['titulo'];
						$componente['titulo'] = (isset($_GET['bl_titulo']) && trim($_GET['bl_titulo']) != "") ? $_GET['bl_titulo'] : $componente['titulo'];
					}
					if((isset($_GET['popup']) && $_GET['popup']=="true") || $componente['bl_cod'] == 0){
						$componente['modelo'] = (isset($_GET['modelo']) && $_GET['modelo'] != "") ? $_GET['modelo'] : $componente['modelo'];
					}
					
					// Cache de blocos
					$onload_temp = $eva['onload'];
					$onunload_temp = $eva['onunload'];
					$head_temp = $eva['head'];
					$script_temp = $eva['script'];
					$ajax_temp = $eva['ajax'];
					
					$eva['onload'] = array();
					$eva['onunload'] = array();
					$eva['head'] = array();
					$eva['script'] = array();
					$eva['ajax'] = array();
					
					// Id para a secao deste bloco
					$bl_id = 'bl_'.$eva['site']['site'].$eva_bloco['BL_COD'];
					$bl_id .= ($bloco == $eva_bloco['BL_COD'])? '_popup' : '';
					
					if(@in_array($componente['bl_cod'], $_SESSION['no_cache']) || intval($eva_bloco['BL_COD']) == 0 || $bloco == $eva_bloco['BL_COD'] || isset($_SESSION['eva_blocos']) || !empty($_GET['atualizar']) || empty($_SESSION[$bl_id]['bloco'])){
						//echo $componente['bl_cod']."<br>";
						$componente['bloco'] = $this->montar($componente);
						$_SESSION[$bl_id]['bloco'] = $componente['bloco'];
						$_SESSION[$bl_id]['onload'] = $eva['onload'];
						$_SESSION[$bl_id]['onunload'] = $eva['onunload'];
						$_SESSION[$bl_id]['head'] = $eva['head'];
						$_SESSION[$bl_id]['script'] = $eva['script'];
						$_SESSION[$bl_id]['ajax'] = $eva['ajax'];						
					}else{
						$componente['bloco'] = $_SESSION[$bl_id]['bloco'];
						$eva['onload'] = $_SESSION[$bl_id]['onload'];
						$eva['onunload'] = $_SESSION[$bl_id]['onunload'];
						$eva['head'] = $_SESSION[$bl_id]['head'];
						$eva['script'] = $_SESSION[$bl_id]['script'];
						$eva['ajax'] = $_SESSION[$bl_id]['ajax'];
					}
					//var_dump($_SESSION[$bl_id]['script']);
					
					$eva['onload'] = array_unique(array_merge_recursive($onload_temp,$eva['onload']));
					$eva['onunload'] = array_unique(array_merge_recursive($onunload_temp,$eva['onunload']));
					$eva['head'] = array_unique(array_merge_recursive($head_temp,$eva['head']));
					$eva['script'] = array_unique(array_merge_recursive($script_temp,$eva['script']));
					$eva['ajax'] = array_unique(array_merge_recursive($ajax_temp,$eva['ajax']));					
					$exibir = str_replace("{{$componente['posicao']}}", $componente['bloco']." {{$componente['posicao']}}",$exibir);
					
					/*
					
					// Atual
					$componente['bloco'] = $this->montar($componente);
					$exibir = str_replace("{{$componente['posicao']}}", $componente['bloco']." {{$componente['posicao']}}",$exibir);
					
					*/
					
					if($bloco !== ""){
						$this->limpar($exibir,$componente['posicao']);
					}
				}
			}
		}
		
		if($_GET['bloco'] == 0 && !$eva_modulo_ok && $bloco != 0 && (!isset($_GET['popup']) || $_GET['popup']=="false" )){
			$sql2 = "INSERT INTO 
						{$config['bdprefixo']}_eva_bloco 
					VALUES
						(0, 2, 'c', 'a', 'Modulo', 0, 0, '', '', 'vazio', '', 't', 0, 0, 0, '')";
			$rs2 = $eva['sql']->executar($sql2);
			$this->blocos("eva_modulo", $exibir, 0);
		}
		if($bloco !== ""){
			return $componente;
		}
		return $exibir;
	}// blocos
	
	/**
	* Incluir componentes de script, header e onload dos blocos
	* @param string Tipo: script, header, onload, unload
	* @param string Valor: Script ou tags a serem incluidas
	*/
	function incluir($tipo, $valor){
		global $eva;		
		$eva[$tipo][] = $valor;
		// Descobrir a qual bloco pertenco o onload
		// $_SESSION[''];
	}// incluir
	
	
	/**
	 * Monta os blocos que serao exibidos
	 *
	 * @param array $componente Endere�os de mem�ria para o array com os componentes necess�rios para montar o bloco
	 * @return string
	 */
	function montar(&$componente){
		global $config;
		global $idioma;
		global $eva;
		global $bd;
		//global $bl_atributos;
		$bloco = "";		
		$modelo = "";
		

		if(is_file($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$componente['modelo']) && $componente['modelo'] != "padrao" && $componente['modelo'] != "vazio"){
			$modelo = @file_get_contents($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$componente['modelo']);
		}
		if($modelo == "" || $componente['modelo'] == "" || $componente['modelo'] == "padrao"){
			if($componente['modelo'] == "vazio"){
				$modelo = "<div>";
				if(trim($componente['titulo']) != "" || intval($componente['fechar']) ){
					$modelo .= "<div>{titulo} {fechar}</div>";
				}
				$modelo .= "{bloco}</div>";
			}else{
				$modelo = "<fieldset>";
				if(trim($componente['titulo']) != "" || intval($componente['fechar']) ){
					$modelo .= "<legend><label>{titulo}{fechar}</label></legend>";
				}
				$modelo .= "{bloco}</fieldset>";
			}
		}
		// Trata src !=  http
		$modelo = $this->tratar_src($modelo);
		
		//pegar o cookie e comparar com o bloco para saber se deve mostra-lo ou nao pare 1 de 1
		if(!isset($_COOKIE['blocos_visiveis'])){
			$_COOKIE['blocos_visiveis'] = "";
			$blocos_visiveis = array();
		}else{
			$blocos_visiveis = explode(",", $_COOKIE['blocos_visiveis']);
		}
		
		//pegar o cookie e comparar com o bloco para saber se deve mostra-lo ou nao parte 2 de 2	
		if (isset($blocos_visiveis[intval($componente['bl_cod'])]) && $blocos_visiveis[intval($componente['bl_cod'])] == "hidden"){
			$mostrar_bloco = "display: none; visibility: hidden;";
			$imagem = "botao_maximizar";
		}else{
			$mostrar_bloco = "visibility: visible;";
			$imagem = "botao_minimizar"; 
		}
		$cod_bl_ordem = $componente['bl_cod']."_".$componente['ordem'];
		
		$div_inicio = "";
		$div_fim = "";
		
		if (trim($componente['titulo']) != ""){
			$modelo = str_replace("{titulo}",$componente['titulo'],$modelo);
		}else{
			$modelo = str_replace("{titulo}", "",$modelo);
		}
		
		if (intval($componente['fechar'])){
			$modelo = str_replace("{fechar}","<div class=\"camada_fechar\" onMouseOver=\"this.style.cursor=eva_mouseover;\"><div class=\"{$imagem}\" onClick=\"mostrar_apagar_bloco({$componente['bl_cod']},this);\"></div></div>",$modelo);
		}else{
			$modelo = str_replace("{fechar}", "",$modelo);
		}
		
		$altura = (intval($componente['altura']) > 0)? "height: {$componente['altura']}px;": ((trim($componente['altura']) != "" && trim($componente['altura']) != "0")? trim($componente['altura']) : "");
		$largura = (intval($componente['largura']) > 0)? "width: {$componente['largura']}px;": ((trim($componente['largura']) != "" && trim($componente['largura']) != "0")? trim($componente['largura']) : "");
		
		switch($componente['estouro']){
			case 'a': $estouro = "overflow: auto;"; break;
			case 'h': $estouro = "overflow: hidden;"; break;
			case 's': $estouro = "overflow: scroll;"; break;
			case 'i': $estouro = "overflow: inherit;"; break;
			default: $estouro = ""; break;
		}
		
		if(isset($_SESSION["us_acesso"][$eva['site']["site"]])){
			$eva['modulo_dados']['acesso_modulo'] = ord(substr($_SESSION["us_acesso"][$eva['site']["site"]], (intval($componente['mo_cod'])-1), 1));	
		}else{
			$eva['modulo_dados']['acesso_modulo'] = "";	
		}
		$eva['modulo_dados']['mo_diretorio'] = $componente['modulo'];
		$eva['modulo_dados']['mo_cod'] = $componente['mo_cod'];
		$eva['modulo_dados']['mo_atributos'] = @unserialize($componente['mo_atributos']);
		$bl_cod = $componente['bl_cod'];
		$bl_titulo = $componente['titulo'];
		$bl_titulo_nome = $componente['titulo_nome'];
		$bl_atributos = @unserialize($componente['bl_atributos']);
		$tipo = $componente['tipo'];
		$bl_modelo = explode("{bloco}",trim($modelo));
		$eva['aba'] = "__0";
		// Inicia o armazenamento do bloco em memoria
		$eva['seguranca']->inicia_ob_start(false);
		
		// Se o usuario Ã© SU do modulo blocos exibe marcacao de inicio e fim
		// Se a edicao de blocos estiver ativa monta camada movel e botoes
		$bloco_fim = "";
		if($eva['seguranca']->verificar_acesso("SU","eva_bloco")){
			$menu_eva_bloco = "";
			echo "<!-- Bloco {$componente['bl_cod']} -->";
			if(isset($_SESSION['eva_blocos']) && $_SESSION['eva_blocos'] === true && (!isset($_GET['popup']) or $_GET['popup']=="false")){
				$eva['incluir']->incluir("alerta");
				echo "<div id=\"m_{$cod_bl_ordem}\" style=\"position: relative; border: 1px solid #333333; margin:1px;\"><table border=\"0\" width=\"100%\"><tr><td id=\"m_{$cod_bl_ordem}_h\" class=\"menu_botoes\" onMouseOver='this.style.cursor=eva_mouseover;".$eva['alerta']->exibir("imagens/16x16/actions/recur.png", $idioma['clique_arraste'], "right", 5000, 200, "", "retornar").";'><div id=\"t_{$cod_bl_ordem}\"><img src=\"imagens/16x16/apps/kwin.png\" align=\"middle\"><img src=\"imagens/16x16/apps/mousecursor.png\" align=\"middle\"> {$componente['titulo_nome']} [{$cod_bl_ordem}] </div></td></tr></table>";
				$bloco_fim .= "{menu_bloco}</div>";
			}
			$bloco_fim .= "<!-- Fim do Bloco {$componente['bl_cod']} -->";
		}
		
		// Exibindo inicio do modelo
		if(isset($bl_modelo[0])) echo $bl_modelo[0];
		
		echo "<div class=\"camada_bloco\" id=\"bloco{$componente['bl_cod']}\" style=\"{$largura}{$altura}{$estouro}{$mostrar_bloco}\">";
		@chdir($eva['caminho_eva']);
		// Se nao existir o idioma solicitado para este bloco use o br
		if(!file_exists("modulos/{$componente['modulo']}/idiomas/{$config['idioma_padrao']}.php")){
			$idioma_padrao = 'br';
		}else{
			$idioma_padrao = $config['idioma_padrao'];
		}
		//echo getcwd();
		require("modulos/{$componente['modulo']}/idiomas/{$idioma_padrao}.php");
		//echo "modulos/{$componente['modulo']}/idiomas/{$idioma_padrao}.php";exit;
		
		if($componente['bl_cod'] == 0 && (!isset($_GET['popup']) or $_GET['popup']=="false")){
			$eva['incluir']->incluir_modulo("eva_menu");
			$menu['modulo'] = $componente['modulo'];
			$eva['xml']->codificar(false);
			echo $eva['modulo_eva_menu']->criar_menu($menu);
			$eva['xml']->codificar(true);
		}
		// Incuindo classe do modulo
		//echo "modulos/{$componente['modulo']}/{$componente['arquivo']}<br>";
		$eva['incluir']->incluir_modulo($componente['modulo']);
		include("modulos/{$componente['modulo']}/{$componente['arquivo']}");
		unset($eva['modulo_'.$componente['modulo']]);
		echo "</div>";
		
		// se foi setado $no_cache = 1; seta a secao para informar para nao fazer cache deste bloco
		if(!empty($no_cache) and !in_array($componente['bl_cod'], $_SESSION['no_cache']))
			$_SESSION['no_cache'][] = $componente['bl_cod'];
			
		// Exibindo fim do modelo
		if(isset($bl_modelo[1])) echo $bl_modelo[1];
		
		echo $bloco_fim;
		
		$bloco = ob_get_contents();
		ob_end_clean();
		
		if(isset($_SESSION['eva_blocos']) && $_SESSION['eva_blocos'] === true && (!isset($_GET['popup']) or $_GET['popup']=="false")){
			$tempo = $eva['geral']->getmicrotime() - $componente['tempo'];
			$eva['tempo_blocos'] += $tempo;
			$bloco = str_replace("{menu_bloco}", $this->menu_bloco($componente,$tempo),$bloco);
		}
		
		return $bloco;	
	}// montar
	
	/**
	* Carrega somente os itens necessÃ¡rios para o comando quando Ã© passado a variavel $_GET['comando'] e sempre gera o XML
	* @param string Nome do modulo o qual serÃ¡ carregado o comando
	* @return string Variavel com o XML que serÃ¡ exibido
	*/
	function comando($modulo){
		global $eva;
		// reduces the javascript size
		if($_GET['comando']=="jsmini"){
			header('Content-Type: text/javascript');
			$eva['incluir']->incluir('jsmini');
			$eva['jsmini']->set_exception("funcoes.js", 'packer');
			$eva['jsmini']->set_exception("calendar.js", 'packer');
			$eva['jsmini']->set_exception("core.js", 'packer');
			$eva['jsmini']->set_exception("funcoes_abas.js", 'packer');
			$eva['jsmini']->set_exception("coordinates.js", 'packer');				
			$eva['jsmini']->set_exception("css.js", 'packer');
			$eva['jsmini']->set_exception("events.js", 'packer');
			$eva['jsmini']->set_exception("theme.js", 'packer');
			echo $eva['jsmini']->compactar($_GET['url']);
			exit;
		}	
		global $config;	
		global $idioma;
		global $bd;
		// Se nao existir o idioma solicitado para este bloco use o br
		@chdir($eva['caminho_eva']);
		if(!file_exists("modulos/{$modulo}/idiomas/{$config['idioma_padrao']}.php")){
			$idioma_padrao = 'br';
		}else{
			$idioma_padrao = $config['idioma_padrao'];
		}
		$sql = "SELECT 
					mo_cod, 
					mo_atributos 
				FROM 
					".$config['bdprefixo']."_eva_modulo 
				WHERE 
					mo_diretorio = '".$modulo."'";
		$rs = $eva['sql']->executar($sql);
		if($linha = $rs->FetchRow()) {		
			$eva_mo_cod = $linha['MO_COD'];
			$eva['modulo_dados']['mo_diretorio'] = $modulo;
			$eva['modulo_dados']['mo_cod'] = $eva_mo_cod;
			$eva['modulo_dados']['mo_atributos'] = @unserialize($linha['MO_ATRIBUTOS']);
			$_SESSION["us_acesso"]=(isset($_SESSION["us_acesso"]))?$_SESSION["us_acesso"]:"";
			if(!empty($_SESSION["us_acesso"][$eva['site']["site"]]))
				$eva['modulo_dados']['acesso_modulo'] = ord(substr($_SESSION["us_acesso"][$eva['site']["site"]], (intval($linha['MO_COD'])-1), 1));	
			
		}
		
		$_GET['comando_tipo'] = (!empty($_GET['comando_tipo']))? $_GET['comando_tipo'] : "xml";
		$_POST = $this->codificar_utf8($_POST, false);
		header("Cache-Control: no-store, no-cache, must-revalidate");
				
		switch($_GET['comando_tipo']){
			case "sem_header":
				//faz nada
			break;
			case "js_sessao": 
				// Retorna um arquivo JS a ser anexado Ã  pÃ¡gina
				header('Content-type: text/javascript;');
				$eva['incluir']->incluir('jsmini');
				//echo "index.php?".$_SERVER['QUERY_STRING']."\n\n<br><br>\n";
				//echo "setTimeout('".str_replace("'", "\'", $eva['jsmini']->compactar(@$_SESSION['script'][$_GET['comando']], 'packer'))."', 2000);";
				//foreach($_SESSION['script'] as $k=>$v) echo $k."<br>";
				//$_SESSION['script']=array();
				//echo "[".$_GET['comando']."] - \n\n<br>".$_SESSION['script'][$_GET['comando']];var_dump($_SESSION['script']);exit;
				if(!$eva['seguranca']->verificar_acesso())
					$r = $eva['jsmini']->_compact(@$_SESSION['script'][$_GET['comando']], 'packer', 62);
				else
					$r = $eva['jsmini']->_compact(@$_SESSION['script'][$_GET['comando']], 'jsmini');
				echo $r;
				exit;
			break;
			case "js_list": 
				// Retorna um arquivo JS a ser anexado Ã  pÃ¡gina
				header('Content-type: text/javascript;');
				$eva['incluir']->incluir('jsmini', 'arquivo');
				$js = unserialize(base64_decode($_GET['comando']));
				foreach($js as $k => $v){
					//echo "\n{$js[$k]}\n";
					$items_replace = array("-", "_", ".js", " ");
					$js2[$k] = ucfirst(str_replace($items_replace, "", ereg_replace(".+\/", "",$v)));
					//echo "{$js[$k]}\n";
				}
				$nome = implode("", $js2);
				//echo "<br>".$nome;exit;
				$arquivo = "arquivos/cache/{$nome}.js";
				$eva['jsmini']->set_exception("funcoes.js", 'packer');
				$eva['jsmini']->set_exception("calendar.js", 'packer');
				$eva['jsmini']->set_exception("core.js", 'packer');
				$eva['jsmini']->set_exception("funcoes_abas.js", 'packer');
				$eva['jsmini']->set_exception("coordinates.js", 'packer');				
				$eva['jsmini']->set_exception("css.js", 'packer');
				$eva['jsmini']->set_exception("events.js", 'packer');
				$eva['jsmini']->set_exception("theme.js", 'packer');
			
				if($eva['arquivo']->existe($arquivo)){
					echo $eva['arquivo']->ler($arquivo);
				}else{
					$source = "";
					foreach($js as $k => $v){
						//echo $eva['caminho_eva']."biblioteca/javascripts/".$v."\n";
						$source .= $eva['arquivo']->ler($eva['caminho_eva']."biblioteca/javascripts/".$v)."\n";
					}
					$r = $eva['jsmini']->_compact($source, 'jsmini');
					$eva['arquivo']->gravar($arquivo, $r);
					echo $r;
				}
				exit;
			break;
			case "js":
				// Retorna um arquivo JS a ser anexado Ã  pÃ¡gina
				header('Content-type: text/html; charset=utf-8');
			break;
			case "html":
				//faz nada
			break;
			case "validar_img":
				$eva['incluir']->incluir("validar");
				$_GET['size']=isset($_GET['size'])?$_GET['size']:6;
				$_GET['item']=isset($_GET['item'])?$_GET['item']:"us_cad_val";
				$eva['validar']->gerar_texto($_GET['size'], $_GET['item']);
				//ob_end_clean();			
				$eva['validar']->showImage();
				exit;
			break;
			case "arquivo":		
				$eva['incluir']->incluir("arquivo", "img");		
				@$arquivo_path=rawurldecode($_GET['arquivo_path']);
				$fn = explode("/", $arquivo_path); // define what is the suposed file name
				$fn = end($fn);
				@$arquivo_nome=!empty($_GET['arquivo_nome'])?rawurldecode($_GET['arquivo_nome']):$fn;
				@$ctype=!empty($_GET['ctype'])?rawurldecode($_GET['ctype']):$eva['arquivo']->mime_get_type($arquivo_nome);
				if(!empty($_GET['modelo'])){				
					if(is_file($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$_GET['modelo']) && $_GET['modelo'] != "padrao" && $_GET['modelo'] != "vazio"){
						$modelo = @file_get_contents($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$_GET['modelo']);
						// Trata src !=  http
						$modelo = $this->tratar_src($modelo);	
						
						$modelo = str_replace("{titulo}", $config['titulo'],$modelo);
						$modelo = str_replace("{fechar}", "<a onMouseover=\"this.style.cursor=eva_mouseover;\" onClick=\"window.close()\" >Fechar</a>",$modelo);
					}		
					
					//$modelo = str_replace("{titulo}", "",$modelo);
				
				// if the file is a swf file and is not download show the swf with a original size
				}
				
				if(empty($_GET['download']) && eregi('\.SWF$', $arquivo_nome) && empty($_GET['swf'])){
					$w = $eva['img']->image_info($arquivo_path, 'width');
					$h = $eva['img']->image_info($arquivo_path, 'height');
					header('Content-type: text/html; charset=UTF-8');
					$link = $eva['arquivo']->link_download($arquivo_path, $arquivo_nome, 0)."&swf=1";
					// put the swf code
					$swf = "<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0\" width=\"{$w}\" height=\"{$h}\" title=\"{$arquivo_nome}\">
  <param name=\"movie\" value=\"{$link}\" />
  <param name=\"quality\" value=\"high\" />
  <embed src=\"{$link}\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"{$w}\" height=\"{$h}\"></embed>
</object>";
					if(!empty($modelo))
						$swf = str_replace("{bloco}", $swf,$modelo);
					echo $swf;
					exit;
				}else if(!empty($modelo) && $eva['img']->is_image($arquivo_nome)){
					header('Content-type: text/html; charset=UTF-8');
					$img = '<img src="'.$eva['arquivo']->link_download($arquivo_path, $arquivo_nome, 0).'">';
					echo str_replace("{bloco}", $img,$modelo);
				}else{				
					header('Content-type: '.$ctype);
					if(!empty($_GET['download']))
						header('Content-Disposition: attachment; filename="'.$arquivo_nome.'"');					
					echo $eva['arquivo']->ler($arquivo_path);
					exit;
				}
			break;
			case "include":
				$_GET['comando'] = base64_decode($_GET['comando']);//echo $_GET['comando'];
				include($_GET['comando']);
			break;
			default:
				header('Content-type: text/xml');
				$eva['incluir']->incluir("xml");
				$eva['xml']->parseXML("<eva_xml></eva_xml>", true);	
			break;
		}
		// Definindo modulos dos comandos padrao
		switch($_GET['comando']){
			case "autocompletar":
				header('Content-Type: text/plain');
				$eva['modulo_dados']['mo_diretorio'] = "eva_usuario";
			break;
			case "include":
				// se estiver incluindo um modulo inclua a classe dele tambem
				$modulo_include = !empty($_GET['include'])?$_GET['include']:(!empty($modulo_include)?$modulo_include:"");
				if(!empty($modulo_include)){
					//echo $modulo_include;			
					preg_match("/modulos\/(.+)\/(.+)\.php/", $_GET['include'], $modulo_include);
					if(!empty($modulo_include[1])){
						//if(eregi("qreview", $_GET['include']))	echo __LINE__."\n\n".$modulo_include[1];
						$eva['incluir']->incluir_modulo($modulo_include[1]);
					}
					$arr = explode("modulos/" , str_replace(".php", "", $_GET['include']));				
					$eva['xml_include_id'] = ereg_replace("[^A-Za-z0-9]","",end($arr));				
					$eva['xml']->criar_resposta_include($_GET['include']);
				}
			break;			
		}//var_dump($_GET['ob_start']);exit;
		$eva['seguranca']->inicia_ob_start();
		$eva['modulo_dados']['mo_diretorio'] = !empty($eva['modulo_dados']['mo_diretorio'])?$eva['modulo_dados']['mo_diretorio']:"eva_modulo";
		$eva['incluir']->incluir_modulo($eva['modulo_dados']['mo_diretorio']);
		
		@chdir($eva['caminho_eva']);
		//echo getcwd();exit;
		include("modulos/{$eva['modulo_dados']['mo_diretorio']}/idiomas/{$idioma_padrao}.php");
		include("modulos/{$eva['modulo_dados']['mo_diretorio']}/eva_comandos.php");
		
		if($_GET['comando_tipo'] == "xml"){
			if(!empty($_GET['camada'])){
					$camada = $eva['xml']->criar_elemento("camada",$_GET['camada']);
					$_GET['substituir'] = (!empty($_GET['substituir']))? 'false' : 'true';
					$eva['xml']->colocar_atributo("substituir", $_GET['substituir'], $camada);
					$eva['xml']->colocar_no_root($camada);
					unset($camada);			
			}
			
			//adiciona os alertas
			if(isset($eva['alerta']))
				$eva['alerta']->monta_alerta();
			
			
			//echo "<!-- Gravou Js ".date("d/m/y H:i:s")." -->\n";
			$exibir_xml = html_entity_decode($eva['xml']->toString());
			$eva['javascript']->incluir($exibir_xml);
			//var_dump($eva['head_xml']);exit;
			// faz um append no head com a sessao css
			if(!empty($eva['head_css'])){
				for($i=0;$i<count($eva['head_css']);$i++){		
					if(eregi("{", $eva['head_css'][$i])){
						$css = urlencode($_SERVER['QUERY_STRING'])."css";		
						$_SESSION['script'][$css] = $eva['head_css'][$i];
						//echo urlencode($_SERVER['QUERY_STRING'])."\n\n<br>";
						//echo $_SESSION['script'][urlencode($_SERVER['QUERY_STRING'])];exit;
						$head_css = "index.php?comando_tipo=js_sessao&c=".$css;
					}else
						$head_css = $eva['head_css'][$i];
					$xml = $eva['xml']->criar_elemento("eva_xml_css", $head_css);
					$eva['xml']->colocar_no_root($xml);
					unset($xml);
				}
			}
			
			// faz um append no head com a sessao js
			if(!empty($eva['head_xml'])){
				for($i=0;$i<count($eva['head_xml']);$i++){
					$xml = $eva['xml']->criar_elemento("js_sessao", $eva['head_xml'][$i]);
					$eva['xml']->colocar_no_root($xml);
					unset($xml);
				}
			}
			$eva['script'] = array_unique($eva['script']);
			$eva['onload'] = array_unique($eva['onload']);
			//var_dump($eva['onload']);
			if(!empty($eva['script']) || !empty($eva['onload']))
				$_SESSION['script'][urlencode($_SERVER['QUERY_STRING'])] = implode(" ",$eva['script'])." ".implode(" ",$eva['onload']);	
			//var_dump($_SESSION['script']);exit;
			if($_GET['comando_tipo']!="js_sessao" && !empty($_SESSION['script'][urlencode($_SERVER['QUERY_STRING'])])){
				$_xml = $eva['xml']->criar_elemento("js_sessao", "index.php?comando_tipo=js_sessao&c=".urlencode($_SERVER['QUERY_STRING']));
				$eva['xml']->colocar_no_root($_xml);
			}
			echo $eva['xml']->exibir();exit;	
		}
		
		$exibir = ob_get_contents();
		ob_end_clean();
		
		return $exibir;	
	}// comando
	
	/**
	* Codifica uma string como UTF-8 - utilizado pelo array_walk
	* @param string A string
	* @param string Chave no array
	*/
	function codificar_utf8($var, $codificar = true){
		if(is_array($var)){
			while(list($c,$v) = each($var)){
				$var[$c] = $this->codificar_utf8($v,$codificar);
			}
			return $var;
		}else{
			if($codificar) return utf8_encode($var);
			return utf8_decode($var);				
		}
	}// codificar_utf8
	
	
	/**
	* Se sobrou alguma Tag {topo}, {esquerca}, {centro}, {direita}, {rodape} no exibir esta funÃ§Ã£o as retira
	* @param string EndereÃ§o de memoria da variavel $exibir, este serÃ¡ modificado
	* @param string Nome da posiÃ§Ã£o que se irÃ¡ retirar as tags
	*/
	function limpar(&$exibir,$posicao = ""){
		global $config;
		for ($i =0; $i < count($config['blocos']); $i++){
			if($posicao != "" && $config['blocos'][$i] != $posicao)
				continue;
			$exibir = str_replace("{".$config['blocos'][$i]."}", "",$exibir);
		}
	}// limpar
	
	/**
	* gerar um Preload das imagens em javascript
	* @global array acrescenta valores nas variaveis $eva['imagens']
	* @global array acrescenta valores nas variaveis $eva['script']
	*/
	function imagens(){
		global $eva;
		
		//$eva['imagens'][] = "imagens/menu_botoes_mouseover.jpg";
		//$eva['imagens'][] = "imagens/menu_botoes_mousedown.jpg";
		$eva['imagens'][] = "imagens/carregando.gif";
		
		$eva['script'][] = "
		if (document.images){";
		while(list($cod,$imagem) = each($eva['imagens'])){
			if($size = @getimagesize($imagem)){
				$eva['script'][] = "
					imagem = new Image(".$size[0].",".$size[1]."); 
					imagem.src=\"".$eva['url_eva'].$imagem."\";";
			}
		}  
		$eva['script'][] = "
		var eva_img_carregando = document.createElement('eva_img_carregando');
		eva_img_carregando.appendChild(document.createTextNode('<div class=\"carregando\"></div>'));
		}";
	}// imagens
	
	/**
	* Menu dos blocos visiveis quando o usuario se encontra no modo de ediÃ§Ã£o
	* @param array EndereÃ§o de memÃ³ria para o array com os componentes necessÃ¡rios para montar o bloco
	* @param string Valor do tempo utilizado para gerar o modulo em questÃ£o
	* @return string Html e javascript do Menu
	*/
	function menu_bloco(&$componente,$tempo){
		global $idioma;
		global $eva;
		global $bd;
		$menu['titulo'] = $tempo;
		if($componente['bl_cod'] == 0){
			$menu[0]['confirma'] = $idioma['deseja']." ".$idioma['desativar']." ".$idioma['o_modulo']." \'{$componente['titulo']}\'?";
			$menu[0]['img']="imagens/16x16/actions/ok.png";
			$menu[0]['url']="index.php?modulo=eva_modulo&acao=desativar&mo_diretorio={$componente['modulo']}";
			$menu[0]['alt']=$idioma['desativar'];
			
			$menu[1]['img']="imagens/16x16/actions/edit.png";
			$menu[1]['url']="index.php?modulo=eva_modulo&acao=editar&mo_diretorio={$componente['modulo']}";
			$menu[1]['alt']=$idioma['editar'];
			
			$menu[2]['confirma']= $idioma['deseja']." ".$idioma['apagar']." ".$idioma['o_modulo']."  \'{$componente['titulo']}\'";
			$menu[2]['img']="imagens/16x16/actions/edittrash.png";
			$menu[2]['url']="index.php?modulo=eva_modulo&acao=desinstalar&mo_diretorio={$componente['modulo']}";
			$menu[2]['alt']=$idioma['desinstalar'];
		
		}else{		
			$menu[0]['confirma']=$idioma['deseja']." ".$idioma['desativar']." ".$idioma['o_bloco']." \'{$componente['titulo']}\'?";
			$menu[0]['img']="imagens/16x16/actions/ok.png";
			$menu[0]['url']="index.php?modulo=eva_bloco&si_cod={$eva['site']['site']}&desativar_bloco={$componente['bl_cod']}";
			$menu[0]['alt']=$idioma['desativar'];
			
			$menu[1]['img']="imagens/16x16/actions/edit.png";
			$menu[1]['url']="index.php?modulo=eva_bloco&si_cod={$eva['site']['site']}&acao=cadastrar&bl_cod={$componente['bl_cod']}";
			$menu[1]['alt']=$idioma['editar'];
			
			$menu[2]['confirma']=$idioma['deseja']." ".$idioma['apagar']." ".$idioma['o_bloco']."  \'{$componente['titulo']}\'";
			$menu[2]['img']="imagens/16x16/actions/edittrash.png";
			$menu[2]['url']="index.php?modulo=eva_bloco&si_cod={$eva['site']['site']}&apagar_bloco={$componente['bl_cod']}";
			$menu[2]['alt']=$idioma['apagar'];
		}
		//$menu['fundo']=false;
		$menu['alt']='camada';
		$eva['incluir']->incluir_modulo("eva_menu");
		return $eva['modulo_eva_menu']->criar_menu($menu);
	}//  menu_bloco
	
	/**
	 * otimizar a exibi��o
	 *
	 * @param string $exibir
	 */
	function tratar_exibir(&$exibir){
		global $eva;
		
		// Incluindo filtro Alpha no IE para correÃ§Ã£o de transparÃªncia nas Imagens PNG
		$exibir = $eva['exibir']->replacePngTags($exibir, "imagens/","crop");
		
		//Corrigir o caminho das imagens		
		//if(isset($eva['config']['url_eva']) && $eva['url_eva'] != $eva['config']['url_eva'])// se as 2 url forem iguais nao precisa desta funcao
		$exibir = $eva['exibir']->corrigir_url_img($exibir, $eva['url_eva']);
		if(empty($_GET['comando'])){
			// Codificando todas as URLs com variÃ¡veis
			$eva['seguranca']->codificar_get_eva($exibir);
		}
		if(!$eva['seguranca']->verificar_acesso("SU") && !empty($eva['config']['site'])){	
			// retira todos os espacos do html para otimizacao
			$eva['arquivo']->retirar_espacos($exibir);
		}
	}
	
	/**
	 * creates a url history
	 *
	 * @param string $url
	 */
	function add_history($url){
		// add the URL in the begin of the array
		$h['url'] = $url;
		$h['cookie'] = $_COOKIE;
		//var_dump($_COOKIE);
		//array_unshift($this->history, $h);
		$_SESSION['eva_history'][] = $h;
		$t = array_chunk($_SESSION['eva_history'], 10);// the history max size is 10
		$_SESSION['eva_history'] = end($t);
	}
	
	/**
	 * Redirect the page to the history
	 *
	 * @param int $i
	 */
	function redirect($i){
		$h = array_reverse($_SESSION['eva_history']);
		if(!empty($h[$i]['url']))
			$url = $h[$i]['url'];
		else
			$url = "index.php";
		if(!empty($h[$i]['cookie']))
			$_COOKIE = $h[$i]['cookie'];
		//var_dump($h[$i]['cookie']);
		//echo $url;
		header("Location: {$url}");
		//exit;
	}	
	
	/**
	 * Trata o src das tags
	 *
	 * @param unknown_type $html
	 * @param unknown_type $raiz
	 * @param unknown_type $url
	 * @return unknown
	 */
	function tratar_src($html, $raiz = "padrao", $url = "padrao"){
		global $config;
		global $eva;
		$url2 = $url;
		
		if($raiz == "padrao"){
			$raiz = "arquivos/temas/".$eva['site']['tema']."/";
		}
		if($url == "padrao"){			
			$url = $eva['config']['url'];
		}
		if(substr(trim($url),-1) == "/"){
			$url = substr(trim($url),0,-1);
		}
		$url = $url."/".$raiz;
		
		if($url2 != "padrao"){
			$html = preg_replace("/a[\s]+href/i", "a target=\"_blank\" href", $html);
		}
		$html = $eva['exibir']->corrigir_url_img($html,$url);
		$html = preg_replace("/link href=\"/i", "link href=\"".$url, $html);
		$html = preg_replace("/background=\"/i", "background=\"".$url, $html);
		$html = preg_replace("/src=\"/i", "src=\"".$url, $html);
		//$html = preg_replace("/src=\"(?!http)/i", "src=\"".$url, $html);
		//$html = preg_replace("/\/ens\//i", "/imagens/", $html); // nao sei pq acontece isso, isso eh pra concertar o preg anterior
		$html = preg_replace("/embed\s*src=\"/i", "embed src=\"".$url, $html);
		$html=str_replace(($url.$url), $url, $html);
		return $html;
	}
	
	/**
	 * Fun��o para obter os atributos de um m�dulo e retornar um vetor
	 *
	 * @param unknown_type $mo_diretorio
	 * @return unknown
	 */
	function pegar_atributos($mo_diretorio = ""){
		global $eva;
		if($mo_diretorio != ""){
				global $config;
				$sql="SELECT 
						mo_atributos 
					FROM
						 ".$config['bdprefixo']."_eva_modulo 
					WHERE 
						mo_diretorio = '".$mo_diretorio."'";
				$rs = $eva['sql']->executar($sql);	
				if($atributos = $rs->FetchRow()) {
					return unserialize($atributos['MO_ATRIBUTOS']);
				}
		}
		return false;
	}
	
	/**
	 * A imagem sera exibida depois que a pagina carregar, bom para uso de imagens dinamicas, poupa processamento
	 *
	 * @param string $url
	 * @param int $w
	 * @param int $h
	 * @param string $style
	 * @return string
	 */
	function imagem_onload($url, $w='100', $h='100', $style='text-align:center; vertical-align:middle;'){
		global $eva;		
		if(empty($this->total_img_ol)) $this->total_img_ol=1;
		if(!empty($w))
			$w = "width:{$w};";
		else
			$w="";
		if(!empty($h))
			$h = "height:{$h};";
		else
			$h="";
		$id = "img_onload".($eva['contador']++);
		$div = '<div style="'.$w.$h.$style.'" id="'.$id.'"><div class="carregando"></div></div>';
		$img = '<img src=\"'.$url.'\"/>';
		$eva['onload'][] = "setTimeout(\"eva_html('{$id}', '{$img}')\", ".(500*($this->total_img_ol++)).");";
		return $div;
	}
}
?>
