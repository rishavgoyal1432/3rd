<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
// Se nao existir o $eva['incluir'] � pq vc esta instalando o sistema EVA e o $eva['incluir'] nao foi instanciado
if(isset($eva['incluir']) && is_object($eva['incluir'])){
	$eva['incluir']->incluir("validar");
}else{
	require_once("../../biblioteca/classes/eva_validar.php");
	$eva['validar'] = new eva_validar();
}
require_once('adodb/adodb.inc.php');
/**
 * Class to handle sql and databases connections
 *
 */
class eva_sql{
	// Objeto de conex�o com a base de dados
	var $conexao;
	// Variaveis para cache
	var $cache;
	var $cache_dir;
	var $cache_tempo;
	var $cont;
	
	function eva_sql(){
		$this->cont=0;
	}
	
	/**
	 * funcao que retorna um array com todas as tabelas, ou true ou false se voce passar o nm da tabela
	 *
	 * @param string $nome
	 * @return boolean
	 */
	function tabela($nome=""){		
		$dict = NewDataDictionary($this->conexao);
		$tabelas = $dict->MetaTables();
		if(empty($nome))
			return $tabelas;
		else
			return in_array($nome, $tabelas);
	}
	
	
	/**
	 * funcao que retorna um array com todas os indexes de uma tabela, ou true ou false se voce passar o nm da tabela
	 *
	 * @param string $nome
	 * @return boolean
	 */
	function index($table, $nome='', $primary = false, $owner = false){		
		$dict = NewDataDictionary($this->conexao);
		$tabelas = $dict->MetaIndexes($table, $primary, $owner);
		//var_dump($tabelas);var_dump($nome);
		if(empty($nome))
			return $tabelas;
		else
			return !empty($tabelas[$nome]);
	}
	
	/**
	 * funcao que retorna um array com todas as chaves primarias de uma tabela, ou true ou false se voce passar o nm da tabela
	 *
	 * @param string $nome
	 * @return boolean
	 */
	function pk($table, $nome='', $owner = false, $intkey=false){		
		$dict = NewDataDictionary($this->conexao);
		//MetaPrimaryKeys($tab,$owner=false,$intkey=false)
		$tabelas = $dict->MetaPrimaryKeys($table, $owner, $intkey);
		//var_dump($tabelas);var_dump($table);var_dump($nome);
		if(empty($nome))
			return $tabelas;
		else
			return !empty($tabelas[$nome]);
	}
	
	/**
	 * funcao que retorna um array com todas as colunas de uma tabela, ou true ou false se voce passar o nm da tabela
	 *
	 * @param string $nome
	 * @return boolean
	 */
	function colunas($table, $nome='', $primary = false, $owner = false){		
		$dict = NewDataDictionary($this->conexao);
		$tabelas = $dict->MetaColumns($table);
		//var_dump($tabelas);var_dump($nome);
		if(empty($nome))
			return $tabelas;
		else
			return !empty($tabelas[$nome]);
	}
	
	/**
	 * funcao cria um formulario para edicao de tabelas do tipo texto
	 *
	 * @param string $nome
	 * @param int $qnt; quantidade de itens na listagem
	 * @param string $camada
	 * @param string $id
	 * @param string $atributos
	 * @param string $funcao_val
	 * @return string
	 */
	function form_tabela($nome="", $qnt = 20, $camada = "", $id = "", $atributos = array(), $funcao_val="\$f_validador=true;"){		
		global $eva, $idioma, $config;	
		$dict = NewDataDictionary($this->conexao);
		$colunas = $dict->MetaColumns($nome);
		$atributos = array_change_key_case($atributos, CASE_LOWER);
		//var_dump($colunas);	echo "<hr>";var_dump($colunas['ID']);echo "<hr>";
		$eva['incluir']->incluir("form", "xml", "grade");
		$eva['incluir']->incluir_modulo("eva_menu");	
		$grade['campos'][] = "";
		$eva['form']->config("", ucwords(strtolower(str_replace("_", " ", $nome))),"fti_{$nome}","",1);
		//echo $_SESSION['func_form_val']."<hr>";
		if(!empty($_SESSION['func_form_val'])){
			//echo $_SESSION['func_form_val']."<hr>";
			eval($_SESSION['func_form_val']);
			//eval("\$funcao_val=true;");
			//$funcao_val = true; 
		}
		// funcao de validacao
		if(empty($camada)){
			$_SESSION['func_form_val'] = $funcao_val;
		}
		
		//var_dump($_POST);
		
		// se estiver editando ou apagando
		//var_dump($_GET['c_acao']);var_dump($id);
		while (list($key, $val) = each($colunas)){
			$val->name = strtolower($val->name); 
			//se for oracle ele nao detecta, entao pegue o primeiro item da tabela 
			if(@$val->primary_key || (eregi("^oci", $config['bdtipo']) && empty($pk))){
				$pk =  $val->name;
				continue;					
			}	
			if(!@$val->auto_increment){
					$col[] = "{$val->name}";
					if(!empty($atributos[$val->name]['tipo']) && $atributos[$val->name]['tipo'] == "timestamp")
						if(!empty($_POST[$nome."_".$val->name]))
							$col_v[] = "'".$eva['geral']->formatar_data(@$_POST[$nome."_".$val->name])."'";
						else
							$col_v[] = "''";
					else
						$col_v[] = "'".@$_POST[$nome."_".$val->name]."'";
			}	
		}
				
		// acoes do form
		if((!empty($f_validador) && $f_validador) || (!empty($_GET['c_acao']) && $_GET['c_acao']=="apagar")){
			if(!empty($_GET['c_acao']) && !empty($id)){
			if($_GET['c_acao'] == 'editar'){
				$sql = "SELECT * FROM ".$nome." WHERE {$pk} = ".$id;
				$rs = $this->executar($sql);
				$row = $rs->FetchRow();					
			}else if($_GET['c_acao'] == 'apagar'){
				$sql = "DELETE FROM ".$nome." WHERE {$pk} = ".$id;
				$this->executar($sql);
			}else if($_GET['c_acao'] == 'salvar' && !empty($col_v)){// se tiver editando
				if(!empty($_POST[$nome."_".$pk])){
					$sql = "UPDATE {$nome} SET ";
					for($i=0;$i<count($col);$i++){
						$sql .= " {$col[$i]} = {$col_v[$i]} ";
						if(($i+1)<count($col)) $sql .= " , ";
					}
					$sql .= "WHERE {$pk} = ".$_POST[$nome."_".$pk];					
					//echo $sql;
					$this->executar($sql);
				}				
			}
		}else if(!empty($_GET['c_acao']) && $_GET['c_acao'] == 'salvar' && !empty($col_v)){ // se for um novo item
			//verifica se todos os itens nao foram passados vazios
			$blank = 0;
			foreach($col_v as $key => $val){
				if(empty($val) || $val=="''")
					$blank++;			
			}
			if($blank < count($col_v)){
				$sql = "INSERT INTO {$nome} ({$pk},  ".implode(",",$col)." ) VALUES ( ".$this->selecionar_maior($nome,$pk,false).", ".implode(",",$col_v).")";
				$this->executar($sql);
			}
		}
		}
		// fim das acoes
		$where_sql = array();
		reset($colunas);
		//var_dump($colunas);
		$grade['largura'] = array();
		$grade['largura'][] = "30";
		while (list($key, $val) = each($colunas)){
			$val->name = strtolower($val->name); 
			$nome_campo = $nome."_".$val->name;
			if(!empty($atributos[$val->name]['nome'])){
				$titulo_campo = $atributos[$val->name]['nome'];
			}else{
				$titulo_campo = ucwords(strtolower(str_replace("_", " ", $val->name)));
			}
			$maxlength =!empty($val->max_length)?$val->max_length:"";
			if(@$val->auto_increment || @$val->primary_key || (eregi("^oci", $config['bdtipo']) && empty($grade['selecionar']))){
				$grade['selecionar'] = $nome_campo;
				if(!empty($id))
					$eva['form']->campo($nome_campo,$titulo_campo,"hidden",(!empty($row[strtoupper($val->name)]))?$row[strtoupper($val->name)]:"", $maxlength);
				continue;				
			}	else{
				$grade['largura'][] = "";
			}
			// pegue os atributos	
			$obs = !empty($atributos[$val->name]['obs'])?$atributos[$val->name]['obs']:'';
			
			//pegue o FK
			if(!empty($atributos[$val->name]['fk'])){
				$pkey = $dict->MetaPrimaryKeys($atributos[$val->name]['fk']['tabela']);
				$fk_colunas = array_merge($pkey, $atributos[$val->name]['fk']['colunas']);
				$where = "";
				if(!empty($atributos[$val->name]['igual'])){
						$where = " WHERE {$pkey[0]} = '".$atributos[$val->name]['igual']."'";
						$where_sql[] = " {$val->name} = '{$atributos[$val->name]['igual']}' ";
				}
				$sql_att = "SELECT ".implode(",", $fk_colunas)." FROM ".$atributos[$val->name]['fk']['tabela']." ".$where;
				$rs = $this->executar($sql_att);
				while($row2 = $rs->FetchRow()){
					$fk_nome = "";
					for($i=0;$i<count($atributos[$val->name]['fk']['colunas']);$i++){
						$fk_nome .= $row2[strtoupper($atributos[$val->name]['fk']['colunas'][$i])]." ";
					}
					$atributos[$val->name]['opcoes'][$row2[strtoupper($fk_colunas[0])]] = $fk_nome;
				}
			}
			// pegue as opcoes
			if(!empty($atributos[$val->name]['noedit'])){
				$tipo   = "hidden";
				$opcoes = "";
			}else if(!empty($atributos[$val->name]['opcoes'])){
				$tipo   = "select";
				$opcoes = $atributos[$val->name]['opcoes'];
			}else if(!empty($atributos[$val->name]['textarea'])){
				$tipo   = "textarea";
				$opcoes = $atributos[$val->name]['textarea'];
			}else if(eregi('(_cor|_color)', $val->name)){
				$tipo   = "cor";
				$opcoes = "";
			}else if(!empty($atributos[$val->name]['tipo']) && $atributos[$val->name]['tipo'] == "timestamp"){
				$tipo   = "data";
				$opcoes = "";
			}else{
				$tipo   = "text";
				$opcoes = $maxlength;
			}
			$eva['form']->campo($nome_campo,$titulo_campo,$tipo,(!empty($row[strtoupper($val->name)]))?$row[strtoupper($val->name)]:"", $opcoes, $val->not_null, '', $obs);
			if(empty($atributos[strtolower($val->name)]['noedit']))
				$grade['campos'][] = array($titulo_campo, $nome.".".$val->name);
		}
		
		//concatena todos os argumentos em uma string get
		$args = "&id_nome=".$grade['selecionar']."&arg_nome=".$nome."&arg_qnt=".$qnt."&arg_att=".base64_encode(serialize($atributos));
		// passar os argumentos para o modulo/comando parq eu possa ordenar
		
		$orderby = "";
		if(!empty($_GET['orderby']))
			$orderby = "ORDER BY ".$_GET['orderby']." ".(!empty($_GET['orderby_direction'])?$_GET['orderby_direction']:"DESC");
		if(!empty($where_sql))
			$where = "WHERE (".implode( " OR ",$where_sql).") ";
		else
			$where = "";
		$sql = "SELECT * FROM ".$nome." {$where} ".$orderby;
		$rs = $this->executar($sql, false, $qnt);
		if ($rs && $rs->RecordCount()) {
			while($row = $rs->FetchRow()){ 
				$row2=array();
				$row = array_change_key_case($row, CASE_LOWER);
				$link = @$atributos['form_tabela_itemlink']['itemlink'];
				while (list($key, $val) = each($row)){
					$link = str_replace("{{$key}}", $val, $link);						
				}
				reset($row);
				while (list($key, $val) = each($row)){
					$row2[$key] = $row[$key];
					if(!empty($atributos[$key]['opcoes']))
						$row2[$key] = @$atributos[$key]['opcoes'][$val];
					if(!empty($atributos[$key]['noedit']))
						unset($row2[$key]);					
					if(!empty($atributos[$key]['tipo']) && $atributos[$key]['tipo'] == "timestamp"){
						$row2[$key] = date($config['formato_data'], $row2[$key]);
					}if(strtolower(@$atributos['form_tabela_itemlink']['item']) == $key)
						$row2[$key] = "<a href='{$link}'>".$row[$key]."</a>";
						
				}
				$grade['dados'][] = array_values($row2);									
			}
		}
		$_GET['ajax_funcao'] = "comando";
		
		//-------------------
		if(!empty($id)){
			$menu[1]['onclick'] = "cancel_table_item('{$nome}', '{$args}');";		
			$menu[1]['alt'] = $idioma['cancelar'];
			$menu[1]['img'] = "imagens/16x16/actions/button_cancel.png";
			$menu[0]['img'] = "imagens/16x16/actions/filesaveas.png";
		}else{
			$menu[1]['onclick'] ="fti_{$nome}.reset()";		
			$menu[1]['alt'] = 'Reset';
			$menu[1]['img'] = "imagens/16x16/actions/reload.png";
			
			$menu[0]['img'] = "imagens/16x16/actions/filesave.png";
		}
		$add = "";
		if(!empty($_GET['var_get'])){ // se estiver criando um novo item do form_select_table
			$vars = unserialize(base64_decode($_GET['var_get']));
			$add = "setTimeout('add_new_{$vars['nome']}_close()', 1000);";
		}
		$menu[0]['onclick'] = "salvar_table_item('{$nome}', '{$args}');{$add}";		
		$menu[0]['alt'] = $idioma['salvar'];
		
		$eva['form']->menu($menu);
		
		$menu = array();
		//$menu['form_id'] = "bwl_list_{$block}_form";
		
		$menu[0]['onclick'] = "apagar_table_item('{$nome}', '{$args}');";
		$menu[0]['img'] = "imagens/16x16/actions/trash.png";
		$menu[0]['alt'] = "Delete";
		//$menu[1]['confirma'] = $idioma['confirma_apagar'];
		
		$menu[1]['onclick'] = "editar_table_item('{$nome}', '{$args}');";
		$menu[1]['img'] = "imagens/16x16/actions/edit.png";
		$menu[1]['alt'] = "Edit";		
		
		//se for a primeira vez carrege os scripts
		if(empty($camada)){
			$eva['script'][] = "
					function apagar_table_item(f, args){
						if(confirm('{$idioma['confirma_apagar']}')){
							p = pegar_elementos_form('form_tabela_'+f);
							eva_add_html('div_grade_'+f, '<div class=\"carregando\"></div>');
							executar_comando('POST', 'index.php?modulo=eva_modulo&comando=form_tabela&c_acao=apagar'+'&camada=div_grade_'+f+args, true, p, '', '');
						}
						return false;				
					};";
					
			$eva['script'][] = "
					function salvar_table_item(f, args){
						if(!validar_form('fti_'+f))
							return false;
						p = pegar_elementos_form('fti_'+f);
						eva_add_html('div_grade_'+f, '<div class=\"carregando\"></div>');
						executar_comando('POST', 'index.php?modulo=eva_modulo&comando=form_tabela&c_acao=salvar'+'&camada=div_grade_'+f+args, true, p, '', '');
						return false;				
					};";
			
			$eva['script'][] = "
					function editar_table_item(f, args){	
						p = pegar_elementos_form('form_tabela_'+f);
						eva_add_html('div_form_'+f, '<div class=\"carregando\"></div>');
						executar_comando('POST', 'index.php?modulo=eva_modulo&comando=form_tabela&c_acao=editar'+'&camada=div_form_'+f+args, true, p, '', '');
						return false;			
					};";
					
			$eva['script'][] = "
					function cancel_table_item(f, args){	
						eva_add_html('div_form_'+f, '<div class=\"carregando\"></div>');
						executar_comando('POST', 'index.php?modulo=eva_modulo&comando=form_tabela&c_acao=cancelar'+'&camada=div_form_'+f+args, true, '', '', '');
						return false;			
					};";
		}		
		//----------------
		
		if(empty($camada)){
			$r = "<div id='div_form_{$nome}'>".$eva['form']->criar()."</div>";
			$r .= (is_array($rs) && !empty($rs['pg'])?$rs['pg']:"");
			$r .= '<form name="form_tabela_'.$nome.'" id="form_tabela_'.$nome.'">';
			$r .= $eva['modulo_eva_menu']->criar_menu($menu,false);
			$r .= "<div id='div_grade_{$nome}'>".$eva['grade']->grade_tabela($grade)."</div>";
			$r .= $eva['modulo_eva_menu']->criar_menu($menu);
			$r .= '</form>';
			$r .= (is_array($rs) && !empty($rs['pg'])?$rs['pg']:"");
		}else{
			if(eregi('div_form_',$camada)){
				$r = $eva['form']->criar();
			}else if(eregi('div_grade_',$camada)){
				$r = $eva['grade']->grade_tabela($grade);
			}
		}
		
		return $r;
	}
	
	/**
	 * Fun��o para criar a conex�o com o banco
	 *
	 * @param string $tipo
	 * @param string $servidor
	 * @param string $usuario
	 * @param string $senha
	 * @param string $banco
	 * @param Boolean $novo indica for�ar nova conexao
	 * @return object
	 */
	function conectar($tipo,$servidor,$usuario,$senha,$banco = '', $novo = false){
		global $eva,  $config;
		
		$this->tipo = $tipo;
		$this->servidor = $servidor;
		$this->usuario = $usuario;
		$this->senha = $senha;
		$this->banco = $banco;
		
		$config['log'] = (!empty($config['log']))? $config['log'] : 'arquivos/logs';
		// Configurando ADODB
		if(!defined('ADODB_ERROR_LOG_TYPE')) define('ADODB_ERROR_LOG_TYPE',3);
		if(!defined('ADODB_ERROR_LOG_DEST')) define('ADODB_ERROR_LOG_DEST',$eva['caminho'].$config['log'].'/eva_erros_sql.log'); // Log de erros
		if(!defined('ADODB_ASSOC_CASE')) define('ADODB_ASSOC_CASE', 1);
		//$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
		//define('ADODB_ASSOC_CASE', 1);
		require_once('adodb/adodb.inc.php');		
		if(!empty($tipo) && $this->conexao = NewADOConnection($tipo)){
			if($novo)
				$bd = $this->conexao->NConnect($servidor, $usuario, $senha, $banco);
			else
				$bd = @$this->conexao->Connect($servidor, $usuario, $senha, $banco);
			if(!$bd){
				$this->conexao = NewADOConnection($tipo);
				$dict = NewDataDictionary($this->conexao);							
				$sql = @$dict->CreateDatabase($banco);
				if($novo)
					$bd = $this->conexao->NConnect($servidor, $usuario, $senha);
				else
					$bd = @$this->conexao->Connect($servidor, $usuario, $senha);
				$rs = @$this->executar($sql[0]);
				//$dict->SetSchema($banco);
				if(!$rs) return false;
				if($novo)
					$bd = $this->conexao->NConnect($servidor, $usuario, $senha, $banco);
				else
					$bd = $this->conexao->Connect($servidor, $usuario, $senha, $banco);
			}
			if($bd){
				$this->conexao->SetFetchMode(ADODB_FETCH_ASSOC);				
				return $this->conexao;
			}
		}else{
			echo "Tipo do bd nao definido";
		}
		return false;
	}// conectar
		
	/**
	 * Fun��o para ativar o cache
	 *
	 * @param string $dir
	 * @param int $tempo
	 */
	function cache($dir = "",$tempo = 10){
		global $eva;
		$this->cache_tempo = (intval($tempo) > 0)? $tempo : 0;
		//$eva['caminho'] = (!empty($eva['caminho']))? $eva['caminho'] : "";
		//$this->cache_dir = (!empty($dir))? $dir : $eva['caminho']."arquivos/cache/bd";
		$this->cache_dir = (!empty($dir))? $dir : "arquivos/cache/bd";
		if($eva['arquivo']->verificar_diretorio($this->cache_dir) === true){
			// Diret�rio para armazenar arquivos de cache
			global $ADODB_CACHE_DIR;
			$ADODB_CACHE_DIR = $this->cache_dir;
			$this->cache = true;
			return;			
		}else{
			//echo $this->cache_dir; exit;
		}
		$this->cache = false;
	}// cache
	
	/**
	 * Fun��o para criar tabelas
	 *
	 * @param string $tabela
	 * @param array $campos
	 * @param array $indices
	 * @param string $opcoes
	 * @return bool
	 */
	function criar_tabela($tabela,$campos, $indices = array(), $opcoes = ""){
		require_once('adodb/adodb.inc.php');
		$dict = NewDataDictionary($this->conexao);		
		$sql = $dict->CreateTableSQL($tabela, $campos, $opcoes);
		$resposta = $dict->ExecuteSQLArray($sql, false);
		if($resposta < 2) return false;
		if(is_array($indices) && count($indices) > 0){
			while(list($nome,$campos) = each($indices)){
				if(!$this->criar_indice($nome,$tabela, $campos)) return false;
			}
		}
		return true;
	}// criar_tabela
	
	/**
	 * Fun��o para criar tabelas
	 *
	 * @param string $tabela
	 * @return object
	 */
	function apagar_tabela($tabela){
		global $config;		
		$log = (isset($eva['site']))? true : false;
		$sql = "DROP TABLE ".$tabela;
		return $this->executar($sql);
	}// apagar_tabela
	
	/**
	 * Fun��o para ativar o cache
	 *
	 * @param string $nome
	 * @param string $tabela
	 * @param string $campos
	 * @return bool
	 */
	function criar_indice($nome,$tabela,$campos){	
		$dict = NewDataDictionary($this->conexao);
		$sql = $dict->CreateIndexSQL($nome, $tabela, $campos);
		if(!$dict->ExecuteSQLArray($sql)) return false;
		return true;
	}// criar_indice
	
	/**
	 * Fun��o Retorna um array com todas as linhas
	 *
	 * @param object $obj
	 * @return object
	 */
	function pegar_vetor(& $obj){
		$a = array();
		while($f = $obj->FetchRow()){
			$a[]=$f;
		}
		return $a;
	}// pegar_vetor
	
	/**
	 * Registra o sql
	 *
	 * @param string $sql
	 * @return object
	 */
	function log_sql($sql){
		global $eva;
		global $config;
		
		$_SERVER['QUERY_STRING'] = (!empty($_SERVER['QUERY_STRING']))? $_SERVER['QUERY_STRING'] : "";
		$_SERVER['HTTP_HOST'] = (!empty($_SERVER['HTTP_HOST']))? $_SERVER['HTTP_HOST'] : "";
		$_SERVER['REQUEST_URI'] = (!empty($_SERVER['REQUEST_URI']))? $_SERVER['REQUEST_URI'] : "";
		$_SERVER["SCRIPT_NAME"] = (!empty($_SERVER["SCRIPT_NAME"]))? $_SERVER["SCRIPT_NAME"] : "";
		$lo_cod = $this->selecionar_maior("eva_log","lo_cod");
		if($_SERVER['HTTP_HOST'] != "" && $_SERVER['REQUEST_URI'] != ""){
			$lo_url = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']=="on")?"https":"http")."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		}else{
			$lo_url = $eva['config']['url'].$_SERVER["SCRIPT_NAME"].$_SERVER['QUERY_STRING'];
		}
		$tipo = explode(" ",trim($sql));
		
		$sql = "INSERT INTO 
					".$config['bdprefixo']."_eva_log 
					(lo_cod,
					lo_us_cod, 
					lo_data, 
					lo_ip, 
					lo_tipo, 
					lo_url, 
					lo_sql) 
				VALUES 
					(".$lo_cod.",
					".(!empty($_SESSION['us_cod'])?intval($_SESSION['us_cod']):0).", 
					".mktime().", 
					'".$_SERVER['REMOTE_ADDR']."', 
					'".strtoupper($tipo[0])."',
					'".$lo_url."',
					'".str_replace("\'", "", $eva['seguranca']->tratar_seguranca($sql))."')";
		return @$this->executar($sql, false, false, false);
	}// log_sql
	
	// Fun��o para consultas SQL
	// Par�metros: SQL, permitir POST externo, pagina��o, cache
	/**
	 * Fun��o para consultas SQL
	 *
	 * @param string $sql
	 * @param bool $validar permitir POST externo
	 * @param bool $paginacao
	 * @param bool $bdcache
	 * @param int $total
	 * @param bool $log_sql
	 * @return array/object
	 */
	function executar($sql, $validar = false, $paginacao = false, $bdcache = false, $total = NULL, $log_sql = true){
		global $idioma, $config, $eva, $ADODB_CACHE_DIR;
		// different behaivors to php4 and 5
		if($eva['geral']->php5()){
			$this_new = new eva_sql();
			$this_new->conexao = $this->conexao;
			//$this_new->conectar($this->tipo,$this->servidor,$this->usuario,$this->senha,$this->banco);
		}else{
			$this_new = $this;
		}
		
		$resposta = $this_new->resposta = $this_new->rs = NULL;
		
		// Verifica se existe um comando SQL e se a vari�vel $eva['site'] foi definida no index.php
		if ((is_array($sql) && count($sql) == 0) || (!is_array($sql) && trim($sql) == "") || !isset($eva['site'])){
			return false;
		}
		//if($eva['seguranca']->verificar_acesso("SU")){var_dump($sql);echo "<hr>";}
		// Conversor de nomes
		
		$bdconversor = false;
		if(!is_array($sql) && !empty($config['bdconversor']) != "" && (@is_file($config['bdconversor']) || @is_file('../../'.$config['bdconversor']))){
			$config['bdconversor'] = (@is_file($config['bdconversor']))? $config['bdconversor'] : '../../'.$config['bdconversor'];
			if(isset($eva['site']['site'])){
				if(true || !isset($_SESSION['conversor_sql'])){
					include($config['bdconversor']);
					$_SESSION['conversor_sql'] = $c;
				}else{
					$c = $_SESSION['conversor_sql'];
				}
			}else{
				include($config['bdconversor']);
			}		
			if(isset($c) && is_array($c) && count($c) > 0){
				$bdconversor = true;
				$guardar = array();
				$cont = 0;
				$tabela = '';
				
				while(list($original,$novo) = each($c)){
					if($novo == ''){
						$tabela = $original;
						continue;
					}else if($novo == $tabela){
						$tabela_eva = $original;
					}
					if(!eregi($original,$sql) || ($novo != $tabela && !eregi($tabela,$sql))) continue;
					if(!eregi("select", $sql)){
						// O espaco ao final do SQL � para garantir o funcionamento da ER
						$sql = preg_replace("/([\`|\s|,|\.|\(|\)])".$original."([\`|\s|,|\.|\(|\)|=])/i", "\\1".$novo."\\2", $sql." ");
					}else{
						if(!preg_match("/^(SELECT)([\s|\S]+)(FROM)(([\s|\S]+))/i", $sql, $busca)){
							continue;
						}
						
						/*
						$busca[1] = SELECT
						$busca[2] = atributos
						$busca[3] = FROM
						$busca[4] = tabelas e WHERE
						*/
						
						if(!empty($novo) && !empty($tabela) && $tabela != $novo && !eregi($tabela.'.'.$original,$busca[2])){
							$novo = $tabela.'.'.$novo;
						}
						//echo ': '.$original.' -> '.$novo.' _________________   '.$tabela.'<br>';
						
						if(eregi($original.'.*',$busca[2])){						
							$busca[2] = preg_replace("/".$original."\.\*/i", $novo.".* ", $busca[2]." ");
						}
						if(eregi('\('.$original.'\)',$busca[2])){						
							$busca[2] = preg_replace("/\(".$original."\)/i", "(".$novo.")", $busca[2]." ");
						}
						
						if(!eregi('as '.$original,$busca[2])){
							
							if($tabela != $novo && !eregi($original.' as',$busca[2])){
								$busca[2] = preg_replace("/([\`|\s|,|\.|\(|\)])".$original."([\`|\s|,|\.|\(|\)])/i", "\\1".$novo." as ".$original."\\2", $busca[2]." ");
							}else{
								$busca[2] = preg_replace("/([\`|\s|,|\.|\(|\)])".$original."([\`|\s|,|\.|\(|\)])/i", "\\1".$novo."\\2", $busca[2]." ");
							}
						}
						
						$busca[4] = preg_replace("/([\`|\s|,|\.|\(|\)|=])".$original."([\`|\s|,|\.|\(|\)|=])/i", "\\1".$novo."\\2", $busca[4]." ");
						
						//$busca[4] = preg_replace("/ORDER[\s]BY[\s]".$tabela."\./i", "ORDER BY ", $busca[4]." ");
						
						$sql = $busca[1].$busca[2].$busca[3].$busca[4];				
					}					
				}
			}
			// echo "<br />".$sql."<br /><br />";
		} 
		
		// Gravando LOG
		if ($log_sql && isset($config['bdlog']) && intval($config['bdlog']) > 0 && !is_array($sql) && !eregi("select", $sql) && !eregi("eva_log", $sql)){
			$this_new->log_sql($sql);
		}
		
		// Limpando o chache de paginas e SQL
		if (!empty($bdcache) && !is_array($sql) && !eregi("select", $sql) && isset($config['cache_tempo']) && intval($config['cache_tempo']) > 0){
			$eva['incluir']->incluir("cache");
			$eva['cache']->cache_config($config['cache'],$config['cache_tempo']);
			$eva['cache']->flush();
			//$temp = $this_new->conexao->CacheFlush();
		}
		
		// Verifica se necessita de valida��o
		if($validar && isset($_POST['validar_campo']) and trim($_POST['validar_campo']) != ""){
			$campo = explode(";", stripslashes($_POST['validar_campo'])); 
			$alerta = explode(";", stripslashes($_POST['validar_alerta'])); 
			$tipo = explode(";", stripslashes($_POST['validar_tipo']));
			$erros = "";
			
			while(list($chave, $valor) = each($campo)){
				if(empty($valor))
					continue;
				if(strstr($valor, '__')){				
					$temp = explode("__",$valor);
					$temp2 = array_pop($temp);
					$valor = implode("__",$temp);
				}
				$er = (isset($eva['validar']->er))? $eva['validar']->er : "";
				if ($er != "" && !preg_match("/".$er[$tipo[$chave]]."/", trim($_POST[$valor]))){
					$erros .= "- ".$alerta[$chave]."<br />";
				}
			}
			if($erros != ""){
				$eva['alerta']->adicionar('redled', $idioma['erros_encontrados'].":<br />".$erros);
				return false;
			}
		}//var_dump($paginacao);
		if (!$paginacao){
			if(is_array ($sql)){
				for ($i=0;$i<count($sql);$i++){
					if (trim($sql[$i]) != ""){
						//echo "\n<!-- {$sql[$i]} -->";
						//echo "\n{$sql[$i]}<hr>";
						if(!$this_new->executar($sql[$i], false, false, $bdcache)){							
							global $sql_erro;
							echo $eva['alerta']->adicionar("redled", addslashes($this_new->erro()."<br>".$sql[$i]), "fixo");
							$sql_erro=$sql[$i];
							return false;
						}
					}
				}
				return true;
			}
			if(isset($eva['incluir']) && is_object($eva['incluir'])){
				$eva['incluir']->incluir("geral");
			}else{
				require_once("../../biblioteca/classes/eva_geral.php");
				$eva['geral'] = new eva_geral();
			}			
			$inicio = $eva['geral']->getmicrotime();
			
			if(eregi("select", $sql) && intval($config['bdcache']) > 0 && $eva['arquivo']->verificar_diretorio($config['cache']) === true && $bdcache &&  !isset($_GET['comando']) && !isset($_GET['atualizar'])){
				//for cache
				@chdir($eva['caminho']);
				// Executa e guarda os resultados por X segundos
				$resposta['rs'] = $this_new->conexao->CacheExecute(($config['bdcache']*60), $sql);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} -- \n\n";
				//for cache
				@chdir($eva['caminho_eva']);
			}else if(eregi("select", $sql) && intval($bdcache) > 1){
				@chdir($eva['caminho']);
				// Executa e guarda os resultados por X segundos
				$resposta['rs'] = $this_new->conexao->CacheExecute(($bdcache*60), $sql);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} Cache -- \n\n";
				@chdir($eva['caminho_eva']);
			}else{
				// Executando consulta SQL
				//echo "$sql<hr>";var_dump($bdcache);
				//if(eregi("us_obs", $sql)){ var_dump($this); echo $sql;}
				$resposta['rs'] = $this_new->conexao->Execute($sql);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} Cache -- \n\n";
			}				
			// Criando variaveis para analise de performance
			if($eva['seguranca']->verificar_acesso('SU') && isset($_SESSION['eva_blocos']) && $_SESSION['eva_blocos'] === true){
				$tempo = $eva['geral']->getmicrotime() - $inicio;
				$eva['tempo_sql'][] = $tempo."|".$sql;
				$eva['tempo_sql_total'] += $tempo;
			}
			// Exibe erros se eh administrador ou se o sistema ainda nao foi instalado
			if(!$resposta['rs'] && ($eva['seguranca']->verificar_acesso('SU') || !isset($config['site']) || @$eva['recover'])){
				echo $eva['alerta']->adicionar("redled", addslashes($this_new->erro()."<br>".((is_array($sql))?implode("<br>", $sql):$sql)), "fixo");
				//echo $resposta['rs']->sql."<br>";var_dump(!$resposta['rs']);echo "<hr>";
				//echo $this_new->conexao->ErrorMsg()."<hr>";exit;
				return false;
			}
			$resposta['pg'] = "";
			$this_new->resposta = $resposta;
			
			return $this_new;
		}else{
			if(!isset($total)){
				//$sql_temp2 = explode("FROM",$sql);
				//$sql_temp = explode("ORDER BY",$sql_temp2[1]);
				//$sql2 = "SELECT COUNT(*) AS total FROM ".$sql_temp[0];
				//$sql2 = eregi_replace("^SELECT(.)+([^\(]+FROM)", "SELECT COUNT(*) AS total FROM", $sql);
				preg_match_all('/^SELECT(.)+([^\(]+FROM)/Uis',trim($sql),$x);
				$sql2 = str_replace($x[0][0], "SELECT COUNT(*) AS total FROM",$sql);				
				$sql2 = eregi_replace("GROUP.*", "", $sql2);
				$sql2 = eregi_replace("ORDER.*", "", $sql2);
				//var_dump($sql2);var_dump($x);exit;
				
				//echo $sql2."\n<br>\n".$sql;
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} \n {$bdcache}-- \n\n"; 
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} \n {$bdcache}-- \n\n";
				//echo "Antes\n\n";
				$rs = $this_new->executar($sql2, false, false, $bdcache);
				//echo "Depois\n\n";
				if(!$rs)return false;
				$rs2 = $rs->FetchRow();
				$total = $rs2['TOTAL'];
			}
			$string = "";
			$var = "";
			$_SERVER['QUERY_STRING'] = (isset($_SERVER['QUERY_STRING']))? $_SERVER['QUERY_STRING']: "";
			$url = explode("&pagina", $_SERVER['QUERY_STRING']);
			// varre todas as variaveis GET e gera uma nova
			foreach($_GET as $chave => $valor){
			   if($chave != "pagina" && $chave != "eva" && !empty($chave) && !empty($valor) && !is_array($valor)){
					$var.= "&".$chave."=".$valor;
			   }
			}
		   $_GET['pagina'] = (isset($_GET['pagina']))? intval($_GET['pagina']) : 0;
			$pagina_atual = $_GET['pagina'];
			if(!empty($paginacao) && $paginacao > 0)
				$total_paginas = ceil($total/$paginacao);
			else
				$total_paginas = 0;
			$pagina_inicial = 0;
			$pagina_final = $total_paginas;
			if($total_paginas>10){
				$dif = 0;
				if($pagina_atual>$pagina_inicial+5)
					$pagina_inicial = $pagina_atual - 5;
				else
					$dif = 5 - $pagina_atual;
				if($pagina_atual<$pagina_final-5)
					$pagina_final = $pagina_atual + 6 + $dif;
				else
					$pagina_inicial = $pagina_final - 11;
			}
			if($pagina_inicial>0)
				if(!empty($_GET['ajax_funcao'])){
					$string .= ' <a onclick="javascript: '.$_GET['ajax_funcao']."('index.php?pagina=0{$var}');\" onMouseOver='this.style.cursor=eva_mouseover;'>&lt;&lt;</a>";
				}else{
					$string .= " <a href=\"index.php?pagina=0".$var."\">&lt;&lt;</a>";
				}
				//$string .= " <a href=\"index.php?pagina=0".$var."\">&lt;&lt;</a>";
			for($i=$pagina_inicial; $i < $pagina_final ; $i++){
				if($i == $pagina_atual){
					$string .= " <strong><font color=\"red\">".($i+1)."</font></strong>";
				}else{
					if(!empty($_GET['ajax_funcao'])){
						$string .= ' <a onclick="javascript: '.$_GET['ajax_funcao']."('index.php?pagina={$i}{$var}');\" onMouseOver=\"this.style.cursor=eva_mouseover;\">".($i+1).'</a>';
					}else{
						$string .= " <a href=\"index.php?pagina=".$i.$var."\">".($i+1)."</a>";
					}
				}
			}
			if($pagina_final<($total_paginas-1))
				if(!empty($_GET['ajax_funcao'])){
					$string .= ' <a onclick="javascript: '.$_GET['ajax_funcao']."('index.php?pagina=".($total_paginas-1)."{$var}');\" onMouseOver='this.style.cursor=eva_mouseover;'>&gt;&gt;</a>";
				}else{
					$string .= " <a href=\"index.php?pagina=".($total_paginas-1).$var."\">&gt;&gt;</a>";
				}
				
			// o select limit do oracle nao suportou order by
			if(eregi("^oci", $config['bdtipo'])){
				$sql = eregi_replace ( "ORDER BY(.+)$", "", $sql );
			}
			
			$pagina = $_GET['pagina']*$paginacao;
			if(eregi("select", $sql) && intval($config['bdcache']) > 0 && $eva['arquivo']->verificar_diretorio($config['cache']) === true && $bdcache &&  !isset($_GET['comando']) && !isset($_GET['atualizar'])){
				@chdir($eva['caminho']);
				// Executa e guarda os resultados por X segundos
				$resposta['rs'] = $this_new->conexao->CacheSelectLimit(($config['bdcache']*60), $sql,$paginacao,$pagina);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} \n\n {$bdcache} -- \n\n";
				@chdir($eva['caminho_eva']);
			}else if(eregi("select", $sql) && intval($bdcache) > 1){
				@chdir($eva['caminho']);
				// Executa e guarda os resultados por X segundos
				$resposta['rs'] = $this_new->conexao->CacheSelectLimit(($bdcache*60), $sql,$paginacao,$pagina);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} \n\n {$bdcache} -- \n\n";
				@chdir($eva['caminho_eva']);
			}else{
				$resposta['rs'] = $this_new->conexao->SelectLimit($sql,$paginacao,$pagina);
				//if(eregi('messages.id', $sql))echo __LINE__." -- {$sql} \n\n {$bdcache} -- \n\n";
			}	
			
			// Para nao imprimir nada de pagina��o na tela 
			if($total_paginas > 1){
				 $resposta['pg'] = "<div style=\"text-align:center; width:100%;\">".$idioma['pagina']."<strong> ".($pagina_atual+1)."</strong> ".$idioma['de']." ".$total_paginas."<br />".$string."</div>";
			}else{$resposta['pg']="";}
			$resposta['pagina_total']=$total_paginas;   
			$resposta['total'] = $total;
			
			$this_new->resposta = $resposta;
			
			return $this_new;
		}
	}
	
	/**
	 * C�digo para carregar arquivo com SQL e retornar um vetor com as queries
	 *
	 * @param string $file
	 * @return object
	 */
	function carrega_sql($file){
		global $eva;
		$sql = "";
		$lista_sql = array();
		if($arquivo = @fopen($file, "r")){
			while (!feof($arquivo)){
				$sql_temp = trim(fgets($arquivo, 4096));
				if($sql_temp != '' && strpos($sql_temp, '#') === false){
					$sql .= $sql_temp;
				}
			}
			fclose ($arquivo);
		}else{
			return false;
		}
		
		return $this->sql_array($sql);
	}
	
	/**
	 * Transforma uma string em um array de SQLs
	 *
	 * @param string $sql
	 * @return array
	 */
	function sql_array($sql){	
		if(empty($sql))	return "";
		if(!is_array($sql)) $s[0] = $sql;
		else $s = $sql; 
		//echo "<hr>";var_dump($s);echo "<hr>";
		for($j=0;$j<count($s); $j++){
			$tamanho = strlen($s[$j]);
			$valor = false;
			$inicio = 0;
			$comentario = false;
			for ($i=0;$i<$tamanho;$i++) {
				$char = $s[$j][$i];
				if ($char == '\'' && !$comentario){
				  $valor = !$valor;
				}
				if ($char == ';' && !$valor){
				  $pagina = $i - $inicio;
				  $lista_sql[] = trim(substr($s[$j], $inicio, $pagina));
				  $inicio = $i+1;
				}
				if ($char == '\\'){
				  $comentario = true;
				}else{
				  $comentario = false;
				}
			}			
		}
		if(empty($lista_sql)) return '';
		$lista_sql = $this->substituir_palavras($lista_sql);
		if(count($lista_sql)==1) return $lista_sql[0];
		else return $lista_sql;
	}
	
	/* coloque isso antes de chamar a fun��o se vc estiver usando POST e GET para substituir
	while(list($key, $val) = each($_POST)){
	  $chave[]= "{".$key."}";
	  $valor[]=$val;
	} 
	while(list($key, $val) = each($_GET)){
	  $chave[]= "{".$key."}";
	  $valor[]=$val;
	} */
	
	/**
	 * Corrige alguns bugs de quando traz do arquivo
	 *
	 * @param string $palavra
	 * @return string
	 */
	function substituir_palavras($palavra){		
		global $eva;
		global $config;
		global $chave;
		global $valor;		
		//a fun�ao carrega_sql($file) tem alguns bugs esta fun��o eh para corrigir isso e substituir as variaveis $_POST e $_GET pelos respectivos "{key}"
		$eva['substituir_sql']["CASCADEON"] = "CASCADE ON";
		$eva['substituir_sql']["RESTRICTON"] = "RESTRICT ON";
		$eva['substituir_sql']["ACTIONON"] = "ACTION ON";
		$eva['substituir_sql']["{mktime}"] = mktime();
		
		while(list($key, $val) = each($config)){
			$eva['substituir_sql']["{".$key."}"] = $val;
		}
		if(is_array($palavra)){
			for($i=0;$i<count($palavra); $i++){
				$palavra[$i] = strtr($palavra[$i], $eva['substituir_sql']);
			}
		}else{
			$palavra = strtr($palavra, $eva['substituir_sql']);
		}
		return $palavra;
	}
	
	/**
	 * Retorna o pr�ximo c�digo dispon�vel para uma tabela, como um autoincrement
	 *
	 * @param string $tabela
	 * @param string $campo
	 * @param bool $prefixo
	 * @return int
	 */
	function selecionar_maior($tabela, $campo, $prefixo = true){
		global $eva;
		global $config;
		//$campo = strtoupper($campo);
		$tabela = ($prefixo)? $config['bdprefixo']."_".$tabela : $tabela;
		$sql = "SELECT MAX(".$campo.") AS ".$campo." FROM ".$tabela;
		$campo = strtoupper($campo);
		$rs = $this->executar($sql, false, false, false);				
		if($rs){
			$cod = $rs->FetchRow();
			$codigo = intval($cod[$campo]) + 1;
		}else{
			$codigo = 1;
		}
		//echo "<hr>COD: {$codigo}<hr>";
				
		return $codigo;
	}
	
	/**
	 * Return the mysql error
	 *
	 * @return String
	 */
	function erro(){
		return $this->conexao->ErrorMsg();
	}
	
	/**
	 * Create a select field with add and edit ajax options from a table
	 *
	 * @param string $nome table name
	 * @param array $campos the fields will be concat into the select
	 * @param string $valor the default value of the select
	 * @param string $separador the separator of the fields concat
	 * @return HTML select field
	 */
	function form_select_table($nome="", $campos = array(), $valor = "",  $separador = " ", $nome_do_select=""){
		global $eva, $config, $idioma;
		$dict = NewDataDictionary($this->conexao);
		$pk = $dict->MetaPrimaryKeys($nome);
		//var_dump($pk);
		$sql="SELECT * FROM `{$nome}`";
		if(!empty($campos))
			$sql.=" ORDER BY ".implode(", ", $campos);
		$rs = $eva['sql']->executar($sql);		
		if($eva['seguranca']->verificar_acesso('admin', "eva_usuario"))
			$options['--'] = "**{$idioma['adicionar_novo_editar']}";
		$options['-'] = " -- ";							
		$eva['incluir']->incluir("form", "alerta");
		while ($lista = $rs->FetchRow()){
			$v ="";
			if(!empty($campos)){
				foreach($campos as $key  => $value){
					$v .= $lista[strtoupper($value)].$separador;
				}
			}else{
				$v .= next($lista);
			}
			$options[$lista[strtoupper($pk[0])]] = $v;
		}
		
		// serialize todas as variaveis
		$vars['nome']=$nome;
		$vars['campos']=$campos;
		$vars['valor']=$valor;
		$vars['separador']=$separador;		
		$var_get = base64_encode(serialize($vars));
		
		$comp1 = $comp2 = "";
		
		if($eva['seguranca']->verificar_acesso('admin', "eva_usuario")){
			$eva['script'][] = "
			var add_new_{$nome}_camada;
			function add_new_{$nome}_form(x){
				if(x!='--') return;
				try{
					add_new_{$nome}_camada = ".$eva['alerta']->exibir("", "<div id=\"new_{$nome}\" class=\"alerta\" style=\"width:600px; height:300px; overflow:auto; padding:2px;\"></div>", "move", 0, 0, "", "retornar", 6000)."				
					eva_html('new_{$nome}', '<div class=\"carregando\"></div>');
					executar_comando('GET', 'index.php?camada=new_{$nome}&modulo=eva_usuario&comando=form_tabela&tabela_nome={$nome}&var_get={$var_get}' , true, '', '', '');
					return false;
				}catch(e){ /*alert('('+e+') Please, try again later');*/ }
			}
			";
			$eva['script'][] = "
			function add_new_{$nome}_close(){
				executar_comando('GET', 'index.php?camada=add_new_{$nome}&modulo=eva_index&comando=form_select_table&var_get={$var_get}' , true, '', '', '');
				div_close(add_new_{$nome}_camada);
			}
			";
		}
		
		if(empty($_GET['comando']) || $_GET['comando']!="form_select_table"){
			$comp1 = "<div id=\"add_new_{$nome}\">";
			$comp2 = "</div>";			
		}else{
			$valor = ($this->selecionar_maior($nome, $pk[0], false)-1);
		}
		
		if(empty($valor)) $valor = "-";
		
		@$eva['form']->campo((empty($nome_do_select)?$pk[0]:$nome_do_select),'',"select", $valor, $options, "","","","onChange=\"add_new_{$nome}_form(this.value)\"");
		
		
		return $comp1.$eva['form']->montar_campo((empty($nome_do_select)?$pk[0]:$nome_do_select)).$comp2;
	} 
	
	/**
	 * Fetch row using the adodb fetchrow but the return array is all uppercase
	 *
	 * @return array or false if fails
	 */
	function FetchRow(){
		global $eva, $config;
		// $eva['geral']->php5() to fix bug for php5
		//if(!$eva['geral']->php5() && empty($this->rs))
		//var_dump($this->rs->sql);echo "\n\n<br>\n";
		if(empty($this->rs))
			$this->rs = $this->rs();
		//var_dump($this->rs);
		//var_dump($this->rs->recordcount());var_dump($this->rs->sql);echo "\n\n<hr>\n";
		//if(!is_object($this->rs)){var_dump($this->rs->sql);exit;}
		//if($this->cont>=10){ echo __LINE__."<br>";exit;} else {echo __LINE__."<br>";$this->cont++;}
		if($this->rs && $row = $this->rs->FetchRow()){
			if($row){
				return array_change_key_case($row, CASE_UPPER);				
			}else{
				unset($this->rs);
				return false;
			}
		}
		/*
		else if($eva['seguranca']->verificar_acesso('SU') || !isset($config['site']) || @$eva['recover']) || !empty($_GET['erro'])){
			echo $eva['alerta']->adicionar("redled", addslashes($this->erro()."<br>".$sql), "fixo");
			return false;
		}
		*/
	}
	
	/**
	 * Fetch row using the adodb fetchArray but the return array is all uppercase
	 *
	 * @return array or false if fails
	 */
	function FetchArray(){
		global $eva, $config;
		if(empty($this->rs))
			$this->rs = $this->rs();
		if($this->rs && $row = $this->rs->FetchRow()){
			if($row){
				eval("\$row = array('".implode("','", $row)."');");
				return 	$row;			
			}else{
				unset($this->rs);
				return false;
			}
		}
	}
	
	/**
	 * Return the total of records
	 *
	 * @return int
	 */
	function RecordCount(){
		if(empty($this->rs))
			$this->rs = $this->rs();
		if($this->rs)
			return $this->rs->RecordCount();
		else
			return 0;
	}
	
	/**
	 * Return the sql executed
	 *
	 * @return rs
	 */
	function sql(){
		if(empty($this->rs))
			$this->rs = $this->rs();
		if(!empty($this->rs->sql))
			return $this->rs->sql;
		else
			return "ERROR: ".$this->conexao->ErrorMsg();
	}
	
	/**
	 * Return the rs object, some times you have an array for pg and rs
	 *
	 * @return rs
	 */
	function rs(){
		if(is_array($this->resposta)){
			return $this->resposta['rs'];
		}else{
			return $this->resposta;
		}
	}
	
	/**
	 * Move register
	 * 
	 * @param int $i
	 * @return $row
	 */
	function Move($i){
		if(empty($this->rs))
			$this->rs = $this->rs();
		//echo $i."<br>";
		return $this->rs->Move($i);
	}
	
	/**
	 * End of file
	 * 
	 * @return boolean
	 */
	function EOF(){
		if(empty($this->rs))
			$this->rs = $this->rs();
		return $this->rs->EOF;
	}
	
	/**
	 * Table fields
	 * 
	 * @return boolean
	 */
	function fields(){
		if(empty($this->rs))
			$this->rs = $this->rs();
		return $this->rs->fields;
	}
	
	function mysql_version(){
		if (empty($_SESSION['MYSQL_INT_VERSION'])) {
			$result = $this->executar('SELECT VERSION() AS version');
			if ($result) {
				$row   = $result->FetchRow();
				$match = explode('.', $row['VERSION']);
			}
			if (!isset($row)) {
				$_SESSION['MYSQL_INT_VERSION'] = 32332;
				$_SESSION['MYSQL_STR_VERSION'] = '3.23.32';
			} else{
				$_SESSION['MYSQL_INT_VERSION'] = (int)sprintf('%d%02d%02d', $match[0], $match[1], intval($match[2]));
				$_SESSION['MYSQL_STR_VERSION'] = $row['VERSION'];
			}
			//unset($result, $row, $match);
		}
	}
	
	function tablecharset($table){
		if($_SESSION['MYSQL_INT_VERSION'] >= 50000){
			$sql = "SELECT table_collation FROM information_schema.tables where table_name = '{$table}' and table_schema = '{$this->banco}'";
			$rs = $this->executar($sql);
			$row = $rs->FetchRow();
			return $row['TABLE_COLLATION'];
		}else if ($_SESSION['MYSQL_INT_VERSION'] >= 40101) {
			// MySQL 4.1.0 does not support seperate charset settings
			// for databases.
			$sql = "SHOW CREATE TABLE `{$table}`";
			$rs = $this->executar($sql);
			$row = $rs->FetchRow();
			$collate = $row['CREATE TABLE'];
			preg_match("/COLLATE=(.+)/",$collate, $r);
			//echo $row['CREATE TABLE']."<hr>";
			//var_dump($r);
			//exit;
			if(!empty($r[1]))
				return $r[1];
			else{
				preg_match("/CHARSET=(.+)/",$collate, $r);
				if(!empty($r[1]))
					return $r[1];
			}
		}
		return '';
	}
		
	function CacheFlush(){
		global $eva;
		@chdir($eva['caminho']);
		$this->conexao->CacheFlush();
		@chdir($eva['caminho_eva']);
	}
}
?>