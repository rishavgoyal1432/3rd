<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
/**
 * Cache class
 *
 * @author   Avenger <avenger@php.net>, Alessandro <alessandro@evacms.com.br>
 * @version  1.0
 * @update   2005-01-19 10:32:00
 */

class eva_cache {
    
    /**
     * url wanta cached
     *
     * @var string
     */
    var $arquivo;

    /**
     * path to the cache save
     *
     * @var string
     */
    var $diretorio;

    /**
     * cached limit time
     *
     * @var string
     */
    var $tempo_validade;

    /**
     * expire time
     *
     * @var string
     */
    var $tempo_criacao;

    /**
     * Construct function
     *
     * @return void
     */
	function cache() {
	}

    /**
     * Inicia variaveis de configuracao
     *
     * @access public
     * @param string $caminho Cached path
     * @param int $tempo Cached time
     * @return void
     */
    function cache_config($caminho='cache/',$tempo=120) {
		global $eva;
		/*EVA*/
		// Identificando o site com $eva['site']['site'] alterado de $HTTP_SERVER_VARS['REQUEST_URI'] para $_SERVER['QUERY_STRING']
		$_SERVER['QUERY_STRING'] = (isset($_SERVER['QUERY_STRING']))? $_SERVER['QUERY_STRING'] : "";
		//&atualizar=true
		$eva['incluir']->incluir("geral");
        $query_string = preg_replace('/(&atualizar=[\s|\S]+)/','',$eva['site']['site'].$eva['geral']->detectar_navegador().$_SERVER['QUERY_STRING']);
        $this->arquivo = md5($query_string).'.cache';
        $this->diretorio = (substr($caminho,-1) == "/")? $caminho : $caminho."/";
        $this->tempo_validade = $tempo*60;
		@chdir($eva['caminho']);
        if (is_dir($this->diretorio)===false) {
            mkdir($this->diretorio,0777);
        }
        if (file_exists($this->diretorio.$this->arquivo)) {
            $this->tempo_criacao = date(time()-filemtime($this->diretorio.$this->arquivo));
        }
		@chdir($eva['caminho_eva']);
    }

    /**
     * Start the cache
     *
     * @access public
     */
    function start(){
        global $eva;
		$eva['incluir']->incluir('arquivo');
	/*EVA*/
	// Se for enviado algo via post ou se o usu�rio estiver autenticado - n�o gerar cache
		@chdir($eva['caminho']);
        if (isset($_GET['atualizar']) || (!file_exists($this->diretorio.$this->arquivo)) || ($this->tempo_criacao > $this->tempo_validade) || count($_POST) || isset($_SESSION['us_cod'])){
            $eva['seguranca']->inicia_ob_start();
        }else{
			//ob_start("ob_gzhandler");
			$eva['seguranca']->inicia_ob_start();
			$arquivo_cache = $eva['arquivo']->ler($this->diretorio.$this->arquivo);
			
			// Verificando o tempo de cria��o da p�gina atrav�s do cache
			list($usec, $sec) = explode(" ", microtime());
			$tempo_fim = ((float)$usec + (float)$sec);
			$arquivo_cache = eregi_replace("<head>","<!-- Cache: ".($tempo_fim - $eva['tempo_inicio'])." - ".$eva['geral']->detectar_navegador()." --><head>",$arquivo_cache);
			
			// Exibindo cache
			echo $arquivo_cache;
			ob_end_flush();
			exit();
        }
		@chdir($eva['caminho_eva']);
    }

    /**
     * End the cache
     *
     * @access public
     */
    function end() {
		global $eva;
        if(isset($_GET['atualizar']) || (!file_exists($this->diretorio.$this->arquivo)) || ($this->tempo_criacao > $this->tempo_validade) ) {
            @chdir($eva['caminho']);
			if(isset($_GET['atualizar'])){
				@unlink($this->diretorio.$this->arquivo);
			}
			
			$contents = ob_get_contents();
            ob_end_clean(); 
            $fp = fopen($this->diretorio.$this->arquivo,'w'); 
            fputs($fp,$contents); 
            fclose($fp);
			@chmod($this->diretorio.$this->arquivo,0644);
			//ob_start("ob_gzhandler");
			$eva['seguranca']->inicia_ob_start();
            echo $contents;
			ob_end_flush();
			@chdir($eva['caminho_eva']);
			//exit();
        }
    }

    /**
     * Flush all cache
     *
     * @access public
     */
    function flush() {	
		global $eva;
		@chdir($eva['caminho']);
		if ($handle = opendir($this->diretorio)) {		
			while (false !== ($arquivo = readdir($handle))) {
				if ($arquivo != "." && $arquivo != ".." && !is_dir($this->diretorio."/".$arquivo)) {
					@chmod($this->diretorio.$arquivo,0777);
					@unlink($this->diretorio.$arquivo);
				}
			}
		}
		@chdir($eva['caminho_eva']);
        return;
    }
		
	/**
	 * Agrupa os arquivos de funcoes em um unico, reduzindo a quantidade de includes
	 *
	 * @param string $funcoes_cache
	 * @return bool
	 *//*
	function cache_funcoes($funcoes_cache){
		global $eva;
		global $config;
		$eva['incluir']->incluir('arquivo');
		$diretorio = "biblioteca/funcoes/";
		$funcoes = "";
		@chdir($eva['caminho']);
		if ($lista = opendir($diretorio)) {
			while (false !== ($arquivo = readdir($lista))) {
				if($arquivo != "." && $arquivo != ".." && $arquivo != "funcoes.php" && $arquivo!="funcoes_geral.php" && ereg("^.+\.php?", $arquivo)){
					$funcoes .= $eva['arquivo']->ler($diretorio.$arquivo);
				}
			}
			closedir($lista);
		}
		@chdir($eva['caminho_eva']);
		// $eva['arquivo']->retirar_espacos($funcoes);
		if(!$eva['arquivo']->gravar($funcoes_cache, $funcoes)){	
			return false;
		}
		return true;
	}
*/
} //End Class
?>