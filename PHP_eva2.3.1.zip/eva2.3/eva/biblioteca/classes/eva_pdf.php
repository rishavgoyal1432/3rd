<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
include_once("extras/html2fpdf/html2fpdf.php");
class eva_pdf extends HTML2FPDF{		
	
	/**
	 * Constructor
	 *
	 * @param string $font
	 * @param int $size
	 * @return eva_pdf
	 */
	function eva_pdf($font = 'Arial', $size = 11){
		$this->HTML2FPDF();
		//if(!isset(FPDF_FONTPATH))
			//define('FPDF_FONTPATH','font/');
		$this->AddPage();
		$this->SetFont($font,'',$size);		
	}	
	
	/**
	 * Enter description here...
	 *
	 * @param string $html
	 * @param string $name
	 * @param char $dest I = Send to standard output; D=Download file F=Save to local file; S=Return as a string
	 * @return buffer
	 */
	function html2pdf($html, $name='',$dest='S'){
		global $eva;
		$html = strip_tags($html, '<tt><kbd><samp><option><outline><newpage><page_break><s><strike><del><bdo><big><small><address><ins><cite><font><center><sup><sub><input><select><option><textarea><title><form><ol><ul><li><h1><h2><h3><h4><h5><h6><pre><b><u><i><a><img><p><br><strong><em><code><th><tr><blockquote><hr><td><tr><table><div>');// <a><b><i><u><img><font><table><tr><td><div><span><p><br>
		//echo $html;exit;
		$html = $eva['geral']->unhtmlentities($html);	
		$this->WriteHTML($html);
		return $this->Output($name, $dest);
	}

}
?>