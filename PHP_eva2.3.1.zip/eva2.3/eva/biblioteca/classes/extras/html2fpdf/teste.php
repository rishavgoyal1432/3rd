<?php
error_reporting(0);
//include("html2fpdf.php");
define('FPDF_FONTPATH','font/');
require('html2fpdf.php');
$pdf=new HTML2FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',11);
$pdf->WriteHTML('<b>03/03/06 - Rotav�rus: vacina evita 850 �bitos de beb�s por ano</b><br /><img width="180" vspace="5" hspace="5" height="119" border="1" align="left" src="http://www.google.com.br/intl/pt-BR_br/images/logo.gif" alt="ff14a85e077ff814e03ea4a06444daaa.jpg" title="ff14a85e077ff814e03ea4a06444daaa.jpg" />Em uma a&ccedil;&atilde;o pioneira em qualquer servi&ccedil;o de sa&uacute;de p&uacute;blico no mundo, o Sistema &Uacute;nico de Sa&uacute;de (SUS) oferece, a partir do dia 6 de mar&ccedil;o, a vacina contra o rotav&iacute;rus, respons&aacute;vel por grande parte dos casos e &oacute;bitos causados por doen&ccedil;as diarr&eacute;icas agudas em crian&ccedil;as, em todo o mundo. Com a implanta&ccedil;&atilde;o da vacina, o governo federal, os estados e os munic&iacute;pios esperam evitar cerca de 850 mortes nessa faixa et&aacute;ria, a cada ano, no Brasil. A redu&ccedil;&atilde;o corresponde a 34% do total de &oacute;bitos que ocorrem em menores de cinco anos, de acordo com estudos sobre o uso da vacina em crian&ccedil;as. <a href="index.php?eva=cz0xJm09ZXZhX2NvbnRldWRvJmNvX2NvZD0zMw==">leia</a><br />');
$pdf->Output();
// Code added by svarrer 
?>