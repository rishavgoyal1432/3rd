<?php

class cssparser {

  var $css;

  var $html;

  

  function cssparser($html = true) {

    // Register "destructor"

    register_shutdown_function(array(&$this, "finalize"));

    $this->html = ($html != false);

    $this->Clear();

  }

  

  function finalize() {

    unset($this->css);

  }

  

  function Clear() {

    unset($this->css);

    $this->css = array();

    if($this->html) {

      $this->Add("ADDRESS", "");

      $this->Add("APPLET", "");

      $this->Add("AREA", "");

      $this->Add("A", "");

      $this->Add("A:visited", "");

      $this->Add("BASE", "");

      $this->Add("BASEFONT", "");

      $this->Add("BIG", "");

      $this->Add("BLOCKQUOTE", "");

      $this->Add("BODY", "");

      $this->Add("BR", "");

      $this->Add("B", "");

      $this->Add("CAPTION", "");

      $this->Add("CENTER", "");

      $this->Add("CITE", "");

      $this->Add("CODE", "");

      $this->Add("DD", "");

      $this->Add("DFN", "");

      $this->Add("DIR", "");

      $this->Add("DIV", "");

      $this->Add("DL", "");

      $this->Add("DT", "");

      $this->Add("EM", "");

      $this->Add("FONT", "");

      $this->Add("FORM", "");

      $this->Add("H1", "");

      $this->Add("H2", "");

      $this->Add("H3", "");

      $this->Add("H4", "");

      $this->Add("H5", "");

      $this->Add("H6", "");

      $this->Add("HEAD", "");

      $this->Add("HR", "");

      $this->Add("html", "");

      $this->Add("IMG", "");

      $this->Add("INPUT", "");

      $this->Add("ISINDEX", "");

      $this->Add("I", "");

      $this->Add("KBD", "");

      $this->Add("LINK", "");

      $this->Add("LI", "");

      $this->Add("MAP", "");

      $this->Add("MENU", "");

      $this->Add("META", "");

      $this->Add("OL", "");

      $this->Add("OPTION", "");

      $this->Add("PARAM", "");

      $this->Add("PRE", "");

      $this->Add("P", "");

      $this->Add("SAMP", "");

      $this->Add("SCRIPT", "");

      $this->Add("SELECT", "");

      $this->Add("SMALL", "");

      $this->Add("STRIKE", "");

      $this->Add("STRONG", "");

      $this->Add("STYLE", "");

      $this->Add("SUB", "");

      $this->Add("SUP", "");

      $this->Add("TABLE", "");

      $this->Add("TD", "");

      $this->Add("TEXTAREA", "");

      $this->Add("TH", "");

      $this->Add("TITLE", "");

      $this->Add("TR", "");

      $this->Add("TT", "");

      $this->Add("UL", "");

      $this->Add("U", "");

      $this->Add("VAR", "");

    }

  }

  

  function Sethtml($html) {

    $this->html = ($html != false);

  }

  

  function Add($key, $codestr) {

    //$key = strtolower($key);

    //$codestr = strtolower($codestr);

    if(!isset($this->css[$key])) {

      $this->css[$key] = array();

    }

    $codes = explode(";",$codestr);

    if(count($codes) > 0) {

      foreach($codes as $code) {

        $code = trim($code);

        list($codekey, $codevalue) = explode(":",$code);

        if(strlen($codekey) > 0) {

          $this->css[$key][trim($codekey)] = trim($codevalue);

        }

      }

    }

  }

  

  function Get($key, $property) {

    //$key = strtolower($key);

    //$property = strtolower($property);

    

    list($tag, $subtag) = explode(":",$key);

    list($tag, $class) = explode(".",$tag);

    list($tag, $id) = explode("#",$tag);

    $result = "";

    foreach($this->css as $_tag => $value) {

      list($_tag, $_subtag) = explode(":",$_tag);

      list($_tag, $_class) = explode(".",$_tag);

      list($_tag, $_id) = explode("#",$_tag);

      

      $tagmatch = (strcmp($tag, $_tag) == 0) | (strlen($_tag) == 0);

      $subtagmatch = (strcmp($subtag, $_subtag) == 0) | (strlen($_subtag) == 0);

      $classmatch = (strcmp($class, $_class) == 0) | (strlen($_class) == 0);

      $idmatch = (strcmp($id, $_id) == 0);

      

      if($tagmatch & $subtagmatch & $classmatch & $idmatch) {

        $temp = $_tag;

        if((strlen($temp) > 0) & (strlen($_class) > 0)) {

          $temp .= ".".$_class;

        } elseif(strlen($temp) == 0) {

          $temp = ".".$_class;

        }

        if((strlen($temp) > 0) & (strlen($_subtag) > 0)) {

          $temp .= ":".$_subtag;

        } elseif(strlen($temp) == 0) {

          $temp = ":".$_subtag;

        }

        if(isset($this->css[$temp][$property])) {

          $result = $this->css[$temp][$property];

        }

      }

    }

    return $result;

  }

  

  function GetSection($key) {

    //$key = strtolower($key);

    

    list($tag, $subtag) = explode(":",$key);

    list($tag, $class) = explode(".",$tag);

    list($tag, $id) = explode("#",$tag);

    $result = array();

    foreach($this->css as $_tag => $value) {

      list($_tag, $_subtag) = explode(":",$_tag);

      list($_tag, $_class) = explode(".",$_tag);

      list($_tag, $_id) = explode("#",$_tag);

      

      $tagmatch = (strcmp($tag, $_tag) == 0) | (strlen($_tag) == 0);

      $subtagmatch = (strcmp($subtag, $_subtag) == 0) | (strlen($_subtag) == 0);

      $classmatch = (strcmp($class, $_class) == 0) | (strlen($_class) == 0);

      $idmatch = (strcmp($id, $_id) == 0);

      

      if($tagmatch & $subtagmatch & $classmatch & $idmatch) {

        $temp = $_tag;

        if((strlen($temp) > 0) & (strlen($_class) > 0)) {

          $temp .= ".".$_class;

        } elseif(strlen($temp) == 0) {

          $temp = ".".$_class;

        }

        if((strlen($temp) > 0) & (strlen($_subtag) > 0)) {

          $temp .= ":".$_subtag;

        } elseif(strlen($temp) == 0) {

          $temp = ":".$_subtag;

        }

        foreach($this->css[$temp] as $property => $value) {

          $result[$property] = $value;

        }

      }

    }

    return $result;

  }

  

  function ParseStr($str) {

    $this->Clear();

    // Remove comments

    $str = preg_replace("/\/\*(.*)?\*\//Usi", "", $str);

    // Parse this damn csscode

    $parts = explode("}",$str);

    if(count($parts) > 0) {

      foreach($parts as $part) {

        list($keystr,$codestr) = explode("{",$part);

        $keys = explode(",",trim($keystr));

        if(count($keys) > 0) {

          foreach($keys as $key) {

            if(strlen($key) > 0) {

              $key = str_replace("\n", "", $key);

              $key = stripslashes($key);

              $this->Add($key, trim($codestr));

            }

          }

        }

      }

    }

    //

    return (count($this->css) > 0);

  }

  

  function Parse($filename) {

    $this->Clear();

    if(file_exists($filename)) {

      return $this->ParseStr(file_get_contents($filename));

    } else {

      return false;

    }

  }

  

  function GetCSS() {

    $result = "";

    foreach($this->css as $key => $values) {

      $result .= $key." {\n";

      foreach($values as $key => $value) {

        $result .= "  $key: $value;\n";

      }

      $result .= "}\n\n";

    }

    return $result;

  }

  

	function EditCSS() {

		$result = "<form action=\"index.php?".$_SERVER['QUERY_STRING']."\" method=\"post\">

		<table cellspacing=\"1\" cellpadding=\"2\">

		<tbody>

		";    

		foreach($this->css as $key => $values) {

			if(count($values)){

				$linha_cor = $eva['geral']->alterna_linha($linha_cor['num']);

				$result.="<tr class=\"{$linha_cor['cor']}\">";

				$result .= "<td align=\"right\">".$key.": </td><td>

				<table>

				<tbody>

				";

				foreach($values as $prop => $prop_value) {

					$result .= "<tr><td align=\"right\">$prop:</td><td>";

					if(eregi("color", $prop)){

						$result .= $eva['geral']->selecionar_cor($prop_value, '_evacss_'.$key.'['.$prop.']');

					}else{

						$result .= "<input type=\"text\" name=\"evacss_".htmlentities($key)."[".htmlentities($prop)."]\" value=\"$prop_value\" />";

					}

					$result .= "</td></tr>";

				}

				$result .="

				</tbody>

				</table>

				</td></tr>";

			}

		}

		$result.="<tr><td></td><td><table><tr>

		<td onMouseOut=\"destacar(this)\" onmouseover=\"destacar(this);\" align=\"center\">

		<input type=\"hidden\" name=\"css_salva\" value=\"1\" />

		<input type=\"image\" src=\"imagens/16x16/actions/filesave.png\"/>

		</td>

		</tr>

		</table>

		</td>

		</tr>

		</tbody>

		</table>

		</form>

		";

		return $result;

	}

	

	function converter_char($palavra){

		$palavra = trim($palavra);

		$simbolo[]=".";

		$simbolo[]="[";

		$simbolo[]="]";

		$simbolo[]="\"";

		$simbolo[]="'";	

		$simbolo_sub[]="csssubsimb1";

		$simbolo_sub[]="csssubsimb2";

		$simbolo_sub[]="csssubsimb3";

		$simbolo_sub[]="csssubsimb4";

		$simbolo_sub[]="csssubsimb5";

		if (eregi("csssubsimb", $palavra)){

			$result = str_replace($simbolo_sub , $simbolo, $palavra);

		}else{

			$result = str_replace($simbolo , $simbolo_sub, $palavra);

		}

		return $result;

	}

  

  // trabalhando com array  

  function GetArrayCSS() {

    $result = "";

    foreach($this->css as $key => $values) {

      foreach($values as $key2 => $value2) {

        $result[trim($key)][trim($key2)]= trim($value2);

      }

    }

    return $result;

  }

  

  // remove os identificadores e retorna o css enviado via post pela classe editCss

	function RetornaCSS($array) {

		$result="";

		foreach($array as $key => $value) {

			if(eregi("evacss_", $key)){

				$key=eregi_replace("cor_", "", $key);

				$key=eregi_replace("evacss_", "", $key);

				$key=eregi_replace("^_", ".", $key);

				foreach($value as $key2 => $value2) {

					$result[$key][$key2] = $value2;

				}

			}

		}

		return $result;

	}

  

	// retorna o css enviado por uma array formatado

	function FormataCSS($array){

		$result="";

		foreach($array as $estilo => $estilo_prop) {

			$estilo=$this->converter_char($estilo);

			$result .= $estilo." {";

			foreach($estilo_prop as $key1 => $value1) {

				$key1=$this->converter_char($key1);

				$result .= "  ".$key1.": ".$value1.";";

			}

			$result .= "}";

		}

		return $result;

	}

  

	function EditArrayCSS($array, $arrayConfig) {

		$result = "<form action=\"index.php?".$_SERVER['QUERY_STRING']."\" method=\"post\" id=\"css_form\">

		<table cellspacing=\"1\" cellpadding=\"2\">

		<tbody>

		"; 

		foreach($array as $key => $values) {

			if(count($values)){	

				// se a classe nao estiver no css do config destaque

				$linha_cor=(!array_key_exists($key ,$arrayConfig))?$eva['geral']->alterna_linha("destaque"):$eva['geral']->alterna_linha();

				$result.="<tr class=\"{$linha_cor}\">";

				$result .= "<td align=\"right\">".$key.": </td><td>

				<table>

				<tbody>

				";

				$key=$this->converter_char($key);

				foreach($values as $prop => $prop_value) {

					$result .= "<tr><td align=\"right\">$prop:</td><td>";   

					$prop=$this->converter_char($prop);

					if(eregi("color", $prop)){

						$result .= $eva['geral']->selecionar_cor($prop_value, '_evacss_'.$key.'['.$prop.']');

					}else{

						$result .= "<input type=\"text\" name=\"evacss_".$key."[".$prop."]\" value=\"$prop_value\" />";

					}

					$result .= "</td></tr>";

				}

				$result .="

				</tbody>

				</table>

				</td></tr>";

			}

		}

		$menu[0]['action']="index.php?".$_SERVER['QUERY_STRING'];

		$menu[0]['confirma']="Tem certeza que deseja editar seu css?";

		$menu[0]['img']="imagens/16x16/actions/filesave.png";

		$menu[0]['url']="";

		$menu[0]['alt'] = $idioma["salvar"];

		$menu[0]['permissao']=true;

		$menu[0]['form_id']="css_form";

		

		$result.="<tr><td colspan=\"2\">

		<input type=\"hidden\" name=\"css_salva\" value=\"1\" />".$eva['modulo_eva_menu']->criar_menu($menu)."

		</td>

		</tr>

		</tbody>

		</table>

		</form>

		";

		return $result;

	}

}

?>

