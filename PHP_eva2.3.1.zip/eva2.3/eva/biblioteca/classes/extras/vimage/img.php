<?
include("vimage.php");
$_GET['size']=isset($_GET['size'])?$_GET['size']:4;
$vImage = new vImage();
$vImage->gerText($_GET['size']);
$vImage->showimage();
?>