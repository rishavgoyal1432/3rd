<?php
// Config file

$font_face = 0;
$font_size = 24;
$rtf_version = 1;
$tab_width = 360;
$paper_size = 5;
$paper_orientation = 1;
?>