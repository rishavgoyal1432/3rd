<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

require_once("extras/rc4.php");

class eva_seguranca extends Crypt_RC4{
	
	/**
	 * Construtor da classe
	 *
	 * @return eva_seguranca
	 */
	function eva_seguranca(){
		global $config;
		global $eva;
		//desencripta as variaveis get
		$this->decodificar_get();
		
		// Definindo o site
		if(isset($_GET['site']) && intval($_GET['site']) > 0){
			$eva['site']["site"] = $_GET['site'];
		}else{
			$eva['site']["site"] = (isset($config['site']) && intval($config['site']) > 0) ? $config['site'] : 1;
			$_GET['site'] = (isset($config['site']) && intval($config['site']) > 0) ? $config['site'] : 1;
		}
	}
	
	/**
	 * Verifica as permissoes do usuario
	 *
	 * @param string $lista_nivel
	 * @param string $modulo
	 * @return bool
	 */
	function verificar_acesso($lista_nivel = "",$modulo = ""){
		global $config;
		global $eva;
		//return true;
		$acesso = 0;
		if(!isset($_SESSION["us_acesso"]["{$eva['site']['site']}"])){
			return false;
		}
		
		if(trim($lista_nivel) == "" && !empty($_SESSION["us_cod"])){
			return true;
		}
		//return true;
		$eva_mo_cod = !empty($eva['modulo_dados']['mo_cod'])? $eva['modulo_dados']['mo_cod'] : 0;
		if(!empty($modulo)){
			$sql = "SELECT 
						mo_cod 
					FROM 
						".$config["bdprefixo"]."_eva_modulo 
					WHERE 
						mo_diretorio = '".$modulo."'";
			$rs = $eva['sql']->executar($sql);
			if($rs && $rs->RecordCount()){
				if($eva_bloco = $rs->FetchRow()){
					$eva_mo_cod = $eva_bloco['MO_COD'];
				}
			}
		}
		if($nivel = 'SU' && eregi("@",$_SESSION["us_acesso"]["{$eva['site']['site']}"])){
			$acesso = 64;
		}else if(intval($eva_mo_cod > 0)){
			$acesso = ord(substr($_SESSION["us_acesso"]["{$eva['site']['site']}"], ($eva_mo_cod - 1), 1));
		}
		$niveis = explode(",",$lista_nivel);
		while(list($cod, $nivel) = each($niveis)){
			if((64 & $acesso) == 64){
				return true;
			}elseif($nivel != "SU" && ((32 & $acesso) == 32)){
				return true;
			}elseif($nivel != "" && (($config['niveis'][$nivel] & $acesso) == $config['niveis'][$nivel])){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Faz uma serie de tratamentos na palavra
	 *
	 * @param string $palavra
	 * @return string
	 */
	function tratar_seguranca($palavra){
		$palavra=stripcslashes($palavra);
		//expressao para retirar a tag q o internet explorer coloca no png
		//De daniel	
		$pattern="/<img.*AlphaImageLoader\(src=(.*\.png),\s*sizingMethod=scale\);.*\/>/Uis";
		preg_match_all($pattern,$palavra,$images);	
		for($i=0;$i<count($images[0]);$i++){
			if(file_exists($images[1][$i])){
				$size=getimagesize($images[1][$i]);
				$palavra = str_replace($images[0][$i], '<img src="'.$images[1][$i].'" width="'.$size[0].'" height="'.$size[1].'" border="0" >', $palavra);
			}
		}
		$palavra = htmlspecialchars($palavra);	
		$palavra = addslashes($palavra);
		$palavra = str_replace("�", "�", $palavra);
		// $palavra = utf8_decode($palavra);
		return $palavra;
	}
	
	/**
	 * Ofuscacao de seguranca das variaveis QUERY_STRING
	 *
	 * @param string $get
	 * @return string
	 */
	function codificar_get($get = ""){
		global $config;
		global $eva;
		$i = "&";
		// descomente a linha de baixo para nao codificar mais a url
		//return $get;
		// Se j� estiver codificado, como no caso do menu que eh codificado no xml
		if(eregi("^eva=", $get)){
			return $get;
		}
		
		// Alterando links em um popup para que continuem abrindo no memso popup
		if((isset($_GET['popup']) and $_GET['popup']=="true") && !strstr($get,"popup=") && !strstr($get,"p=")){
			$get = "popup=true".$i.$get;
		}

		// Coloca o codigo do site na url
		if(!strstr($get,"site=") && !strstr($get,"&s=") && substr($get,0,2) != "s="){
			$get = "site=".$eva['site']['site'].$i.$get;
		}

		$lista = explode($i,$get);
		$get2 = "";
		while(list(,$item) = each($lista)){
			$variavel = explode("=",$item);
			if($variavel[0] == "eva" || $variavel[0] == "") continue;
			switch($variavel[0]){
				case "site":
					$get2 .= "s=";
				break;
				case "comando":
					$get2 .= "c=";
				break;
				case "modulo":
					$get2 .= "m=";
				break;
				case "bloco":
					$get2 .= "b=";
				break;
				case "acao":
					$get2 .= "a=";
				break;
				case "subacao":
					$get2 .= "u=";
				break;
				case "popup":
					$get2 .= "p=";
				break;
				default:
					$get2 .= $variavel[0]."=";
				break;
			}
			$variavel[1] = (empty($variavel[1]))? "" : $variavel[1];
			$get2 .= $variavel[1].$i;
		}
		$get2 = substr($get2,0,-1);
		if($eva['seguranca']->verificar_acesso("SU")){
			return $get2;
		}
		$get = base64_encode($get2);
		return "eva=".$get;
	}
	/**
	 * Busca no codigo html gerado as urls que serao codificadas
	 *
	 * @param string $exibir
	 */
	function codificar_get_eva(&$exibir){
		global $config;
		$pattern="/index.php\??([^\"\'\s\\\]*)/ei";
		$exibir = preg_replace($pattern,"'index.php?'.\$this->codificar_get('\\1')",$exibir);
	}
	
	/**
	 * Decodifica a variavel get
	 *
	 */
	function decodificar_get(){
		$get = '';
		if(isset($_GET["eva"])){
			$get = base64_decode($_GET["eva"]);	
			unset($_GET["eva"]);
			// o tiny mce coloca &amp; nas urls com get 
			$get = str_replace("&amp;", "&", $get);
		}else if(!empty($_SERVER['QUERY_STRING'])){
				$get = $_SERVER['QUERY_STRING'];
		}
		$lista = explode("&",$get);
		
		while(list(,$item) = each($lista)){
			$variavel = explode("=",trim($item));
			if(count($variavel) > 1){
				switch($variavel[0]){
					case "s":
						$_GET['site']=$variavel[1];
					break;
					case "c":
						$_GET['comando']=$variavel[1];
					break;
					case "m":
						$_GET['modulo']=$variavel[1];
					break;
					case "b":
						$_GET['bloco']=$variavel[1];
					break;
					case "a":
						$_GET['acao']=$variavel[1];
					break;
					case "u":
						$_GET['subacao']=$variavel[1];
					break;
					case "p":
						$_GET['popup']=$variavel[1];
					break;
					default:
						$_GET[$variavel[0]]=$variavel[1];
					break;
				}
			}
		}
	}
	
	/**
	 * fun��o de criptografia
	 *
	 * @param string $palavra
	 * @return string
	 */
	function encriptar_palavra($palavra){
		$salt = "ORatoRoeuARoupaDoReiDeRoma";
		return crypt($palavra, $salt);
	}
	
	/**
	 * fun��o para verificar e iniciar o ob_start
	 *
	 */
	function inicia_ob_start($z = true){
		global $config;
		if(!$z || empty($config['ob_gzhandler']) || (isset($_GET['ob_start']) && ($_GET['ob_start'] == "0" || $_GET['ob_start'] == "false"))){
			//echo "OB";
			@ob_start();
			return;
		}
		$phpver = phpversion();
		$useragent = (isset($_SERVER["HTTP_USER_AGENT"]) ) ? $_SERVER["HTTP_USER_AGENT"] : $HTTP_USER_AGENT;
		if ( $phpver >= '4.0.4pl1' && (strstr($useragent,'compatible') || strstr($useragent,'Gecko'))){
			if (extension_loaded('zlib')){
				//echo "GZ";
				@ob_start('ob_gzhandler');
			}
		}else if ($phpver > '4.0'){
			if (strstr($HTTP_SERVER_VARS['HTTP_ACCEPT_ENCODING'], 'gzip')){
				if (extension_loaded('zlib')){
					//echo "zlib";
					@ob_start();
					ob_implicit_flush(0);		
					header('Content-Encoding: gzip');
				}
			}
		}
	}
	
	/**
	 * Verifica ataques (floods)
	 *
	 * @param string $diretorio
	 */
	function verificar_ataque($diretorio = "arquivos/logs"){
		global $eva;
		// comentei a linha abaixo pq deu pau no linux, deve dar pau agora pra subsite
		//$diretorio = $eva['caminho'].$diretorio;
		if(!$eva['arquivo']->verificar_diretorio($diretorio)) return;
		include_once("extras/class.floodblocker.php");		
		@chdir($eva['caminho']);
		$flb = new FloodBlocker($diretorio);
		// Regras		
		$flb->rules = array (
		10=>30    // regra 2 - maximo de 20 requisicoes em 10 segs
		//, 60=>100  // regra 4 - maximo de 100 requisicoes em 60 segs
		);
		
		// Verificando ataque
		if(!$flb->CheckFlood()) exit;
		@chdir($eva['caminho_eva']);
	}
	
	/**
	 * Retira tags e o conteudo dos textos
	 *
	 * @param array $tag array com as tags a serem removidas
	 * @param string $texto
	 */
	function retirar_tag($tag, $texto){
		for($i=0;$i<count($tag);$i++)
			$texto = preg_replace("'<\s*{$tag[$i]}[^>]*>.*</\s*{$tag[$i]}\s*>'siU",' ',$texto);
		return $texto;
	}
	
	/**
	 * Decrypt the database password stored in the config file
	 *
	 */
	function senha_banco_decrypt(){
		global $config, $eva;
		if(empty($config['bdusuario'])) return;
		if(empty($config['eva_versao'])){	
			$this->setKey($config['bdusuario']);
			$this->decrypt($config['bdsenha']);		
			$this->atualizar_config($config);				
		}else if((empty($config['eva_versao']) || $config['eva_versao'] == '2.0' )){	
			$this->setKey($config['bdusuario']);
			$config['bdsenha'] = base64_decode($config['bdsenha']);
			$this->decrypt($config['bdsenha']);	
			$this->atualizar_config($config);				
		}
		/*
		nao sera mais utilizada crypt para senha do banco, so da dor de cabe�a
		// se nao foi setada a versao do eva crie a senha com base64
		if(empty($config['eva_versao']) && $this->verificar_acesso('SU')){	
			$this->setKey($config['bdusuario']);
			$this->decrypt($config['bdsenha']);		
			$this->atualizar_config($config);				
		}else{
			//var_dump($config['bdsenha']);echo "<hr>";
			$this->setKey($config['bdusuario']);
			$config['bdsenha'] = stripslashes(empty($config['eva_versao']))?$config['bdsenha']:base64_decode($config['bdsenha']);
			//var_dump($config['bdsenha']);echo "<hr>";
			$this->decrypt($config['bdsenha']);
			//var_dump($config['bdsenha']);echo "<hr>";
		}
		*/
	}
	
	/**
	 * Update the config.php file
	 *
	 * @param array $config the config values
	 */
	function atualizar_config($config){	
		global $eva;
		$_SESSION['bdusuario'] = $config['bdusuario'];
		$_SESSION['bdsenha'] = $config['bdsenha'];	
		$_POST['site'] = $config['site'];		
		$_SESSION['bdtipo'] = $config['bdtipo'];
		$_SESSION['bdnome'] = $config['bdnome'];
		$_SESSION['bdhost'] = $config['bdhost'];
		$_SESSION['bdprefixo'] = $config['bdprefixo'];
		$_SESSION['bdcache'] = $config['bdcache'];
		$_SESSION['bdconversor'] = $config['bdconversor'];
		$_POST['bdlog'] = $config['bdlog'];
		$_POST['cache_tempo'] = $config['cache_tempo'];
		$_POST['cache_tamanho'] = $config['cache_tamanho'];
		$_POST['email'] = $config['email'];
		$_POST['site'] = $config['site'];
		$_POST['si_nome'] = $config['titulo'];
		$_POST['url'] = $config['url'];
		$_POST['idioma_padrao'] = $config['idioma_padrao'];
		$_POST['si_modulo_inicial'] = $config['redirecionar_modulo'];
		$_POST['modelo_alerta'] = $config['modelo_alerta'];
		$_POST['formato_data'] = $config['formato_data'];
		$_POST['galeria'] = $config['galeria'];
		$_POST['galeria_path'] = $config['galeria_path'];
		$_POST['galeria_miniatura'] = $config['galeria_miniatura'];
		$_POST['tempo_limite'] = $config['tempo_limite'];
		
		if(!empty($config['login'])){
			
			$_SESSION['login_tipo']=$config['login'][0]['tipo'];
			$_SESSION['login_servidor']=$config['login'][0]['servidor'];
			$_SESSION['login_porta']=$config['login'][0]['porta'];
			$_SESSION['login_dominio']=$config['login'][0]['dominio'];
			$_SESSION['login_grupo']=$config['login'][0]['grupo'];
			$_SESSION['login_login']=$config['login'][0]['login'];
			$_SESSION['login_basedn']=$config['login'][0]['base_dn'];
			$_SESSION['login_binddn']=$config['login'][0]['bind_dn'];
			$_SESSION['login_bindpw']=$config['login'][0]['senha_bind'];
			$_SESSION['login_filtro']=$config['login'][0]['filtro'];
			$_SESSION['login_pass_att']=$config['login'][0]['atributo_senha'];
			$_SESSION['login_url']=$config['login'][0]['url'];
			
		}		
		
		$eva['incluir']->incluir("arquivo");
		require("modulos/eva_config/modelo_config.php");
		$eva['arquivo']->gravar($eva['caminho'].'/arquivos/config.php', $conteudo);
	}
	
	/**
	 * Verifica as permissoes do usuario
	 *
	 * @param string $gr_nome Nome do Grupo
	 * @param int $us_cod Codigo do Usuario
	 * @return bool
	 */
	function verificar_grupo($gr_nome,$us_cod = ""){
		global $eva;
		if(empty($us_cod)){
			if(empty($_SESSION['us_cod'])){ // the user is not logged
				return false;
			}else{
				$us_cod = $_SESSION['us_cod'];
			}
		}
		//cache for this function
		if(isset($_SESSION['verificar_grupo'][$us_cod][$gr_nome]))
			return $_SESSION['verificar_grupo'][$us_cod][$gr_nome];
			
		$eva['incluir']->incluir_modulo("eva_usuario");
		$gr_cod = $eva['modulo_eva_usuario']->gr_cod($gr_nome);		
		$rs = $eva['modulo_eva_usuario']->select_usuarios($gr_cod, $us_cod);
		if($rs->RecordCount()){
			$_SESSION['verificar_grupo'][$us_cod][$gr_nome] = true;
			return true;
		}else{
			$_SESSION['verificar_grupo'][$us_cod][$gr_nome] = false;
			return false;
		}		
	}
}
?>