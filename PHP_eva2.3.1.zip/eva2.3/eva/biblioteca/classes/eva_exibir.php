<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_exibir{
	
	
	/**
     * Array com os itens que serao exibidos
     *
     * @var Array
     */
    var $array_item = array();
		
	/*
	KOIVI PNG Alpha IMG Tag Replacer for PHP (C) 2004-2005 Justin Koivisto
	Version 2.0.7
	Last Modified: 4/21/2005
	
		This library is free software; you can redistribute it and/or modify it
		under the terms of the GNU Lesser General Public License as published by
		the Free Software Foundation; either version 2.1 of the License, or (at
		your option) any later version.
	
		This library is distributed in the hope that it will be useful, but
		WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
		or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
		License for more details.
	
		You should have received a copy of the GNU Lesser General Public License
		along with this library; if not, write to the Free Software Foundation,
		Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
	
		Full license agreement notice can be found in the LICENSE file contained
		within this distribution package.
	
		Justin Koivisto
		justin.koivisto@gmail.com
		http://www.koivi.com
	*/
	
	/*
	*   Modifies IMG and INPUT tags for MSIE5+ browsers to ensure that PNG-24
	*   transparencies are displayed correctly.  Replaces original SRC attribute
	*   with a transparent PNG file (spacer.png) that is located in the same
	*   directory as the orignal image, and adds the STYLE attribute needed to for
	*   the browser. (Matching is case-insensitive. However, the width attribute
	*   should come before height.
	*
	*   Also replaces code for PNG images specified as backgrounds via:
	*   background-image: url(image.png); or background-image: url('image.png');
	*   When using PNG images in the background, there is no need to use a spacer.png
	*   image. (Only supports inline CSS at this point.)
	*
	*   @param  $x  String containing the content to search and replace in.
	*   @param  $img_path   The path to the directory with the spacer image relative to
	*                       the DOCUMENT_ROOT. If none os supplied, the spacer.png image
	*                       should be in the same directory as PNG-24 image.
	*   @param  $sizeMeth   String containing the sizingMethod to be used in the
	*                       Microsoft.AlphaImageLoader call. Possible values are:
	*                       crop - Clips the image to fit the dimensions of the object.
	*                       image - Enlarges or reduces the border of the object to fit
	*                               the dimensions of the image.
	*                       scale - Default. Stretches or shrinks the image to fill the borders
	*                               of the object.
	*   @result Returns the modified string.
	*/
	function replacePngTags($x,$img_path='',$sizeMeth='scale'){
		/*EVA*/
		global $eva, $config;
		$lista = array();
		
		$arr2=array();
		// make sure that we are only replacing for the Windows versions of Internet
		// Explorer 5+
		//$msie='/msie\s(5\.[5-9]|[6-9]\.[0-9]*).*(win)/i';
		$msie='/msie\s(5\.[5-9]|6\.[0-9]*).*(win)/i'; // se for IE 7 ele nao � detectado pois nao � mais necessario o png fix
		if( !isset($_SERVER['HTTP_USER_AGENT']) ||
			!preg_match($msie,$_SERVER['HTTP_USER_AGENT']) ||
			preg_match('/opera/i',$_SERVER['HTTP_USER_AGENT']))
			return $x;
	
		// find all the IMG tags with ".png" in them
		/*EVA*/
		//$pattern='/<(input|img)[^>]*src=([\\"\\\']?)([^>]*\.png)\2[^>]*>/i';
		$pattern='/<(input|img)[^>]*src=(\\\'|\"|\\\")([^>]*\.png)\2[^>]*>/Ui'; 
		preg_match_all($pattern,$x,$images);
		for($num_images=0;$num_images<count($images[0]);$num_images++){
			// for each found image pattern
			$original=$images[0][$num_images];
			$quote=$images[2][$num_images];
			$atts=''; $width=0; $height=0; $modified=$original;
			// We do this so that we can put our spacer.png image in the same
			// directory as the image - if a path wasn't passed to the function
			if(empty($img_path)){
				$tmp=split('[\\/]',$images[3][$num_images]);
				$this_img=array_pop($tmp);
				$img_path=join('/',$tmp);
				if(empty($img_path)){
					// this was a relative URI, image should be in this directory
					$tmp=split('[\\/]',$_SERVER['SCRIPT_NAME']);
					array_pop($tmp);    // trash the script name, we only want the directory name
					$img_path=join('/',$tmp).'/';
				}else{
					$img_path.='/';
				}
			}else if(substr($img_path,-1)!='/'){
				// in case the supplied path didn't end with a /
				$img_path.='/';
			}
	
			// If the size is defined by styles, find them
			preg_match_all(
				'/style=([\\"\\\']).*(\s?width:\s?([0-9]+(px|%));).*'.
				'(\s?height:\s?([0-9]+(px|%));).*\\1/Ui',
				$images[0][$num_images],$arr2);
			if(is_array($arr2) && count($arr2[0])){
				// size was defined by styles, get values
				$width=$arr2[3][0];
				$height=$arr2[6][0];
	
				// remove the width and height from the style
				$stripper=str_replace(' ','\s','/('.$arr2[2][0].'|'.$arr2[5][0].')/');
				// Also remove any empty style tags
				$modified=preg_replace(
					'`style='.$arr2[1][0].$arr2[1][0].'`i',
					'',
					preg_replace($stripper,'',$modified));
			}else{
				// size was not defined by styles, get values from attributes
				preg_match_all('/width=([\\"\\\']?)([0-9%]+)\\1/i',$images[0][$num_images],$arr2);
				if(is_array($arr2) && count($arr2[0])){
					$width=$arr2[2][0];
					if(is_numeric($width))
						$width.='px';
		
					// remove width from the tag
					$modified=str_replace($arr2[0][0],'',$modified);
				}
				preg_match_all('/height=([\\"\\\']?)([0-9%]+)\\1/i',$images[0][$num_images],$arr2);
				if(is_array($arr2) && count($arr2[0])){
					$height=$arr2[2][0];
					if(is_numeric($height))
						$height.='px';
		
					// remove height from the tag
					$modified=str_replace($arr2[0][0],'',$modified);
				}
			}
			
			if($width==0 || $height==0){
				/*EVA*/
				// width and height not defined in HTML attributes or css style
				$_SERVER['DOCUMENT_ROOT'] = (isset($_SERVER['DOCUMENT_ROOT']))? $_SERVER['DOCUMENT_ROOT'] : "";
				//echo $images[3][$num_images]."<hr>";
				
				if(@file_exists($_SERVER['DOCUMENT_ROOT']."/".$img_path.$images[3][$num_images])){
					$size=getimagesize($_SERVER['DOCUMENT_ROOT'].$img_path.$images[3][$num_images]);					
				}elseif(@file_exists($img_path.$images[3][$num_images])){
					$size=getimagesize($img_path.$images[3][$num_images]);
				}elseif(@file_exists($images[3][$num_images])){
					$size = @getimagesize($images[3][$num_images]);
				}elseif(@file_exists($eva['caminho'].$images[3][$num_images])){
					$size = @getimagesize($eva['caminho'].$images[3][$num_images]);
				}elseif(@file_exists($eva['caminho_eva'].$images[3][$num_images])){
					$size = @getimagesize($eva['caminho_eva'].$images[3][$num_images]);
				}elseif(@file_exists($eva['caminho'].$eva['caminho_eva'].str_replace($config['url'], "", $images[3][$num_images]))){
					$size = @getimagesize($eva['caminho'].$eva['caminho_eva'].str_replace($config['url'], "", $images[3][$num_images]));
				}elseif(@file_exists($eva['caminho'].str_replace($config['url'], "", $images[3][$num_images]))){
					$size = @getimagesize($eva['caminho'].str_replace($config['url'], "", $images[3][$num_images]));
				}else{					
					$size[0]='16';
					$size[1]='16';
				}
				$width=$size[0].'px';
				$height=$size[1].'px';
			}
			
			// end quote is already supplied by originial src attribute
			$replace_src_with=$quote.$img_path.'spacer.png'.$quote.' style='.$quote.'width: '.$width.
				'; height: '.$height.'; filter: progid:DXImageTransform.'.
				'Microsoft.AlphaImageLoader(src='.((eregi("^imagens/", $images[3][$num_images]))?$eva['url_eva']:"").$images[3][$num_images].', sizingMethod='.
				$sizeMeth.');'.$quote;
	
			// now create the new tag from the old
			$new_tag=str_replace($quote.$images[3][$num_images].$quote,$replace_src_with,
				str_replace('  ',' ',$modified));
			// now place the new tag into the content
			/*EVA*/
			if(!in_array($original,$lista)){
				$x=str_replace($original,$new_tag,$x);
				$lista[] = $original;
			}
		}
	
		// find all the png images in backgrounds
		preg_match_all('/background-image\s*:\s*url\(([\\"\\\']?)([^\)]+\.png)\1\);/Uis',$x,$background);
		for($i=0;$i<count($background[0]);$i++){
			// simply replace:
			//  "background-image: url('image.png');"
			// with:
			//  "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(
			//      enabled=true, sizingMethod=scale src='image.png');"
			// I don't think that the background-repeat styles will work with this...
			
			/*EVA*/
			if(!in_array($background[2][$i],$lista)){
				$x=str_replace($background[0][$i],'filter:progid:DXImageTransform.'.
						'Microsoft.AlphaImageLoader(enabled=true, sizingMethod='.$sizeMeth.
						' src=\''.$background[2][$i].'\');',$x);					
				$lista[] = $background[2][$i];
			}
		}
		
		return $x;
	}
	
	/**
	 * Corrige a url para subsites
	 *
	 * @param string $x
	 * @param string $complemento
	 * @return string
	 */
	function corrigir_url_img($url, $complemento=NULL){
		global $eva;
		$lista = array();
		$complemento = isset($complemento)? $complemento : $eva['url_eva'];		
		//$complemento = (!eregi("/$", $complemento))?$complemento."/":$complemento;
		//var_dump($complemento);//var_dump($eva['config']);
		// find all the IMG tags
		$pattern = '/<(input|img)[^>]*src=(\\\'|\"|\\\")([^>]*)\2[^>]*>/Ui';
		preg_match_all($pattern,$url,$images);
		//var_dump($images);
		for($num_images=0;$num_images<count($images[0]);$num_images++){
			// now place the new tag into the content	
			//echo htmlentities($eva['url_eva'].$images[3][$num_images])."<br>";	
			if(!in_array($images[3][$num_images],$lista) && !eregi("https:|http:|index.php|\/arquivos|insertfile\/img\/ext",$images[3][$num_images]) && !eregi("^arquivos",$images[3][$num_images])){
				//if(eregi("O job est� publicado", $url)){echo $images[2][$num_images].$complemento.$images[3][$num_images]."<hr>\n\n";}
				$url=str_replace($images[2][$num_images].$images[3][$num_images],$images[2][$num_images].$complemento.$images[3][$num_images],$url);
				$lista[] = $images[2][$num_images].$images[3][$num_images];
			}
		}
		preg_match_all('/background-image\s*:\s*url\((\\\'|\"|\\\")([^\)]+)\1\);/Uis',$url,$background);
		for($i=0;$i<count($background[0]);$i++){			
			if(!in_array($background[2][$i],$lista) && !eregi("https:|http:|index.php|\/arquivos",$background[2][$i])){
				$url=str_replace($background[1][$i].$background[2][$i],$background[1][$i].$complemento.$background[2][$i],$url);
				$lista[] = $background[1][$i].$background[2][$i];
			}
		}	
		$s[]="<param name=\"movie\" value=\"imagens";
		$r[]="<param name=\"movie\" value=\"{$complemento}imagens";	
		$s[]="Microsoft.AlphaImageLoader(src=imagens/16x16/";
		$r[]="Microsoft.AlphaImageLoader(src={$complemento}imagens/16x16/";
		$s[]=$complemento.$complemento;
		$r[]=$complemento;
		$s[]="/eva/eva/";
		$r[]="/eva/";
		
		$url=str_replace($s, $r, $url);
		
		return $url;
	}
		
	/**
	* Gera itens no padrao
	* @param array Com varios atributos
	* @param int Numero de Colunas
	* @return string com os itens formatados
	*/	
	function itens($num_colunas=1, $arquivo_modelo="", $exibir_mais = "", $secao = array()){
		global $eva;
		$tabela = "";
		$num_colunas = (intval($num_colunas)<1)? 1 : $num_colunas;
		$num_colunas = (count($this->array_item) < $num_colunas)? count($this->array_item) : $num_colunas;
		if(count($this->array_item) > 0){
			$tabela .= "<table border=\"0\" cellpadding=\"1\" cellspacing=\"2\" width=\"100%\">";
			// for loop para linhas
			for($i=0;$i<count($this->array_item);){
				$tabela .= "<tr>";
				// for loop para colunas
				for($j=0;$j<$num_colunas;$j++){
					$tabela .= "<td valign=\"top\" width=\"".(intval(100/$num_colunas))."%\">";
					if(isset($this->array_item[$i])){
						if(trim($arquivo_modelo)!="" and $modelo = @file_get_contents($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$arquivo_modelo)){
							$modelo = $eva['carregar']->tratar_src($modelo);
						}else if(eregi("{bloco}", $arquivo_modelo) || eregi("{titulo}", $arquivo_modelo)){
							$modelo = $arquivo_modelo;
						}else{
							$modelo = "{titulo}<br />{bloco}";
						}
						$modelo = str_replace("{fechar}", "",$modelo);
						$modelo = str_replace("{titulo}",$this->array_item[$i]['titulo'],$modelo);
						$modelo = str_replace("{bloco}",$this->array_item[$i]['bloco'],$modelo);
						$tabela .= $modelo;
					}
					$tabela .= "</td>";
					// passa para o proximo item do array
					$i++;
				}
				$tabela .= "</tr>";
			}
			$tabela .= "</table>";
			if(!empty($exibir_mais)){
				$tabela .= "<a href=\"index.php?s=1&m=eva_conteudo&se_cod=".(implode(";",$secao))."\">{$exibir_mais}</a>";
			}
		}
		$this->array_item=array();
		return $tabela;
	} //itens
	
	
	/**
	* adiciona item titulo e descricao no atributo da classe
	* @param String Titulo
	* @param String Descricao
	*/	
	function adicionar_item($titulo="", $desc=""){
		if(trim($titulo) != ""){
			$contador=count($this->array_item);
			$this->array_item[$contador]['titulo']=$titulo;
			$this->array_item[$contador]['bloco']=$desc;
		}
	} //adicionar_item
} //eva_geral
?>