<?php
include_once("biblioteca/classes/extras/imageresizeclass/ImageResizeFactory.php");
class eva_img extends ImageResizeFactory{
	
	
	/**
	 * Retorna um Thumbs ou o icone do arquivo
	 *
	 * @param string $imageName
	 * @param string $resizedImageName
	 * @param int $newWidth
	 * @param int $newHeight
	 * @param boolean $overwrite
	 * @return string
	 */
	function resize($imageName, $resizedImageName, $newWidth, $newHeight, $overwrite = true){
		global $eva;
		ini_set("memory_limit","64M");// some times the image is big and exaust the mem limit
		if(empty($resizedImageName)) $resizedImageName = eregi_replace("\.(...|....)$", "_thumbs.\\1", $imageName );
		//echo $resizedImageName;
		if($overwrite || !$eva['arquivo']->existe($resizedImageName)){
			if($instance = $this->getInstanceOf($imageName, $resizedImageName, $newWidth, $newHeight)){
				$instance->getResizedImage();
				return $resizedImageName;
			}else{
				return $eva['arquivo']->icone($resizedImageName, true);
			}
		}else{
			return $resizedImageName;
		}
	}
	
	/**
	 * Redimenciona uma Imagem
	 *
	 * @param string $imageName
	 * @param string $resizedImageName
	 * @param int $newWidth
	 * @param int $newHeight
	 * @param boolean $overwrite
	 * @param boolean $img_url
	 * @return string
	 */
	function resize_img($imageName, $resizedImageName, $newWidth, $newHeight, $overwrite = true, $img_url = false){
		$img = $this->resize($imageName, $resizedImageName, $newWidth, $newHeight, $overwrite);
		if(!$img_url)
			return '<img src="'.$img.'" border="0" hspace="3" vspace="3"/>';
		else
			return $img;
	}
	
	
	/**
	* mixed image_info( file $file [, string $out] )
	*
	* Returns information about $file.
	*
	* If the second argument is supplied, a string representing that information will be returned.
	*
	* Valid values for the second argument are IMAGE_WIDTH, 'width', IMAGE_HEIGHT, 'height', IMAGE_TYPE, 'type',
	* IMAGE_ATTR, 'attr', IMAGE_BITS, 'bits', IMAGE_CHANNELS, 'channels', IMAGE_MIME, and 'mime'.
	*
	* If only the first argument is supplied an array containing all the information is returned,
	* which will look like the following:
	*
	*    [width] => int (width),
	*    [height] => int (height),
	*    [type] => string (type),
	*    [attr] => string (attributes formatted for IMG tags),
	*    [bits] => int (bits),
	*    [channels] => int (channels),
	*    [mime] => string (mime-type)
	*
	* Returns false if $file is not a file, no arguments are supplied, $file is not an image, or otherwise fails.
	*
	**/
	function image_info($file = null, $out = null) {
		
		/*EVA*/
		global $eva;
		if(!eregi("^{$eva['caminho']}", $file))
			@chdir($eva['caminho']);
		
		// If $file is not supplied or is not a file, warn the user and return false.
		if (is_null($file) || !is_file($file)) {
			echo '<p><b>Warning:</b> image_info() => first argument must be a file.</p>';
			return false;
		}
		
		// Defines the keys we want instead of 0, 1, 2, 3, 'bits', 'channels', and 'mime'.
		$redefine_keys = array(
			'width',
			'height',
			'type',
			'attr',
			'bits',
			'channels',
			'mime',
		);
		
		// If $out is supplied, but is not a valid key, nullify it.
		if (!is_null($out) && !in_array($out, $redefine_keys)) $out = null;
		
		// Assign usefull values for the third index.
		$types = array(
			1 => 'GIF',
			2 => 'JPG',
			3 => 'PNG',
			4 => 'SWF',
			5 => 'PSD',
			6 => 'BMP',
			7 => 'TIFF(intel byte order)',
			8 => 'TIFF(motorola byte order)',
			9 => 'JPC',
			10 => 'JP2',
			11 => 'JPX',
			12 => 'JB2',
			13 => 'SWC',
			14 => 'IFF',
			15 => 'WBMP',
			16 => 'XBM'
		);
		$temp = array();
		$data = array();
		
		// Get the image info using getimagesize().
		// If $temp fails to populate, warn the user and return false.
		if (!$temp = getimagesize($file)) {
			echo '<p><b>Warning:</b> image_info() => first argument must be an image.</p>';
			return false;
		}
		
		// Get the values returned by getimagesize()
		$temp = array_values($temp);
		
		// Make an array using values from $redefine_keys as keys and values from $temp as values.
		foreach ($temp AS $k => $v) {
			$data[$redefine_keys[$k]] = $v;
		}
		
		// Make 'type' usefull.
		$data['type'] = $types[$data['type']];
		
		// Return the desired information.
		return !is_null($out) ? $data[$out] : $data;   
	}
	
	/**
	 * Check if the file is a image
	 *
	 * @param string $img
	 * @return boolean
	 */
	function is_image($img){
		return eregi('(\.GIF|\.JPG|\.PNG|\.SWF|\.PSD|\.BMP|\.TIFF|\.JPC|\.JP2|\.JPX|\.JB2|\.SWC|\.IFF|\.WBMP|\.XBM)$', $img);
	}
	
	/**
	 * Check if the file is a HTML
	 *
	 * @param string $img
	 * @return boolean
	 */
	function is_html($html){
		return eregi('(\.HTM|\.HTML)$', $html);
	}

}
?>