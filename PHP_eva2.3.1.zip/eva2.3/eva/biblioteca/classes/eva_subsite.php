<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
* Gerenciamento de multiplos sites
*/
class eva_subsite{
	/**
	 * verifica se as pastas que devem ser copiadas estao compativeis
	 *
	 * @return eva_subsite
	 */
	function eva_subsite() {
		global $config;
		global $eva;
		@chdir($eva['caminho']);
		//echo $eva['caminho_eva'].'biblioteca'."<hr><hr>".$eva['caminho'].'biblioteca'."<hr><hr>";
		//echo filemtime($eva['caminho_eva'].'biblioteca')."<hr><hr>".filemtime($eva['caminho'].'biblioteca')."<hr><hr>";
		if($eva['caminho_eva'] != 'eva/' && !file_exists($eva['caminho'].'biblioteca')){
			$dir[] = "biblioteca/javascripts/tiny_mce";
			$dir[] = "biblioteca/javascripts/extras";
			ini_set("max_execution_time", "120");
			while(list($c,$d) = each($dir)){				
				$eva['arquivo']->verificar_diretorio($eva['caminho'].$d);
				@$this->apagar_dir($eva['caminho'].$d);
			}
			reset($dir);//var_dump($dir);echo "<hr>";
			while(list($c,$d) = each($dir)){
				//echo $c." - ".$d."<hr>";
				$eva['arquivo']->verificar_diretorio($d);
				$this->copiar_dir($eva['caminho_eva'].$d, $d);
			}
		}
		@chdir($eva['caminho_eva']);
	}

	/**
	 * Copiar os arquivos recursivamente de um dir para o outro
	 *
	 * @param string $dir
	 * @param string $dir_novo
	 */
	function copiar_dir($dir, $dir_novo){ 
		global $eva;
		@chdir($eva['caminho']);
	   //echo "<hr>".$dir_novo."<hr>".$dir."<hr>"; 	   
	   //var_dump(file_exists($dir_novo));var_dump(file_exists($dir));
	   if(file_exists($dir) && file_exists($dir_novo)){
		   $copiar_dir=opendir($dir);
		   while (false !== ($file = readdir($copiar_dir))) {
			   //echo "<hr>".$dir_novo."/".$file."<hr>".$dir."/".$file;
			   if($file != "." && $file != ".." && !ereg("_notes", $d) && !ereg("CVS", $d)){
				   if(file_exists($dir_novo."/".$file) && @filetype($dir_novo."/".$file."/") != "dir"){
					   unlink($dir_novo."/".$file);
				   }
				   //echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".getcwd()."<hr>";
				   if(@filetype($dir."/".$file."/") == "dir"){ //echo $dir."/".$file."/"." - Diretorio<br>";
					   if(!file_exists($dir_novo."/".$file."/")){
						   mkdir($dir_novo."/".$file."/");
						   $this->copiar_dir($dir."/".$file."/", $dir_novo."/".$file."/");
					   }//else{echo "<b> [Ja existe] </b><br>";}
				   }else{//echo $dir."/".$file."/"." - Arquivo";
					   copy($dir."/".$file."/", $dir_novo."/".$file);
				   }
				   //echo "<hr>".@filetype($dir_novo."/".$file."/")."<hr>";
			   }
		   }
	   }
	   //@chdir($eva['caminho_eva']);
	}
	
	/**
	 * apaga o diretorio indicado
	 *
	 * @param string $dir
	 */
	function apagar_dir($dir) {
	   if($objs = glob($dir."/*")){
		   foreach($objs as $obj) {
			   is_dir($obj)? $this->apagar_dir($obj) : unlink($obj);
		   }
	   }
	   rmdir($dir);
	}
}
?>