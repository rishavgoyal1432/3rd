<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

class eva_idioma{

	/**
	 * Cria as vari�veis de se��o que definem o idioma a ser utilizado
	 *
	 * @param string $codigo
	 * @return array
	 */
	function selecionar($codigo=""){
		$idioma_padrao['moeda'] = '$R';
		$idioma_padrao['seperador_decimal'] = ',';
		$idioma_padrao['seperador_milhar'] = '.';
		$idioma_padrao['formato_data'] = 'd-m-Y';
		$idioma_padrao['formato_hora'] = 'G:i';
		$idioma_padrao['inicio_semana'] = 1;
		$idioma_padrao['fuso_horario'] = 1;
		$idioma_padrao['horario_verao'] = 1;
		
		$idiomas['nl'] = $idioma_padrao;
		$idiomas['nl']['descricao'] = 'Nederlands';
		$idiomas['nl']['arquivo_idioma'] = 'nl';
		$idiomas['nl-be'] = $idioma_padrao;
		$idiomas['nl-be']['arquivo_idioma'] = 'nl';
		
		$idiomas['da'] = $idioma_padrao;
		$idiomas['da']['arquivo_idioma'] = 'da';
		$idiomas['da']['descricao'] = 'Dansk';
		$idiomas['da']['moeda'] = 'DKK';
		$idiomas['da-dk'] = $idioma_padrao;
		$idiomas['da-dk']['arquivo_idioma'] = 'da';
		$idiomas['da-dk']['descricao'] = 'Dansk/Danmark';
		$idiomas['da-dk']['moeda'] = 'DKK';
		
		$idiomas['fr'] = $idioma_padrao;
		$idiomas['fr']['arquivo_idioma'] = 'fr';
		$idiomas['fr']['descricao'] = 'Fran&ccedil;ais';
		$idiomas['fr-be'] = $idioma_padrao;
		$idiomas['fr-be']['arquivo_idioma'] = 'fr';
		$idiomas['fr-ca'] = $idioma_padrao;
		$idiomas['fr-ca']['arquivo_idioma'] = 'fr';
		$idiomas['fr-lu'] = $idioma_padrao;
		$idiomas['fr-lu']['arquivo_idioma'] = 'fr';
		$idiomas['fr-mc'] = $idioma_padrao;
		$idiomas['fr-mc']['arquivo_idioma'] = 'fr';
		$idiomas['fr-ch'] = $idioma_padrao;
		$idiomas['fr-ch']['arquivo_idioma'] = 'fr';
		
		$idiomas['de'] = $idioma_padrao;
		$idiomas['de']['arquivo_idioma'] = 'de';
		$idiomas['de']['descricao'] = 'Deutsch';
		$idiomas['de-at'] = $idioma_padrao;
		$idiomas['de-at']['arquivo_idioma'] = 'de';
		$idiomas['de-at']['descricao'] = 'Deutsch/Austria';
		$idiomas['de-li'] = $idioma_padrao;
		$idiomas['de-li']['arquivo_idioma'] = 'de';
		$idiomas['de-lu'] = $idioma_padrao;
		$idiomas['de-lu']['arquivo_idioma'] = 'de';
		$idiomas['de-ch'] = $idioma_padrao;
		$idiomas['de-ch']['arquivo_idioma'] = 'de';
		$idiomas['de-ch']['descricao'] = 'Deutsch/Switzerland';
		
		$idiomas['en'] = $idioma_padrao;
		$idiomas['en']['arquivo_idioma'] = 'en';
		$idiomas['en']['descricao'] = 'English';
		$idiomas['en']['decimal_separator'] = '.';
		$idiomas['en']['seperador_milhar'] = ',';
		$idiomas['en']['inicio_semana'] = 1;
		$idiomas['en']['fuso_horario'] = 0;
		$idiomas['en']['horario_verao'] = 0;
		
		$idiomas['en-us'] = $idiomas['en'];
		$idiomas['en-us']['descricao'] = 'English/United States';
		$idiomas['en-us']['moeda'] = '$';
		$idiomas['en-us']['formato_data'] = 'm-d-Y';
		$idiomas['en-us']['formato_hora'] = 'g:i a';
		$idiomas['en-us']['fuso_horario'] = 4;
		$idiomas['en-us']['horario_verao'] = 1;
		
		$idiomas['en-gb'] = $idiomas['en'];
		$idiomas['en-gb']['descricao'] = 'English/Great Britain';
		$idiomas['en-gb']['moeda'] = 'GBP';
		$idiomas['en-gb']['fuso_horario'] = 0;
		
		$idiomas['en-au'] = $idiomas['en'];
		$idiomas['en-au']['descricao'] = 'English/Australia';
		$idiomas['en-au']['moeda'] = '$';
		$idiomas['en-au']['fuso_horario'] = 10;
		$idiomas['en-au']['horario_verao'] = 1;
		
		$idiomas['en-ie'] = $idiomas['en'];
		$idiomas['en-ie']['descricao'] = null;
		
		$idiomas['en-jm'] = $idiomas['en'];
		$idiomas['en-jm']['descricao'] = null;
		
		$idiomas['en-nz'] = $idiomas['en'];
		$idiomas['en-nz']['descricao'] = 'English/New Zealand';
		$idiomas['en-nz']['moeda'] = '$';
		$idiomas['en-nz']['inicio_semana'] = 1;
		$idiomas['en-nz']['fuso_horario'] = 12;
		$idiomas['en-nz']['horario_verao'] = 1;
		
		$idiomas['en-ph'] = $idiomas['en'];
		$idiomas['en-ph']['descricao'] = null;
		
		$idiomas['en-za'] = $idiomas['en'];
		$idiomas['en-za']['descricao'] = null;
		
		$idiomas['en-zw'] = $idiomas['en'];
		$idiomas['en-zw']['descricao'] = null;
		
		$idiomas['it'] = $idioma_padrao;
		$idiomas['it']['descricao'] = 'Italiano';
		$idiomas['it']['arquivo_idioma'] = 'it';
		
		$idiomas['sv'] = $idioma_padrao;
		$idiomas['sv']['descricao'] = 'Svenska';
		$idiomas['sv']['arquivo_idioma'] = 'sv';
		$idiomas['sv-fi'] = $idioma_padrao;
		$idiomas['sv-fi']['arquivo_idioma'] = 'sv';
		
		$idiomas['zh_TW_big5'] = $idioma_padrao;
		$idiomas['zh_TW_big5']['descricao'] = 'Chinese';
		$idiomas['zh_TW_big5']['arquivo_idioma'] = 'zhTW_big5';
		
		$idiomas['pt'] = $idioma_padrao;
		$idiomas['pt']['descricao'] = 'Portugues';
		$idiomas['pt']['arquivo_idioma'] = 'pt';
		$idiomas['pt-pt'] = $idioma_padrao;
		$idiomas['pt-pt']['arquivo_idioma'] = 'pt';
		$idiomas['pt-br'] = $idioma_padrao;
		$idiomas['pt-br']['descricao'] = 'Portugues/Brazil';
		$idiomas['pt-br']['arquivo_idioma'] = 'br';
		
		$idiomas['es'] = $idioma_padrao;
		$idiomas['es']['arquivo_idioma'] = 'es';
		$idiomas['es']['descricao'] = 'Spanish';
		$idiomas['es-es'] = $idioma_padrao;
		$idiomas['es-es']['arquivo_idioma'] = 'es';
		
		$idiomas['no'] = $idioma_padrao;
		$idiomas['no']['arquivo_idioma'] = 'no';
		$idiomas['no']['descricao'] = 'Norsk';
		
		$idiomas['bg'] = $idioma_padrao;
		$idiomas['bg']['arquivo_idioma'] = 'bg';
		$idiomas['bg']['descricao'] = 'Bulgaria';
		
		$idiomas['sl']['moeda'] = 'SIT';
		$idiomas['sl']['seperador_decimal'] = ',';
		$idiomas['sl']['seperador_milhar'] = '.';
		$idiomas['sl']['formato_data'] = 'd-m-Y';
		$idiomas['sl']['formato_hora'] = 'G:i';
		$idiomas['sl']['inicio_semana'] = 1;
		$idiomas['sl']['fuso_horario'] = 1;
		$idiomas['sl']['horario_verao'] = 1;
		$idiomas['sl']['arquivo_idioma'] = 'sl';
		$idiomas['sl']['descricao'] = 'Slovenski';
		
		
		
		$idiomas['sr'] = $idioma_padrao;
		$idiomas['sr']['arquivo_idioma'] = 'sr';
		$idiomas['sr']['descricao'] = 'Serbian';
		
		
		$idiomas['he'] = $idioma_padrao;
		$idiomas['he']['arquivo_idioma'] = 'he';
		$idiomas['he']['descricao'] = 'Hebrew';
		
		$idiomas['th'] = $idioma_padrao;
		$idiomas['th']['arquivo_idioma'] = 'th';
		$idiomas['th']['descricao'] = 'Thais';
		
		if(trim($codigo)!=""){
			return $idiomas[$codigo];
		}else{
			return $idiomas;
		}
	}
}
?>