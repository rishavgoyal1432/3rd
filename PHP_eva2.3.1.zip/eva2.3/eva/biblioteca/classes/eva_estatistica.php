<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
* Estat�sticas sobre a p�gina
*/
include("extras/class.webpagesize.php");
class eva_estatistica extends WebpageSize{
	/**
	* Construtor da classe
	*/
	function eva_estatistica(){
	} //eva_estatistica
	
	/**
	* Retorna uma tabela HTML com a lista de arquivos e tamanhos na p�gina
	* @param array Vetor com um conjunto de par�metros para montagem das abas
	* @return string Conjunto de abas em html, ou null
	*/
	function tamanho_pagina($url = "", $proxy = "", $porta = ""){
		global $config;
		if($url == ""){
			$url = $eva['config']['url'];
		}
		if(!isset($_GET['erro']) && !isset($_GET['teste'])) error_reporting(0);
		if($proxy != ""){
			$$url = $eva['config']['url'];
			$this->setURLviaProxy($url,$proxy,$porta);
		}else{
			$this->setURL($url);
		}	
		return $this->printResult();

	} //tamanho_pagina
} //eva_aestatistica
?>