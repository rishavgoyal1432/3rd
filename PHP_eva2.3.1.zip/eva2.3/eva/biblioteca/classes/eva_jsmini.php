<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
	
class eva_jsmini{	
	var $exception;
	
	function eva_jsmini($cache = ''){
		
	}
	
	function set_exception($word, $method='none'){
		$this->exception[] = array($word, $method);
	}
	
	function is_exception($word, $old_method=false){
		for($i=0; $i<count($this->exception); $i++){
			if(eregi($this->exception[$i][0], $word)) return $this->exception[$i][1];
		}
		return $old_method;
	}
	
	// cria o cache
	function compactar($url, $method = 'jsmini', $not_compact = false){
		global $eva, $config;	
		// if it is a php file eval it				
		$http = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']=="on")?"https":"http").'://'.$_SERVER['HTTP_HOST'].(!eregi(":", $_SERVER['HTTP_HOST'])?":".$_SERVER['SERVER_PORT']:"");
		if($this->_is_file($url) && eregi("\.php$", $url)){
			return $this->_compact($eva['arquivo']->ler((!eregi($http, $url)?$http:"").$url));
			//return $eva['arquivo']->eva_eval($eva['arquivo']->ler($url));
		}else if(eregi("^http://", $url)){
			$find[] = $eva['url_eva'];
			$find[] = $http."/{$eva['caminho_eva']}";
			$find[] = $config['url'];			
			$find[] = $http;
			$url = str_replace($find, "", $url);
		}
		//$url = eregi_replace(".*/eva/", "eva/", $url);
		
					
		// if su display all indented
		if($eva['seguranca']->verificar_acesso('SU') && !$not_compact){
			if($this->_is_file($url)){
				@chdir($eva['caminho_eva']);
				return file_get_contents($url);
			}else
				return $url; 
		}
		$eva['incluir']->incluir('arquivo');;
		$arquivo = "arquivos/cache/{$url}_";
		
		if(false && $this->_is_file($url) && empty($_GET['atualizar']) && $eva['arquivo']->existe($arquivo)){
			return $eva['arquivo']->ler($arquivo);
		}
		
		$method = $this->is_exception($url, $method);
		$out = $this->_compact($url, $method);
		if($this->_is_file($url))
			$eva['arquivo']->gravar($arquivo, $out);
		return $out;
	}
	
	
	function _compact($url, $method = 'jsmini', $_encoding = 0){
		global $eva, $config;
		@chdir($eva['caminho_eva']);
		if($eva['caminho_eva'] == 'eva/'){
			$url = str_replace(@$config['url'],"", $url);
			$url = str_replace(@$eva['url_eva'],"", $url);
			//echo $eva['url_eva']."\n".$config['url']."\n".$eva['config']['url']."\n".$url."\n";
		}
		else ini_set('allow_url_fopen', '1');
		//echo $url;
		if($this->_is_file($url))
			$code = file_get_contents($url);
		else
			$code = $url;
			
		switch ($method){
			case 'jsmini': 
				// the JSMin class now works on php strings, too
				define('JSMIN_AS_LIB', true); // prevents auto-run on include
				include_once("extras/jsmini2.php");							
				if(!isset($jsMin))$jsMin = new JSMin($code, false);
				else $jsMin->JSMin($code, false);
				// in that case, the modifies string is returned by minify():
				return $jsMin->minify();
			break;
			case 'packer':	
				if(empty($_encoding))			
					$_encoding = (strlen($url) < 256 &&  $this->_is_file($url))?62:0;
				//$_encoding = 0;
				/*
				'None' => 0,
				'Numeric' => 10,
				'Normal' => 62,
				'High ASCII' => 95
				*/
				include_once("extras/packer.php-1.0/class.JavaScriptPacker.php4");	
				//JavaScriptPacker($_script, $_encoding = 62, $_fastDecode = true, $_specialChars = false)
				if(!isset($packer))$packer = new JavaScriptPacker($code,$_encoding);
				else $packer->JavaScriptPacker($code,$_encoding);
				return $packer->pack();
			break;
		}
	}
	
	function _is_file($url){
		return (strlen($url) < 256 && (is_file($url) || eregi("\.(.){2,4}$", $url)));
	}
	
}
?>