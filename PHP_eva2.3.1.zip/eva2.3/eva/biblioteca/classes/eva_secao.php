<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

$eva['incluir']->incluir("aba");

/**
 * Fun��es para criar se��es para cada m�dulo
 *
 */
class eva_secao{
	
	/**
	 * Fun��o para exibir o formul�rio de cadastro de nova sess�o
	 *
	 * @param string $action
	 
	function form_secao2($action){
		global $idioma;
		global $eva;
		global $config;
		
		$se_cod = (isset($se_cod))? $se_cod:"";
		if ($se_cod != ""){
			$sql = "SELECT se_cod, se_nome, se_desc, se_grupo, se_pai FROM ".$config['bdprefixo']."_eva_secao WHERE se_cod = ".$se_cod;
			$rs = $eva['sql']->executar($sql);
			if ($edita = $rs->FetchRow()){
				$arr_se_grupo = explode(";", $edita['SE_GRUPO']);
			}  
		}
		?>
		<form action="index.php?modulo=<?php echo $_GET['modulo'] ?>&acao=<?php echo $_GET['acao'] ?>&subacao=<?php echo $_GET['subacao'] ?>&subacao_secao=salvar" method="post" enctype="multipart/form-data" name="cadastrar_secao" class="modulo" id="cadastrar_secao<?php echo $se_cod;?>">
		<?php 
		$menu[0]['action']="index.php?modulo={$_GET['modulo']}&acao=secao&subacao_secao=salvar";
		$menu[0]['confirma']="";
		$menu[0]['img']="imagens/16x16/actions/filesave.png";
		$menu[0]['url']="";
		$menu[0]['alt'] = $idioma["salvar"];
		$menu[0]['permissao']=true;
		$menu[0]['form_id']="cadastrar_secao{$se_cod}";
		
		echo $eva['modulo_eva_menu']->criar_menu($menu, false);
		?><?php 
		
		$menu['campo'][] = "se_nome{$eva['aba']->total}";
		$menu['alerta'][] = $idioma['validar_se_nome'];
		$menu['formato'][] = "nao_nulo";
		?>
		<table align="center" cellpadding="2" cellspacing="0" class="tabela_form">
		<tr>
			<td align="right" valign="top"><strong><?php echo $idioma['nome']; ?>:</strong></td>
			<td align="left"> <input name="se_nome" type="text" id="se_nome<?php echo $eva['aba']->total;?>" value="<?php if (isset($edita)){ echo $edita['SE_NOME'];} ?>" size="50" maxlength="50"> </td>
			</tr>
			<tr>
			<td align="right" valign="top"><strong><?php echo $idioma['descricao']; ?>:</strong></td>
			<td align="left"> <input name="se_desc" type="text" id="se_desc" value="<?php if (isset($edita)){ echo $edita['SE_DESC'];} ?>" size="50" maxlength="255"> </td>
			</tr>
			<tr>
			<td align="right" valign="top"><strong><?php echo $idioma['secao_pai']; ?>:</strong></td>
			<td align="left">
		<select name="se_pai">
		<option value="0"><?php echo $idioma['topo']; ?></option>
		<?php  
		$sql = "SELECT se_cod, se_nome FROM ".$config['bdprefixo']."_eva_secao, {$config["bdprefixo"]}_eva_modulo WHERE se_mo_cod = mo_cod AND mo_diretorio = '{$_GET["modulo"]}' order by se_nome";
		$rs = $eva['sql']->executar($sql);
		if($rs){
			while ($lista = $rs->FetchRow()) {
				?>
				<option value="<?php echo $lista['SE_COD']?>" <?php if (isset($edita) && $edita['SE_PAI'] == intval($lista['SE_COD'])) echo "selected";?>><?php echo $lista['SE_NOME']?></option>
				<?php
			}
		}
		?>
		</select>
		</td>
		</tr>
			<tr>
			<td align="right" valign="top"><strong><?php echo $idioma['permissoes_grupos']; ?>: </strong></td>
			<td align="left" valign="top"><table border="0" cellspacing="1" cellpadding="0">
				<tr>
				<td><table width="100%" border="0" cellspacing="0" cellpadding="1">
				<tr>
					<td><input name="se_grupo[]" type="checkbox" id="se_grupo<?php echo $eva['aba']->total?>0" value="t" <?php if (isset($edita)){ if (in_array("t", $arr_se_grupo)){echo "checked";}}else{echo "checked";} ?>></td>
					<td><?php echo $idioma['todos']; ?> <font color="#999999">[<?php echo $idioma['todos_usuarios']; ?>]</font></td>
				</tr>
				<tr>
					<td><input name="se_grupo[]" type="checkbox" id="se_grupo<?php echo $eva['aba']->total?>1" value="v" <?php if (isset($edita)){ if (in_array("v", $arr_se_grupo)){echo "checked";}}else{echo "checked";} ?>></td>
					<td><?php echo $idioma['visitantes']; ?></td>
				</tr>
				<tr>
					<td><input name="se_grupo[]" type="checkbox" id="se_grupo<?php echo $eva['aba']->total?>2" value="u" <?php if (isset($edita)){ if (in_array("u", $arr_se_grupo)){echo "checked";}}else{echo "checked";} ?>></td>
					<td><?php echo $idioma['usuarios']; ?></td>
				</tr>
				<?php 
				$sql = "SELECT gr_cod, gr_nome, gr_desc FROM ".$config['bdprefixo']."_eva_grupo  ORDER BY gr_nome";
				$rsGr = $eva['sql']->executar($sql);
				$contador = 3;
				while ($grupos = $rsGr->FetchRow()){
					?>
					<tr>
					<td width="5"><input name="se_grupo[]" type="checkbox"  id="se_grupo<?php echo $eva['aba']->total?><?php echo $contador ?>" value="<?php echo $grupos["GR_COD"] ?>" <?php if (isset($edita)){ if (in_array($grupos["GR_COD"], $arr_se_grupo)){echo "checked";}}else{echo "checked";} ?>></td>
					<td><?php echo $grupos["GR_NOME"] ?><font color="#999999"> [<?php echo $grupos["GR_DESC"] ?>]</font></td>
					</tr>
					<?php 
					$contador++;
				}
				?>				
				<tr>
				<td colspan="2"><hr size="1" noshade></td>
				</tr>
				<tr>
				<td align="center">
				<input type="checkbox" id="selecionar_todos<?php echo $eva['aba']->total?>" name="selecionar_todos<?php echo $eva['aba']->total?>" onChange="selecionar_todos(this,'se_grupo<?php echo $eva['aba']->total?>',<?php echo $contador ?>)">
				</td>					
				<td valign="middle">
				<label for="selecionar_todos<?php echo $eva['aba']->total?>">
				<?php echo $idioma['selecionar_todos'] ?>
				</label>
				</td>
				</tr>
				</table></td>
				</tr>
			</table></td>
			</tr>
			<tr>
				<td align="right">
				<?php if (isset($edita)){ ?>
				<input name="se_cod" type="hidden" id="se_cod" value="<?php echo  $edita['SE_COD']; ?>">
				<?php }?>
				</td>
			</tr>
			</table>
			<?php
			echo $eva['modulo_eva_menu']->criar_menu($menu);
			?>
		</form>
		<?php
	}
	*/
	/**
	 * Fun��o para exibir o formul�rio de cadastro de nova sess�o
	 *
	 * @param string $action
	 */
	function form_secao($action, $se_cod=''){
		global $idioma;
		global $eva;
		global $config;
		
		$se_cod = (isset($se_cod))? $se_cod:"";
		if (!empty($se_cod)){
			if ($edita = $this->_listar_secao_cod($se_cod)){
				$arr_se_grupo = explode(";", $edita['SE_GRUPO']);
			}  
		}
		$eva['incluir']->incluir("form");
		//$eva['form']->config($action, $av['AV_NOME']." (".$av['AV_DESC'].")","","",1);
		$eva['form']->campo('se_nome', $idioma['nome'],"text", @$edita['SE_NOME'], 50);
		
		$eva['form']->campo('se_desc', $idioma['descricao'],"text", @$edita['SE_DESC'], 255);
		
		$opcoes = array();
		$opcoes['0'] = $idioma['topo'];
		if($rs = $this->_listar_secao($_GET["modulo"])){
			while ($lista = $rs->FetchRow()) {
				$opcoes[$lista['SE_COD']] = $lista['SE_NOME'];
			}
		}
		$eva['form']->campo('se_pai', $idioma['secao_pai'],"select", @$edita['SE_PAI'], $opcoes);
		
		$opcoes = array();
		$opcoes['t'] = "{$idioma['todos']} <font color=\"#999999\">[{$idioma['todos_usuarios']}]";
		$opcoes['v'] = "{$idioma['visitantes']}";
		$opcoes['u'] = "{$idioma['usuarios']}";
		$sql = "SELECT gr_cod, gr_nome, gr_desc FROM ".$config['bdprefixo']."_eva_grupo  ORDER BY gr_nome";
		$rsGr = $eva['sql']->executar($sql);
		if($rsGr){
			while ($grupos = $rsGr->FetchRow()) {
				$opcoes[$grupos["GR_COD"]] = "{$grupos['GR_NOME']} <font color=\"#999999\"> [{$grupos['GR_DESC']}] </font>";
			}
		}
		$eva['form']->campo('se_grupo', $idioma['permissoes_grupos'],"checkbox", @$arr_se_grupo, $opcoes);
		
		if (isset($edita)){
				$eva['form']->campo('se_cod', '',"hidden",$edita['SE_COD']);
		}
		/*
		se_exibe_titulo
		se_exibe_data
		se_exibe_desc
		se_exibe_imprimir
		se_exibe_enviar
		se_exibe_visitas 
			*/	
		$opcoes = array();
		$opcoes['1'] = $idioma['sim'];
		$opcoes['0'] = $idioma['nao'];
		$eva['form']->campo('se_exibe_titulo', $idioma['exibe_titulo'], "select", @$edita['SE_EXIBE_TITULO'], $opcoes);
				
		$menu[0]['action']="index.php?modulo=eva_conteudo&acao=secao&subacao_secao=salvar";
		$menu[0]['confirma']="";
		$menu[0]['img']="imagens/16x16/actions/filesave.png";
		$menu[0]['url']="";
		$menu[0]['alt'] = $idioma["salvar"];
		$menu[0]['permissao']=true;
		//$menu[0]['form_id']="cadastrar_secao{$se_cod}";
		
		$eva['form']->menu($menu);
		
		return $eva['form']->criar();
	}
	
	/**
	 * Fun��o para salvar as informa��es da sess�o de um m�dulo
	 *
	 * @return boolean
	 */
	function salvar_secao(){
		global $idioma;
		global $eva;
		global $config;
		global $eva;

		$se_grupo = (isset($_POST['se_grupo']))? implode(";", $_POST['se_grupo']) : "";
		if (isset($_POST['se_cod']) && intval($_POST['se_cod']) > 0){
			// se a secao pai nao for definida o codigo � o mesmo codigo dela mesmo
			$_POST['se_pai']=(intval($_POST['se_pai'])>0)?$_POST['se_pai']:$_POST['se_cod'];
			$sql = "UPDATE ".$config['bdprefixo']."_eva_secao SET 
			se_nome = '".$eva['seguranca']->tratar_seguranca($_POST['se_nome'])."', 
			se_desc = '".$eva['seguranca']->tratar_seguranca($_POST['se_desc'])."', 
			se_grupo = '".$se_grupo."', 
			se_pai = ".intval($_POST['se_pai']).",
			se_exibe_titulo = ".intval(@$_POST['se_exibe_titulo']).",
			se_exibe_data = ".intval(@$_POST['se_exibe_data']).",
			se_exibe_desc = ".intval(@$_POST['se_exibe_desc']).",
			se_exibe_imprimir = ".intval(@$_POST['se_exibe_imprimir']).",
			se_exibe_enviar = ".intval(@$_POST['se_exibe_enviar']).",
			se_exibe_visitas = ".intval(@$_POST['se_exibe_visitas'])."
			WHERE se_cod=".$_POST['se_cod'];
		}else{
			$se_cod = $eva['sql']->selecionar_maior("eva_secao","se_cod");
			
			$sql = "SELECT mo_cod FROM {$config["bdprefixo"]}_eva_modulo WHERE mo_diretorio = '{$_GET['modulo']}'";		
			$rs = $eva['sql']->executar($sql);
			if($modulo_secao = $rs->FetchRow()){
				$se_mo_cod = $modulo_secao["MO_COD"];
			}
			
			// se a secao pai nao for definida o codigo � o mesmo codigo dela mesmo
			$_POST['se_pai']=(intval($_POST['se_pai'])>0)?$_POST['se_pai']:$se_cod;
			
			$sql = "INSERT INTO ".$config['bdprefixo']."_eva_secao 
			(se_cod, se_pai, se_mo_cod,  se_nome, se_desc, se_grupo, se_exibe_titulo, 		se_exibe_data, se_exibe_desc, se_exibe_imprimir, se_exibe_enviar, se_exibe_visitas) 
			VALUES 
			(".$se_cod.", ".intval($_POST['se_pai']).", ".$se_mo_cod.",'".$eva['seguranca']->tratar_seguranca($_POST['se_nome'])."', '".$eva['seguranca']->tratar_seguranca($_POST['se_desc'])."', '".$se_grupo."', ".intval(@$_POST['se_exibe_titulo']).", ".intval(@$_POST['se_exibe_data']).", ".intval(@$_POST['se_exibe_desc']).", ".intval(@$_POST['se_exibe_imprimir']).", ".intval(@$_POST['se_exibe_enviar']).", ".intval(@$_POST['se_exibe_visitas']).")";
		}
		if ($rs = $eva['sql']->executar($sql)){
			return true;
		}
		return false;
	}
	
	/**
	 * Fun��o para montar campo select para sele��o de se��es
	 *
	 * @param string $campo
	 * @param string $selecionado
	 * @param string $modulo
	 * @return string
	 */
	function selecionar_secao($campo,$selecionado,$modulo = ""){
		global $eva;
		global $config;
		global $idioma;
		
		$modulo = ($modulo == "")? $_GET["modulo"] : $modulo;
		
		$selecao = "<select name=\"".$campo."\">";		
		$sql = "SELECT 
					se_cod, se_nome, se_desc 
				FROM 
					".$config['bdprefixo']."_eva_secao, 
					".$config["bdprefixo"]."_eva_modulo 
				WHERE 
					se_mo_cod = mo_cod 
					AND 
					mo_diretorio = '".$modulo."' 
				ORDER BY
					se_nome";
		$rs = $eva['sql']->executar($sql);
		if($rs->RecordCount()){
			$selecao .= "<option value=\"\">".$idioma['selecione_secao']."</option>";
			while ($secao = $rs->FetchRow()) {
				$selecao .= "<option value=\"".$secao['SE_COD']."\"";				
				if (intval($selecionado) == intval($secao['SE_COD']))
					$selecao .= "selected";
				$selecao .= ">".$secao['SE_NOME']."</option>";				
			}
		}else{
			$selecao .= "<option value=\"\">".$idioma['nenhuma_secao_encontrada']."</option>";
		}
		$selecao .= "</select>";
		return $selecao;
	}
	
	/**
	 * Apaga se��o
	 *
	 * @param int $se_cod
	 * @return bool
	 */
	function apagar_secao($se_cod){
		global $idioma;
		global $eva;
		global $config;
		global $eva;

		$sql = "DELETE FROM ".$config['bdprefixo']."_eva_secao WHERE se_cod =".intval($se_cod);
		//echo $sql;exit;
		if ($rs = $eva['sql']->executar($sql)){
			return true;
		}
		return false;
	}
	
	/**
	 * Lista as secoes
	 *
	 */
	function listar_secao(){
		global $idioma;
		global $eva;
		global $config;
		global $eva;
		$sql = "SELECT se_cod, se_nome, se_desc, se_alinhamento FROM ".$config['bdprefixo']."_eva_secao, {$config["bdprefixo"]}_eva_modulo WHERE se_mo_cod = mo_cod AND mo_diretorio = '{$_GET['modulo']}' order by se_nome";
		$rs = $eva['sql']->executar($sql);
		if($rs && intval($rs->RecordCount())){
			?>
			<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="1">
			<?php
			while ($secao = $rs->FetchRow()) {
				?>
				<tr>
				<td align="left" valign="top" class="<?php echo $eva['geral']->alterna_linha();?>"><img src="imagens/16x16/actions/list.png" width="22" height="22" border="0" align="left"><a href="index.php?modulo=<?php echo $_GET['modulo']?>&se_cod=<?php echo $secao['SE_COD']?>"><strong><?php echo $secao['SE_NOME']?></strong></a>
				<?php
				if($eva['seguranca']->verificar_acesso('admin')){
					?>
					(<?php echo $secao['SE_COD']?>) <a href="index.php?modulo=<?php echo $_GET['modulo'] ?>&acao=secao&subacao=listar&subacao_secao=cadastrar&se_cod=<?php echo $secao['SE_COD'];?>"><img src="imagens/16x16/actions/edit.png" width="16" height="16" border="0"></a> <a href="index.php?modulo=<?php echo $_GET['modulo'] ?>&acao=<?php echo $_GET['acao'] ?>&subacao=<?php echo $_GET['subacao'] ?>&subacao_secao=apagar&se_cod=<?php echo $secao['SE_COD'];?>" onClick="return confirma('Voc� deseja apagar a se��o �<?php echo $secao['SE_NOME']; ?>�?')"><img src="imagens/16x16/actions/edittrash.png" width="16" height="16" border="0"></a>
					<?php
				}
				?>
				<br />
				<?php 
				if($secao['SE_DESC'] != $secao['SE_NOME']){
					echo $secao['SE_DESC'];
				}
				?></td>
				</tr>
				<?php
			}
			?>
			</table>
			<?php
		}else{
			$eva['incluir']->incluir("alerta");
			$eva['alerta']->exibir("redled", $idioma['nenhuma_secao_encontrada']."!");
		}
	}
	
	
	/**
	 * A�oes da secao
	 *
	 */
	function gerenciar_secao(){
		global $idioma;
		global $eva;
		
		switch($_GET['subacao_secao']){
			case 'cadastrar':
				$aba["selecionado"]=1;
				//$this->form_secao();			
			break;
			case 'salvar':
				$eva['incluir']->incluir("alerta");
				if ($this->salvar_secao()){
					$eva['alerta']->exibir("greenled", "Se��o salva com sucesso!");
				}else{
					$eva['alerta']->exibir("redled", "Falha ao salvar se��o!");
				}
				$aba["selecionado"]=0;
				//$this->listar_secao();
			break;
			default:
				if($eva['seguranca']->verificar_acesso('admin')){
					if($_GET['subacao_secao'] == "apagar" && !empty($_GET['se_cod'])){
						$eva['incluir']->incluir("alerta");
						if($this->apagar_secao($_GET['se_cod'])){
							$eva['alerta']->exibir("greenled", "Se��o exclu�da com sucesso!");
						}else{
							$eva['alerta']->exibir("redled", "Falha ao excluir se��o!");
						}
					}
				
				}		
				$aba["selecionado"]=0;
				//$this->listar_secao();
			break;
		}
		if($eva['seguranca']->verificar_acesso('admin')){
			$aba[0]['nome']="Listar";
			$aba[0]['php']="\$eva['secao']->listar_secao();";
			$aba[0]['arquivo']="";
			$aba[0]['selecionado']=true;
			$aba[0];
			$aba[0]['img']="imagens/16x16/mimetypes/doc.png";
			
			$aba[1]['nome']="Novo";
			$aba[1]['php']="echo \$eva['secao']->form_secao(\"index.php?modulo={$_GET['modulo']}&acao=secao&subacao=salvar\", ".intval(@$_GET['se_cod']).");";
			$aba[1]['arquivo']="";
			$aba[1]['selecionado']=false;
			$aba[1];
			$aba[1]['img']="imagens/16x16/actions/filenew.png";
			
			if(isset($se_cod) and $_GET['subacao_secao']=='cadastrar'){
				$aba["selecionado"]=2;
				$aba[2]['nome']="Editar";
				$aba[2]['php']="echo \$eva['secao']->form_secao(\"index.php?modulo={$_GET['modulo']}&acao=secao&subacao=listar&subacao_secao=cadastrar&se_cod={$se_cod}\", {$_GET['se_cod']});";
				$aba[1]['arquivo']="";
				$aba[2]['selecionado']=false;
				$aba[2];
				$aba[2]['img']="imagens/16x16/actions/edit.png";
			}
			$eva['aba']->criar_abas($aba);
		}else{
			$this->listar_secao();
		}
		
	}
	
	/**
	 * Cria Se��o
	 *
	 * @param string $mo_dir
	 * @param string $se_nome
	 * @param string $se_desc
	 * @param int $se_cod if is editing
	 * @param int $se_pai
	 * @param string $se_grupo
	 * @param string $se_alinhamento
	 * @param string $se_ordenar
	 * @param string $se_imagem
	 * @param string $se_exibe_titulo
	 * @param string $se_exibe_data
	 * @param string $se_exibe_desc
	 * @param string $se_exibe_imprimir
	 * @param string $se_exibe_enviar
	 * @param string $se_exibe_visitas
	 * @return boolean
	 */
	function criar_secao($mo_dir, $se_nome, $se_desc, $se_cod = 0, $se_pai = 0, $se_grupo="t", $se_alinhamento="", $se_ordenar="", $se_imagem="", $se_exibe_titulo="", $se_exibe_data="", $se_exibe_desc="", $se_exibe_imprimir="", $se_exibe_enviar="", $se_exibe_visitas=""){
		global $idioma;
		global $eva;
		global $config;
		global $eva;		
		
		if(empty($se_cod)){
			$update = false;
			$se_cod = $eva['sql']->selecionar_maior("eva_secao","se_cod");
		}else{
			$update = true;
		}
		
		//pegue o $se_mo_cod onde = $mo_dir
		$se_mo_cod = $eva['modulo_eva_modulo']->get_mo_cod($mo_dir);
				
		// se a secao pai nao for definida o codigo � o mesmo codigo dela mesmo
		$se_pai=(!empty($se_pai))?$se_pai:$se_cod;

		
		if ($update){
			$sql = "UPDATE ".$config['bdprefixo']."_eva_secao SET se_nome = '".$eva['seguranca']->tratar_seguranca($se_nome)."', se_desc = '".$eva['seguranca']->tratar_seguranca($se_desc)."', se_grupo = '".$se_grupo."', se_pai = ".intval($se_pai)." WHERE se_cod=".$se_cod;
		}else{
			$sql = "INSERT INTO ".$config['bdprefixo']."_eva_secao (se_cod, se_pai, se_mo_cod,  se_nome, se_desc, se_grupo) VALUES (".$se_cod.", ".intval($se_pai).", ".$se_mo_cod.",'".$eva['seguranca']->tratar_seguranca($se_nome)."', '".$eva['seguranca']->tratar_seguranca($se_desc)."', '".$se_grupo."')";
		}
		if ($rs = $eva['sql']->executar($sql)){
			return true;
		}
		return false;
	}
	
	/**
	 * Fun��o para montar campo select para sele��o de se��es
	 *
	 * @param string $campo
	 * @param string $selecionado
	 * @param string $modulo
	 * @return string
	 */
	function selecionar_secao_nome($nome){		
		$rs = $this->_listar_secao("", $nome);
		return $rs->FetchRow();
	}
	
	/**
	 * Create a form to record sessions using ajax
	 *
	 * @param string $modulo
	 * @return HTML
	 */
	function form_secao_ajax($modulo){
		global $eva, $config, $idioma;
		$atributos['se_alinhamento']['noedit']=true;
		$atributos['se_ordenar']['noedit']=true;
		$atributos['se_imagem']['noedit']=true;
		$atributos['se_exibe_titulo']['noedit']=true;
		$atributos['se_exibe_data']['noedit']=true;
		$atributos['se_exibe_desc']['noedit']=true;
		$atributos['se_exibe_imprimir']['noedit']=true;
		$atributos['se_exibe_enviar']['noedit']=true;
		$atributos['se_exibe_visitas']['noedit']=true;
		
		$atributos['se_mo_cod']['fk']['tabela'] = $config['bdprefixo']."_eva_modulo";
		$atributos['se_mo_cod']['fk']['colunas'] = array("mo_nome");
		$atributos['se_mo_cod']['nome'] = $idioma['modulo'];
		$atributos['se_mo_cod']['igual'] = $eva['modulo_eva_modulo']->get_mo_cod($modulo);
				
		$atributos['se_pai']['fk']['tabela'] = $config['bdprefixo']."_eva_secao";
		$atributos['se_pai']['fk']['colunas'] = array("se_nome");		
		$atributos['se_pai']['nome'] = $idioma['secao_pai'];
		
		$atributos['se_nome']['nome'] = $idioma['nome'];
		$atributos['se_desc']['nome'] = $idioma['descricao'];
		$atributos['se_grupo']['nome'] = $idioma['grupo'];
				
		return $eva['sql']->form_tabela($config['bdprefixo'].'_eva_secao', 20, "", "", $atributos);
	}
	
	/**
	 * Lista as se��es
	 *
	 * @param string $modulo
	 * @param string $link
	 * @return HTML
	 */
	function listar_secao_grade($modulo, $link=""){
		global $idioma;
		global $eva;
		$rs = $this->_listar_secao($modulo, "", "se_nome");
		$grade['dados'] = array();
		while($linha = $rs->FetchRow()){
			if(empty($link))
				$dados = $linha['SE_NOME']." ".$linha['SE_DESC'];
			else{
				// replace {cod} for the the SE_COD
				$link2 = str_replace("{cod}", $linha['SE_COD'], $link);
				$dados = "<a href='{$link2}'>".$linha['SE_NOME']." ".$linha['SE_DESC']."</a>";
			}
			$grade['dados'][] = array($dados);
		}
		//$grade['campos'] = array($idioma['secoes']);
		$grade['campos'] = array("");
		$grade['largura'] = array("");
		//$grade['selecionar'] = "se_cod";
		return $eva['grade']->grade_tabela($grade);
	}
	
	/**
	 * Lista se��es
	 *
	 * @param string $modulo
	 * @param string $se_nome
	 * @param string $order_by
	 * @param array $secoes
	 * @return SQL resource
	 */
	function _listar_secao($modulo="", $se_nome="", $order_by="", $secoes=array()){
		global $eva, $config;
		$sql = "SELECT se_cod, se_nome, se_desc, se_alinhamento, se_grupo, se_pai , se_exibe_titulo, se_exibe_data, se_exibe_desc, se_exibe_imprimir, se_exibe_enviar, se_exibe_visitas 
		FROM ".$config['bdprefixo']."_eva_secao";
		$where=false;
		if(!empty($modulo)){
			$sql .= ", {$config['bdprefixo']}_eva_modulo ";
			$sql .= " WHERE se_mo_cod = mo_cod ";
			$sql .= " AND mo_diretorio = '{$modulo}'";
			$where=true;
		}
		if(!empty($se_nome)){
			if($where){
				$sql .= " AND ";
			}else{
				$sql .= " WHERE ";
			}
			$sql .= " se_nome = '{$se_nome}'";
			$where=true;
		}		
		// seleciona somente as secoes cujo os codigos estao no array
		if(!empty($secoes)){
			if($where){
				$sql .= " AND ";
			}else{
				$sql .= " WHERE ";
			}
			$sql .= " ( ";
			for($i=0; $i<count($secoes); $i++){
				$sql .= " se_cod = '{$secoes[$i]}' ";
				if($i+1<(count($secoes))) $sql .= " OR ";
			}
			$sql .= " ) ";
			$where=true;
		}
		if(!empty($order_by))
			$sql .= " order by {$order_by}";
		return $eva['sql']->executar($sql);
	}	
	
	/**
	 * Select a single session by the code
	 *
	 * @param int $se_cod
	 * @return array
	 */
	function _listar_secao_cod($se_cod){
		global $eva, $config;
		$sql = "SELECT se_cod, se_nome, se_desc, se_alinhamento, se_grupo, se_pai, se_exibe_titulo, se_exibe_data, se_exibe_desc, se_exibe_imprimir, se_exibe_enviar, se_exibe_visitas 
		FROM ".$config['bdprefixo']."_eva_secao";
		if(!empty($se_cod)){
			$sql .= " WHERE se_cod = {$se_cod} ";
		}
		$rs = $eva['sql']->executar($sql);
		return $rs->FetchRow();
	}	
	
	/**
	 * cria o complemento para sql com as permissoes de grupos
	 *
	 * @param string $grupos
	 * @param array $no_and
	 * @return string
	 */
	function sql_grupos($grupos="", $no_and=false){
		global $eva;
		if($eva['seguranca']->verificar_acesso('SU'))
			return "";
		if(!$no_and)
			$sql = " AND ";
		else
			$sql = "";
		
		$sql .= "( se_grupo LIKE '%t%' ";
		if(empty($grupos)){
			$sql .= ")";
		}else if(is_array($grupos)){			
			for($i=0;$i<count($grupos);$i++){
				// por enquanto ta igual mas devereia ser uma expre��o regular
				$sql .= " OR se_grupo = '{$grupos[$i]}' ";
			}
			$sql .= ")";
		}else{
			$sql .= " OR se_grupo = '{$grupos[$i]}' )";
		}
		return $sql;
	}
} //eva_secao
?>