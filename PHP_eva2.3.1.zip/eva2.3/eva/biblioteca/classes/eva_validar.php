<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

require_once("extras/vimage/vimage.php");

/**
* Valida os dados enviados pelos usuarios
*/
class eva_validar extends vImage{
	
	// Lista de express�es regulares
	var $er;
	
	/**
	* Construtor da classe
	*/
	function eva_validar(){
		// Express�es regulares para valida��o de campos em formul�rios
		$this->er['texto'] = "^\w+$";
		$this->er['branco'] = "^\s+$";
		$this->er['letras'] = "^[a-zA-Z]+$";
		$this->er['letras_numeros'] = "^[a-zA-Z0-9\s]+$";
		$this->er['sem_espaco'] = "^[a-zA-Z0-9]+$";
		$this->er['numeros'] = "^[0-9]+$";
		$this->er['numeros_inteiros'] = "^[0-9]+$";
		$this->er['letra_ou_numero'] = "^([a-zA-Z]|[0-9])$";
		$this->er['ponto_flutuante'] = "^((\d+(\.\d*)?)|((\d*\.)?\d+))$";
		$this->er['ponto_decimal'] = "^((\d+(\,\d*)?)|((\d*\,)?\d+))$";
		$this->er['ponto_decimal_2_casas'] = "^(\d+((,\d{1,2})|(\.\d{1,2}))?)$";
		$this->er['email'] = "^.+\@.+\..+$";
		$this->er['nao_nulo'] = "^[\s|\S]+$";
		$this->er['rg'] = "[0-9]\.[0-9]{3}\.[0-9]{3}\-\d";
		$this->er['cpf'] = "[0-9]\.[0-9]{3}\.[0-9]{3}\-\d";
		$this->er['data'] = "^([0-9]{2}\/[0-9]{2}\/[0-9]{4})$";
		$this->er['data_hora'] = "^([0-9]{2}\/[0-9]{2}\/[0-9]{4}\s[0-9]{2}:[0-9]{2})$";
		$this->er['cep'] = "^[0-9]{8}$";		
	} //eva_validar
	
	
	/**
	* @return array com as regras de validacao
	*/
	function regras(){
		return $this->er;
	}// regras
	
	/**
	* Compara os valores do vetor campo com a express�o regular equivalente ao vetor tipo
	* @param string Caminho e nome do arquivo a ser gravado
	* @param string Informa��o a ser armazenada no arquivo
	* @return int Tamanho em bytes do arquivo gravado
	*/	
	function validar_campos($formulario,$campo,$alerta,$tipo){
		global $eva;
		$validar_campo = "var {$formulario}_campo = new Array(";
		$validar_alerta = "var {$formulario}_alerta = new Array(";
		$validar_tipo = "var {$formulario}_tipo = new Array(";
		for($i=0;$i<count($campo);$i++){
			if(empty($campo[$i]))
				continue;
			$tipo[$i] = (trim($tipo[$i]) != "")? $tipo[$i] : "nao_nulo";
			$validar_campo .= "'".$campo[$i]."',";
			$validar_alerta .= "'".$alerta[$i]."',";
			$validar_tipo .= "/".$this->er[$tipo[$i]]."/,";
		}
		
		$validar_campo = substr($validar_campo,0,-1).");";
		$validar_alerta = substr($validar_alerta,0,-1).");";
		$validar_tipo = substr($validar_tipo,0,-1).");";
		//echo "{$validar_campo}{$validar_alerta}{$validar_tipo}";exit;
		$eva['script'][]="{$validar_campo}{$validar_alerta}{$validar_tipo};";
		//var_dump("{$validar_campo}{$validar_alerta}{$validar_tipo}");
		
		return "
		<input name=\"validar_campo\" type=\"hidden\" id=\"validar_campo\" value=\"".implode(";",$campo)."\">
		<input name=\"validar_alerta\" type=\"hidden\" id=\"validar_alerta\" value=\"".implode(";",$alerta)."\">
		<input name=\"validar_tipo\" type=\"hidden\" id=\"validar_tipo\" value=\"".implode(";",$tipo)."\">";
	} //validar_campos


	var $invalido = false;
	
	/**
	* Verifica se o CPF � v�lido
	* @param string N�mero de CPF
	* @return boolean True caso seja v�lido
	*/	
	function validar_cpf($cpf){
		$cpf = preg_replace("/[\.-]/", "", $cpf);
		for($i = 0; $i <= 9; $i++){
			if($cpf == str_repeat($i , 11)){
				$this->invalido = true;
			}
		}
		if($this->invalido == 1 or strlen($cpf) <> 11 or !is_numeric($cpf) or $cpf == "12345678909"){
			return false;
		}
		$res = $this->soma(10, $cpf);
		$dig1 = $this->pega_digito($res);
		$res2 = $this->soma(11, $cpf.$dig1);
		$dig2 = $this->pega_digito($res2);
		if($cpf{9} <> $dig1 or $cpf{10} <> $dig2){
			return false;
		}
		return true;
	} //validar_cpf
	
	/**
	* Realizar soma para verifica��o
	* @param int
	* @return int N�mero de CPF
	*/	
	function soma($num, $cpf){
		$j = 0;
		$res = "";
		for($i = $num; $i >= 2; $i--){ $res += ($i * $cpf{$j}); $j++;}
			return $res;
	} //soma
	
	/**
	* Retorna o d�gito verificador
	* @param int $res N�mero a ser verificado
	* @return int $dig D�gito verificador
	*/	
	function pega_digito($res){
		$dig = $res % 11;
		$dig = $dig < 2 ? $dig = 0 : $dig = 11 - $dig;
		return $dig;
	} //pega_digito
	
		
	/**
	 * gera texto para a imagem
	 *
	 * @param int $num
	 * @param string $item
	 */
	function gerar_texto($num, $item){
		# receber tamanho da string
		if (($num != '')&&($num > $this->numChars)) $this->numChars = $num;		
		# gerar string randmica
		$this->texto = $this->gerString();
		$_SESSION['vImageCodS'.$item]= $this->texto;
	} //gerar_texto
	
	
	/**
	 * faz a comparacao da sessao do validador com o q foi digitado
	 *
	 * @param string $var_post
	 * @return boolean
	 */
	function validar_validador($var_post){
		global $eva;
		global $idioma;
		if(!empty($_POST[$var_post]) && !empty($_SESSION['vImageCodS'.$var_post])){
			$this->postCode = $_POST[$var_post];
			$this->sessionCode = $_SESSION['vImageCodS'.$var_post];
			if($this->postCode == $this->sessionCode){
				return true;
			}
		}else{			
			//var_dump($_POST);
			//$eva['alerta']->adicionar("redled", "{$var_post}: {$this->postCode} = {$_SESSION['vImageCodS'.$var_post]}");
		}	
		$eva['incluir']->incluir("alerta");
		$eva['alerta']->adicionar("redled", $idioma['validacao_incorreta']."!<br>");
		return false;
	} //validar_validador
	
	/**
	* valida uma expressao regular
	* @param string valor do campo
	* @param string Tipo do validador
	* @return bool
	*/	
	function validar_campo($valor,$tipo){			
		return eregi($this->er[$tipo], $valor);
	} //validar_campo
	
} //eva_validar
?>