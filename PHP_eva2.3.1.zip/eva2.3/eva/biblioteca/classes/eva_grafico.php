<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
include_once("extras/graph.php");
class eva_grafico extends graph{		
	/**
	 * Construtor
	 *
	 * @param int $width
	 * @param int $height
	 * @param string $titulo
	 * @param string $desc_x
	 * @param string $desc_y
	 * @return eva_grafico
	 */
	function eva_grafico($width = 400, $height = 240, $titulo = "", $desc_x = "", $desc_y = "", $legend = false){
		$this->graph($width,$height);
		//$this->parameter['output_format'] = 'JPEG';
		$this->parameter['path_to_fonts'] = 'biblioteca/fonts/';
		$this->parameter['title'] = $titulo;
		$this->parameter['x_label'] = $desc_x;
		$this->parameter['y_label_left'] = $desc_y;
		if($legend){
			$this->parameter['legend']        = 'outside-top';
			$this->parameter['legend_border'] = 'black';
			$this->parameter['legend_offset'] = 1;
		}
	}
	
	/**
	 * Cria um grafico com barras verticais
	 *
	 * @param array $x
	 * @param array $y
	 */
	function grafico_barra($x = array() , $y = array(), $file=""){
		if(!empty($x))		
			$this->x_data = $x;
		//var_dump($y);
		//$x = array('Fri', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri');
		//$y[$key]['valor'] = array(2, 10,  3,  5,  8,  9);
		//$y[$key]['format'] = array('colour' => 'blue', 'bar' => 'fill');
		if(count($y)>1){
			$this->parameter['bar_size']    = 1.5; // make size > 1 to get overlap effect
			//$this->parameter['bar_spacing'] = 20; // don't forget to increase spacing so that graph doesn't become one big block of colour
		}
		while (list($key, $value) = each($y)) {
        	$this->y_data[$key] = $value['valor'];
			$this->y_format[$key] = $value['format'];
			$this->y_order[] = $key;
		}	
		//var_dump($this->parameter['path_to_fonts'].$message['font']);exit;
		//ob_end_clean();
		$this->draw();
		// save the file if is set
		if(!empty($file)){
			$c = ob_get_contents();
			global $eva;
			$eva['incluir']->incluir("arquivo");
			$eva['arquivo']->gravar($file, $c);
		}
		exit;
		//$this->draw_stack();
	}

}
?>