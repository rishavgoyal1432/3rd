<?php
/**
* @package evacms
* @copyleft (cc) 2004-2006 EVAcms. Alguns direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

/**
* Cria um conjuto de abas para acesso a diferentes arquivos
*/
class eva_aba{

	var $total = "__0";
	var $contador = 0;
	var $selecionada = "";
	var $cod = 0;
	var $total_abas = 0;
	
	/**
	* Construtor da classe
	*/
	function eva_aba(){
	} //eva_aba
	
	/**
	* Cria um conjuto de abas para acesso a diferentes arquivos
	* @param array Vetor com um conjunto de par�metros para montagem das abas
	* @return string Conjunto de abas em html, ou null
	*/
	function criar_abas(&$parametros, $retornar = false, $id = ''){ 
		global $config;
		global $idioma;
		global $bd;
		global $eva;
		$this->contador += 100;
		// para poder contar quantas abas sao
		$temp_parametros = $parametros;
		unset($temp_parametros['selecionado']);
		unset($temp_parametros['alinhamento']);
		unset($temp_parametros['sentido']);
		
		$_GET['comando'] = (!empty($_GET['comando']))?$_GET['comando']:"";
		
		if($this->cod == 0){
			$eva['script'][] = "var eva_alerta_aba = '".$idioma['deseja_prosseguir']."';";
		}
		
		$aba_total = $this->contador;
		//var_dump($temp_parametros);echo "<hr>";var_dump(count($temp_parametros));
		$ultima_aba = $aba_total+(count($temp_parametros)-1);//echo $ultima_aba;
		$aba_confere = $aba_total;
		$cookie_id = $id.($_GET['modulo']=="eva_index"?"":$_GET['modulo']).($_GET['comando']=="include"?"":$_GET['comando']).(empty($eva['xml_include_id'])?"":$eva['xml_include_id']);
		//var_dump($_COOKIE);
		$aba_selecionada = (!empty($_COOKIE[$cookie_id.$aba_total]) && intval($_COOKIE[$cookie_id.$aba_total])<=$ultima_aba)? $_COOKIE[$cookie_id.$aba_total] : $aba_total;
		//var_dump($aba_selecionada);
		$aba_selecionada = (isset($parametros['selecionado']))? $parametros['selecionado']+$aba_total : $aba_selecionada;
		//var_dump($aba_selecionada);
		$aba_selecionada = (isset($_GET['aba_num']) && intval($_GET['aba_num']) > 0 && substr($_GET['aba_num'],0,1) == substr($this->contador,0,1))? $_GET['aba_num'] : $aba_selecionada;
		//var_dump($aba_selecionada);
		$this->selecionada = $aba_selecionada;
		
		unset($parametros['selecionado']);
		
		$alinhamento = (isset($parametros['alinhamento']) && trim($parametros['alinhamento']) != "")? $parametros['alinhamento'] : "left";
		unset($parametros['alinhamento']);
		
		$sentido = (isset($parametros['sentido']) && trim($parametros['sentido']) != "")? $parametros['sentido'] : "horizontal";
		unset($parametros['sentido']);
		
		// Abas para sub-modulos
		if(isset($parametros['modulo']) && trim($parametros['modulo']) != ""){
			$sql = "SELECT 
						mo_modelo,mo_nome,mo_desc,mo_atributos, mo_diretorio, mo_cod
					FROM 
						{$config["bdprefixo"]}_eva_modulo 
					WHERE 
						mo_diretorio LIKE '%{$parametros['modulo']}_%' 
					AND 
						mo_status = 'a'
					ORDER BY
						mo_nome
			";
			$rs_aba = $eva['sql']->executar($sql);
			$c=0;
			$abas = $parametros;
			$eva['modulo_dados']['mo_diretorio'] = $abas['modulo'];
			unset($abas['modulo']);
			$parametros=array();
			while($aba_modulo = $rs_aba->FetchRow()) {
				$parametros[$c]['nome']=$aba_modulo['MO_NOME'];
				include("modulos/{$aba_modulo['MO_DIRETORIO']}/eva_config.php");
				$parametros[$c]['img'] = $mo_icone;
				$parametros[$c]['diretorio']=$aba_modulo['MO_DIRETORIO'];
				$parametros[$c]['arquivo']="modulos/{$aba_modulo['MO_DIRETORIO']}/index.php";
				$parametros[$c]['include'][]="modulos/{$aba_modulo['MO_DIRETORIO']}/idiomas/{$config['idioma']}.php";
				$c++;
			}
			
			$total_abas = count($abas);
			$total_parametros = count($parametros);
			
			$x=0;
			for($i=0;$i < $total_abas;$i++){
				for($j=0;$j < $total_parametros;$j++){
					if($eva['modulo_dados']['mo_diretorio']."_".$abas[$i]['nome'] == $parametros[$j]['diretorio']){
						$nova_aba[$x] = $parametros[$j];
						$parametros[$j]['nome'] = "";
						$x++;
					}
				}
			}
			
			for($j=0;$j < $total_parametros;$j++){
				if($parametros[$j]['nome'] != ""){
					$nova_aba[$x] = $parametros[$j];
					$x++;
				}
			}
			
			$parametros = array();
			$parametros = $nova_aba;
		} 
		$cont_aba=0;
		
		// Verifica se existe htmlarea em algum inlude
		// Se existir trava as outras abas
		$this->total_abas = 0;
		for ($i=0;$i < count($parametros);$i++){
			$parametros[$i]['editor'] = (isset($parametros[$i]['editor']))? $parametros[$i]['editor'] : false;
			if(!isset($parametros[$i]['permissao']) || (isset($parametros[$i]['permissao']) && $eva['seguranca']->verificar_acesso($parametros[$i]['permissao'])) || $parametros[$i]['permissao'] === true){
				$this->total_abas ++;
			}
		}
		// Se n�o ira exibir nenhuma aba, sair
		if($this->total_abas == 0) return;
		// insere alguns css especificos		
		if($eva['geral']->detectar_navegador('IE'))
			$eva['head'][] = '<style type="text/css">.aba_horizontal_conteudo { width:100%;}</style>';
		else
			$eva['head'][] = '<style type="text/css">.aba_horizontal_espaco { width:100%;}</style>';
		
		$html['horizontal'] = '<table width="100%"><tr><td>			
		<table border="0" cellspacing="0" cellpadding="0" width="100%" align="'.$alinhamento.'">
		<tr>
			<td valign="bottom"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td>{abas}</td><td class="aba_horizontal_espaco"></td></tr></table></td>
		</tr>
		<tr>
			<td valign="top">
				{conteudo}
			</td>
		</tr>
		</table></td></tr></table>';
		
		$html['vertical'] = '								
		<table width="100%"><tr><td><table border="0" cellspacing="0" cellpadding="0" width="100%" align="'.$alinhamento.'">
		<tr>
		<td valign="top" width="16">
			<table border="0" cellspacing="0" cellpadding="0">
			<tr>
			{abas}
			</tr>
			<tr>
				<td class="aba_vertical_espaco">
					<img src="imagens/transparente.gif" width="1" height="1" vspace="0" hspace="0" />
				</td>
				<td class="aba_normal_2"></td>
			</tr>
			</table>
		</td>
		<td valign="top" height="100%">
			{conteudo}
		</td>
		</tr>
		</table></td></tr></table>';
		
		$cont_aba=$aba_total;
		$get=$_GET;
		$post=$_POST;
		
		$html['abas'] = array();
		for ($i=0;$i < count($parametros);$i++){
			if((isset($parametros[$i]['permissao']) && $eva['seguranca']->verificar_acesso($parametros[$i]['permissao'])) || !isset($parametros[$i]['permissao']) || $parametros[$i]['permissao'] === true){
				if(!empty($parametros[$i]['ajax'])){
					// esta eh uma variavel js para que a aba so seja carregada uma vez
					$lista_abas = "la_".((empty($_GET['m']))?"default":$_GET['m'])."_".((empty($_GET['c']))?"default":$_GET['c']).mktime();
					$eva['script'][] = "var ".$lista_abas." = new Array();";
				}
				// se estiver selecionado
				if((isset($aba_selecionada) and intval($aba_selecionada)==$cont_aba) or (!isset($aba_selecionada) and $parametros[$i]['selecionado'])){
					if(!empty($parametros[$i]['ajax'])){
						$eva['script'][] = "if(typeof(lista_abas) == 'undefined') {lista_abas = new Array();}";
						$eva['onload'][] = "setTimeout(\"carrega_aba('{$parametros[$i]['ajax']}&ob_start=0', 'abadiv_".$cookie_id.$cont_aba."', '{$lista_abas}')\", 200);";
					}
					$classe = "aba_{$sentido}_selecionada";
				}else{
					$classe = "aba_{$sentido}_normal";
				}
				$funcao = "mostrar";
				$url = 'index.php?modulo='.$_GET['modulo'].'&acao='.$get['acao'].'&subacao='.$get['subacao'].'&aba_num='.$cont_aba;
				
				$onclick = $funcao.'_aba(\''.$url.'\','.$cont_aba.','.$aba_total.','.($aba_total + count($parametros)).',\''.$sentido.'\',\''.$cookie_id.'\');';
				if(!empty($parametros[$i]['ajax'])){
					$onclick .= "carrega_aba('{$parametros[$i]['ajax']}&ob_start=0', 'abadiv_".$cookie_id.$cont_aba."', '{$lista_abas}');";
					$eva['script'][] = "var var_".$cookie_id.$cont_aba." = '';";
				}else{
					$eva['script'][] = "if(!lista_abas.length)lista_abas = new Array();";
				}
				// Correcao para problemas com o display:block
				/*
				if($this->selecionada == $cont_aba){
					$eva['onload'][] = $onclick;
				}*/
				
				$html['abas'][$cont_aba] = '<td id="td'.$cookie_id.$cont_aba.'" onClick="'.$onclick.'" onMouseOver="aba_sobre(this,\''.$sentido.'\',\'sobre\');" onMouseOut="aba_sobre(this,\''.$sentido.'\',\'normal\');" class="'.$classe.'">';
				if(!empty($parametros[$i]['img'])){
					$html['abas'][$cont_aba] .= '<img src="'.$parametros[$i]['img'].'" align="absmiddle" width="16" height="16" vspace="0" hspace="0" border="0" class="aba_imagem" />';
				}
				$html['abas'][$cont_aba] .= (!empty($parametros[$i]['nome']))? $parametros[$i]['nome'] : '';
				$html['abas'][$cont_aba] .= '</td><td id="td'.$cookie_id.$cont_aba.'_2" class="'.$classe.'_2"><img src="imagens/transparente.gif" width="5" height="5" vspace="0" hspace="0" /></td>';
				$cont_aba++;
			}
		}
		if($sentido == 'horizontal') $html['abas'][$cont_aba] = '<td class="aba_horizontal_espaco"><img src="imagens/transparente.gif" width="1" height="1" vspace="0" hspace="0" /></td>';
		
		$cont_aba=$aba_total;
		$html['conteudo'] = array();
		for ($i_aba=0;$i_aba < count($parametros);$i_aba++){
			// se tem htmlarea e � a aba selecionada ou nao tem htmlarea
			if((isset($parametros[$i]['permissao']) && $eva['seguranca']->verificar_acesso($parametros[$i]['permissao'])) || !isset($parametros[$i]['permissao']) || $parametros[$i]['permissao'] === true){
				$this->cod = $i_aba+$aba_total;
				if(isset($parametros[$i_aba]['include']) && count($parametros[$i_aba]['include']) > 0){
					while(list(,$valor) = each($parametros[$i_aba]['include'])){
						include($valor);
					}
				}
				$html['conteudo'][$cont_aba] = '<div id="aba'.$cookie_id.$cont_aba.'" style="'.(((isset($aba_selecionada) and intval($aba_selecionada)==($i_aba+$aba_total)) or (!isset($aba_selecionada) and $parametros[$i_aba]['selecionado']))? "" : "visibility: hidden; display:{display}").'" class="aba_'.$sentido.'_conteudo">';
				//Criando vari�vel para diferenciar os formu�rios e seus objetos (id)			
				$this->total = "__".($this->contador + $i_aba);
				//echo $html['conteudo'][$cont_aba].' - ';
				// Limpa as variaveis $_GET, $_POST, $_COOKIE para os modulos que nao estao sendo usados
				if(!((isset($aba_selecionada) and intval($aba_selecionada)==$cont_aba) or (!isset($aba_selecionada) and $parametros[$i_aba]['selecionado']))){
					$_GET =  array();
					$_POST = array();
					// Definir o modulo para que todos saibam em que modulo estao
					$_GET['modulo'] = $get['modulo'];
					// Definir o site para que todos saibam em que site vc esta
					$_GET['site'] = $get['site'];
					// Definir acao vazia (default)
					$_GET['acao'] = "";
					// Definir subacao vazia (default)
					$_GET['subacao'] = "";
				}
				
				// Inicia o armazenamento do conteudo em memoria
				ob_start();
				if(!empty($parametros[$i_aba]['php'])){
					eval($parametros[$i_aba]['php']);
				}
				if(!empty($parametros[$i_aba]['arquivo'])){
					@chdir($eva['caminho_eva']);
					include($parametros[$i_aba]['arquivo']);
				}
				if(!empty($parametros[$i_aba]['conteudo'])){
					echo $parametros[$i_aba]['conteudo'];
				}
				if(!empty($parametros[$i_aba]['ajax'])){
					echo "<div id='abadiv_".$cookie_id.$cont_aba."'><div class=\"carregando\"></div></div>";
				}
		
				
				$html['conteudo'][$cont_aba] .= ob_get_contents().'</div>';
				
				// Corrigindo camadas para editor
				$display = 'none';				
				if(eregi('eva_editor',$html['conteudo'][$cont_aba])){
					$display = '';
				}
				$html['conteudo'][$cont_aba] = str_replace('{display}',$display,$html['conteudo'][$cont_aba]);
				// Limpa saida
				ob_end_clean();
				
				// Recra as variaveis GET e POST
				$_GET=$get;
				$_POST=$post;
				
				$cont_aba++;
			}
		}
		
		$implode = ($sentido == 'horizontal')? '' : '</tr><tr>';
		//var_dump($implode);var_dump($html['abas']);var_dump($sentido);
		$html[$sentido] = str_replace('{total}',((count($html['conteudo'])*2)+1),$html[$sentido]);
		$html[$sentido] = str_replace('{abas}',implode($implode,$html['abas']),$html[$sentido]);
		$html[$sentido] = str_replace('{conteudo}',implode('',$html['conteudo']),$html[$sentido]);
		
		$parametros = array();	
		$aba_total -= $aba_confere;	
		$this->total = "__".($this->contador + $cont_aba + 1);
		
		if($retornar)
			return $html[$sentido];
		else
			echo $html[$sentido];
	} //criar_abas
} //eva_aba
?>