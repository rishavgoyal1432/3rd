<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
 
$eva['incluir']->incluir_modulo("eva_menu");

class eva_form {

    /**
     * Contador com o total de editores HTML
     *
     * @var string
     */
    var $editor;
	
	 /**
     * Contador com o total de fields para completar
     *
     * @var string
     */
    var $autocompletar;

    /**
     * Variavel que armazena o formulario gerado
     *
     * @var string
     */
    var $form;

    /**
     * Lista de campos do furmulario
     *
     * @var array
     */
    var $campo;

    /**
     * Lista de opcoes avancadas do furmulario
     *
     * @var array
     */
    var $avancado;

    /**
     * Menu do formulario - opcional, substitui o padrao
     *
     * @var array
     */
    var $menu;

    /**
     * Define o sentido vertical ou horizontal
     *
     * @var string
     */
    var $sentido;

    /**
     * Define o codigo da aba atual
     *
     * @var string
     */
    var $aba;

    /**
     * Define o numero de formularios existentes e o numero do atual
     *
     * @var int
     */
    var $total;

    /**
     * Method - GET ou POST
     *
     * @var string
     */
    var $metodo;

    /**
     * Target - _blank, _self, _parent, _top
     *
     * @var string
     */
    var $destino;

    /**
     * Class - modulo, bloco
     *
     * @var string
     */
    var $classe;

    /**
     * Style, onsubmit...
     *
     * @var string
     */
    var $extra;

    /**
     * Rodape do formulario
     *
     * @var string
     */
    var $cabecalho;

    /**
     * Cabecalho do fomrulario
     *
     * @var string
     */
    var $rodape;
	
	/**
     * Campos Multiplos
     *
     * @var string
     */
    var $multiplo;
	
	/**
     * Quantidade de colunas
     *
     * @var int
     */
    var $colunas;
	
	/**
     * Quantidade maxima de colunas
     *
     * @var int
     */
    var $max_colunas;	

    /**
     * Construct function
     *
     * @return void
     */
	function eva_form() {
		
	}//eva_form

    /**
     * Cria novo formularioInicia variaveis de configuracao
     *
     * @access public
     * @param string $action URL para submiss�o do formul�rio
     * @param string $titulo Titulo do formulario
     * @param string $botao Titulo do botao (Salvar/Enviar)
     * @param int $menu_tipo Tipo de menu (0 = menu em cima e embaixo; 1 = embaixo; 2=em cima; 3=sem menu; 4=sem form)
     * @return void
     */
    function config($action = "",$titulo="",$id="",$botao = "",$menu_tipo = 0){
		global $eva;
		global $idioma;
		// Limpando a variavel de formulario - criando novo
		$this->form = "";
		$this->aba = empty($eva['aba']->total)?0:$eva['aba']->total;		
		$this->editor = (isset($this->editor))? $this->editor++ : 0;
		$this->menu = array();
		$this->campo = array();
		$this->action = $action;
		$this->menu_tipo = $menu_tipo; // 0 = menu em cima e embaixo; 1 = embaixo; 2=em cima; 3=sem menu; 4=sem form
		$this->classe = "";
		$this->metodo = "post";
		$this->destino = "_self";
		$this->cabecalho = "";
		$this->rodape = "";
		$this->titulo = (isset($titulo) && trim($titulo) != "")? $titulo : "";
		$this->botao = (isset($botao) && trim($botao) != "")? $botao : $idioma['salvar'];
		$this->total = (isset($this->total))? ($this->total + 1) : 1;
		$this->id  = (!empty($id))? $id : "form_".$_GET['modulo'].$this->total."_".(empty($eva['aba']->total)?0:$eva['aba']->total);
		$this->max_colunas = $this->colunas = 1;
    }//config

    /**
     * Destrutor da classe, limpa as variaveis exceto as de contagem
     *
     * @access public
     * @return void
     */
    function destroy(){		
		// Limpando a variavel de formulario - criando novo
		$this->form = "";
		$this->aba = "";
		$this->menu = array();
		$this->campo = array();
		$this->avancado = array();
		$this->action = "";
		$this->extra = "";
		$this->menu_tipo = "";
		$this->classe = "";
		$this->metodo = "";
		$this->destino = "";
		$this->cabecalho = "";
		$this->rodape = "";
		$this->titulo = "";
		$this->botao = "";
		$this->id  = "";
    }//config

    /**
     * Gera menu de botoes defunido pelo usuario
     *
     * @access public
     * @param string $menu Menu definido pelo usuario
     * @return void
     */
    function menu(&$menu){
		global $eva;
		$menu['form_id'] = (isset($menu['form_id']) && trim($menu['form_id']) != "")? $menu['form_id'] : $this->id;
		$menu['campo'] = isset($this->menu['campo'])? $this->menu['campo'] : array();
		$menu['alerta'] = isset($this->menu['alerta'])? $this->menu['alerta'] : array();
		$menu['formato'] = isset($this->menu['formato'])? $this->menu['formato'] : array();
		$this->menu = $menu;
		$menu = array();
    }//menu

    /**
     * Conta os itens do menu
     *
     * @access public
     * @return int
     */
    function contar_menu(){
		$total = 0;
		while(list($indice,$valor) = each($this->menu)){
			if(is_numeric($indice)) $total++;
		}
		return $total;
    }//contar_menu

    /**
     * Script para autocompletar campos
     *
     * @access public
     * @param string $campo Campo a ser completado
     * @param string $comando Comando com os dados
     * @return void
     */
    function autocompletar($nome, $comando, $valor="", $auto=1){
		global $eva;
		global $config;		
		$this->autocompletar[]=$nome;
		if(!empty($this->campo[$nome]['valor'])){
			$sql = "SELECT us_nomecom
				FROM 
					".$config['bdprefixo']."_eva_usuario
				WHERE
					us_cod = ".intval($this->campo[$nome]['valor']);
			$rs = $eva['sql']->executar($sql);
			$linha = $rs->FetchRow();
		}else{
			$linha['US_NOMECOM']="";
		}
		$eva['onload'][] = "setTimeout(autocompleteAutoAttach, 3000);";
		$this->campo[$nome]['id'].="_eva_";
		$this->campo[$nome]['extra'] .= " autocomplete=\"off\" auto=\"{$auto}\" ";
		$this->campo[$nome]['html'] .= " <input class=\"autocomplete\" id=\"".$this->campo[$nome]['id']."-autocomplete\" value=\"".$comando."&comando_tipo=js\" disabled=\"disabled\" type=\"hidden\">
										<input id=\"".$this->campo[$nome]['id']."_oculto\" name=\"".$this->campo[$nome]['nome']."\" value=\"".$valor."\" type=\"hidden\"> ";
		$this->campo[$nome]['classe'] = " form-autocomplete ";
		$this->campo[$nome]['nome'] = $this->campo[$nome]['nome']."_exibir";
		//$this->campo[$nome]['valor'] = $linha['US_NOMECOM'];
		$tag = "<!-- eva_autocompletar -->";
		if(isset($_GET['comando_tipo']) && $_GET['comando_tipo'] == "xml"){
			$xml = $eva['xml']->criar_elemento("tag_extra", $tag);
			$eva['xml']->colocar_no_root($xml);
		}else
			echo $tag;
    }//menu
	
    /**
     * Adiciona os campos do formulario
     *
     * @access public
     * @param string $nome Atributo name
     * @param string $titulo Titulo para descri��o
     * @param string $tipo Atributo type
     * @param string $valor Atributo valor, ou item selecionado, ou lista de selecionados
     * @param string $opcoes Atributo maxlenght, vetor de opcoes, ou rows
     * @param string $alerta Mensagem para validacao
     * @param string $formato Formato para validacao
     * @param string $html Conteudo fora do campo. Pode conter o proprio campo
     * @param string $extra Tags adicionais e scripts
     * @return void
     */
    function campo($nome,$titulo="",$tipo = "text", $valor = "", $opcoes = "", $alerta = "",$formato = "",$html = "",$extra="", $avancado = false){
		global $eva, $idioma;
		
		// Caso o cmpo n�o tenha nome
		if(trim($nome) == "") return;
		if(!isset($this->id) || (isset($this->id) && $this->id == ""))  $this->config();
		
		$campo = array();
		$campo['nome'] = $nome;
		$campo['titulo'] = $titulo;
		$campo['tipo'] = $tipo;
		$nome = (substr($nome, -2) == '[]')? substr($nome,0, -2) : $nome;
		$campo['id'] = $nome.(empty($eva['aba']->total)?0:$eva['aba']->total);
		$campo['valor'] = $valor;
		$campo['extra'] = $extra;
		$campo['html'] = $html;
		$campo['opcoes'] = $opcoes;
		$campo['classe'] = "";
		$campo['avancado'] = $avancado;

		$this->campo[$nome] = $campo;
		if($avancado===true) $this->avancado[$campo['id']] = $nome;
		
		if($alerta != "" || $formato != "" || $tipo=="validador" || $alerta===true){
			$this->campo[$nome]['titulo']="*".$this->campo[$nome]['titulo'];
			$this->menu['campo'][] = $nome.(isset($eva['aba']->total)?$eva['aba']->total:"");
			$this->menu['alerta'][] = (!empty($alerta) && !($alerta===true))? $alerta : $idioma['validar_campo']." ".$campo['titulo'];
			$this->menu['formato'][] = (!empty($formato))? $formato : "nao_nulo";
		}
		
		return $campo['id'];
    }//campo

    /**
     * Monta um campo do formulario
     *
     * @access public
     * @param string $nome Nome do campo
     * @return string HTML do campo
     */
    function montar_campo($nome,$mostrar = true, $apagar=true, $alinhamento="esquerda"){
		global $eva;
        global $idioma;
		$campos = "";
		//var_dump($this->campo[$nome]['titulo']."<br>");
		//var_dump($mostrar);echo "<hr>";
		if($mostrar && $this->campo[$nome]['titulo'] != "" && $this->campo[$nome]['titulo'] != "*"){
			$campos = "<label for=\"".$this->campo[$nome]['id']."\">".$this->campo[$nome]['titulo'].":</label>";
		}
		$this->campo[$nome]['valor']=(isset($this->campo[$nome]['valor']))?$this->campo[$nome]['valor']:"";
		switch($this->campo[$nome]['tipo']){
			case "star":
				$eva['head_css'][] = "				
				.star1{}							
				.star2{filter:alpha(opacity=60);-moz-opacity:.60;opacity:.60;}
				.star3{filter:alpha(opacity=25);-moz-opacity:.25;opacity:.25;}	
				";
				$eva['script'][] = "
				function star_mover(t){
					t.style.cursor=eva_mouseover;					
					total = t.getAttribute('pos');
					name = t.getAttribute('nm');					
					input = eva_elem(name);	
					to = input.getAttribute('to');
					try{clearTimeout(to);}catch(e){}
					t = eva_elem(name).getAttribute('t');
					for(i=1;i<=t;i++){
						t2 = eva_elem(name+i);
						if(i<=eva_elem(name).value)
							eval('t2.className=\"star2\"');
						else
							eval('t2.className=\"star3\"');					
					}
					for(i=1;i<=total;i++){
						t2 = eva_elem(name+i);
						if(i<=eva_elem(name).value)
							eval('t2.className=\"star1\"');
						else
							eval('t2.className=\"star2\"');
					}
				}
				function star_mout(t){
					name = t.getAttribute('nm');
					input = eva_elem(name);
					to = input.getAttribute('to');
					try{clearTimeout(to);}catch(e){}
					imgt = setTimeout('_star_mout(eva_elem(\"'+t.id+'\"))', 100);
					input.setAttribute('to', imgt);
				}
				function _star_mout(t){
					total = t.getAttribute('pos');
					name = t.getAttribute('nm');
					input = eva_elem(name);	
					t = input.getAttribute('t');
					for(i=1;i<=t;i++){
						t2 = eva_elem(name+i);
						if(i<=input.value)
							eval('t2.className=\"star1\"');
						else
							eval('t2.className=\"star3\"');					
					}
				}
				function star_onclick(t){
					total = t.getAttribute('pos');
					name = t.getAttribute('nm');
					input = eva_elem(name);	
					t = input.getAttribute('t');				
					input.value=total;
					for(i=1;i<=t;i++){
						t2 = eva_elem(name+i);
						if(i<=total)
							eval('t2.className=\"star1\"');
						else
							eval('t2.className=\"star3\"');					
					}
				}
				";
				$total = 0;
				$campos .= "<img id=\"_eva_{$this->campo[$nome]['id']}0\" pos=\"0\" nm=\"_eva_{$this->campo[$nome]['id']}\" class=\"star1\" src=\"{$eva['url_eva']}imagens/16x16/actions/locationbar_erase.png\" hspace=\"1\" onmouseover=\"star_mover(this);\" onmouseout=\"star_mout(this);\" onclick=\"star_onclick(this);\" onload=\"var_to(this);\" />";
				// total of stars = $this->campo[$nome]['opcoes']
				for($i=1; $i<=$this->campo[$nome]['opcoes']['total']; $i++){
					if(empty($this->campo[$nome]['opcoes']['img'])){
						$img = $eva['url_eva']."imagens/16x16/actions/bookmark.png";
					}else{
						$img = (!eregi("^arquivos\/", $this->campo[$nome]['opcoes']['img'])?$eva['url_eva']:"").$this->campo[$nome]['opcoes']['img']; 
					}
					$campos .= "<img id=\"_eva_{$this->campo[$nome]['id']}{$i}\" pos=\"{$i}\" nm=\"_eva_{$this->campo[$nome]['id']}\" class=\"".($i>$this->campo[$nome]['valor']?"star3":"star1")."\" src=\"{$img}\" hspace=\"1\" onmouseover=\"star_mover(this);\" onmouseout=\"star_mout(this);\" onclick=\"star_onclick(this);\" />";
					$total++;
				}
				$campos .= "<input name=\"{$this->campo[$nome]['nome']}\" to=\"\" type=\"hidden\" id=\"_eva_{$this->campo[$nome]['id']}\" value=\"{$this->campo[$nome]['valor']}\" {$this->campo[$nome]['extra']} t=\"{$total}\" />";
			break;
			case "text":
				if(intval($this->campo[$nome]['opcoes'])<=0) $this->campo[$nome]['opcoes'] ="";
				$campos .= "<input name=\"".$this->campo[$nome]['nome']."\" type=\"".$this->campo[$nome]['tipo']."\" class=\"input_text".$this->campo[$nome]['classe']."\" id=\"".$this->campo[$nome]['id']."\" value=\"".$this->campo[$nome]['valor']."\" ".(!empty($this->campo[$nome]['opcoes'])?"maxlength=\"".$this->campo[$nome]['opcoes']."\"":"")." ".$this->campo[$nome]['extra']." />".$this->campo[$nome]['html'];
			break;
			default:
			case "file":
				if(intval($this->campo[$nome]['opcoes'])<=0) $this->campo[$nome]['opcoes'] ="";
				$enctype = "multipart/form-data";
				$campos .= "<input name=\"".$this->campo[$nome]['nome']."[]\" type=\"".$this->campo[$nome]['tipo']."\" class=\"input_text\" id=\"".$this->campo[$nome]['id']."\" value=\"".$this->campo[$nome]['valor']."\" ".(!empty($this->campo[$nome]['opcoes'])?"maxlength=\"".$this->campo[$nome]['opcoes']."\"":"")." ".$this->campo[$nome]['extra']." />"."Max ".ini_get('upload_max_filesize').$this->campo[$nome]['html'];
			break;
			case "password":
				if(intval($this->campo[$nome]['opcoes'])<=0) $this->campo[$nome]['opcoes'] ="";
				$campos .= "<input name=\"".$this->campo[$nome]['nome']."\" type=\"".$this->campo[$nome]['tipo']."\" class=\"input_text\" id=\"".$this->campo[$nome]['id']."\" value=\"".$this->campo[$nome]['valor']."\" ".(!empty($this->campo[$nome]['opcoes'])?"maxlength=\"".$this->campo[$nome]['opcoes']."\"":"")." ".$this->campo[$nome]['extra']." />".$this->campo[$nome]['html'];
			break;
			case "code": // testando ainda
				$eva['onload'][]="new RTSH();RTSH.initialize();";
				$eva['head'][] = "<script type=\"text/javascript\" src=\"{$eva['url_eva']}biblioteca/javascripts/rsth.js\"></script>\n";
				$campos .= '<div style="border:thin #666666 solid; width:95%; height:400px; overflow:auto; background:white; font-family:monospace; font-size:13px; white-space:pre; padding:6px; " id="edt" contenteditable="true" onblur="eva_elem('.$this->campo[$nome]['id'].').value=this.innerHTML"><PRE>'.$this->campo[$nome]['valor'].'</PRE></div>';
				$this->campo[$nome]['tipo'] = "hidden";
			case "hidden":
				$campos .= "<input name=\"".$this->campo[$nome]['nome']."\" type=\"".$this->campo[$nome]['tipo']."\" id=\"".$this->campo[$nome]['id']."\" value=\"".$this->campo[$nome]['valor']."\" ".$this->campo[$nome]['extra']." />";
			break;
			case "radio":
				if(!(is_array($this->campo[$nome]['opcoes']) && count($this->campo[$nome]['opcoes']) > 0)) continue;
				$onclick = $d = "";
				$selec = $x = 0;
				while(list($valor,$desc) = each($this->campo[$nome]['opcoes'])){
					$x++;					
					$result = $this->mostrar_select_div($desc, $this->aba, $this->campo[$nome]['nome'], $valor,$selec);
					if(is_array($result)){
						$d = !empty($result['d'])?$result['d']:$d;
						$desc = $result['nome'];
					}		
						
					if($valor == $this->campo[$nome]['valor']){
						$checked = "checked";
						// adiciona no onload a func para carregar os itens da vez
						if(!empty($d))
							$eva['onload'][] = "mostrar_select_div('{$this->campo[$nome]['valor']}', '{$this->aba}', '{$this->campo[$nome]['nome']}');";
					}else{
						$checked = "";
					}					
					if($selec) $onclick = " onclick=\"mostrar_select_div(this.value, '{$this->aba}', this.name)\" ";
					if($alinhamento=="esquerda"){
						$campos .= "<div><input name=\"".$this->campo[$nome]['nome']."\" type=\"".$this->campo[$nome]['tipo']."\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." {$onclick} /><label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label></div>";
					}else{
						$campos .= "<div style='text-align:right'><label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label><input name=\"".$this->campo[$nome]['nome']."\" type=\"".$this->campo[$nome]['tipo']."\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." {$onclick} /></div>";
					}
				}							
				$campos .= "".$d.$this->campo[$nome]['html'];
			break;
			case "radio_horizontal":				
				if(!(is_array($this->campo[$nome]['opcoes']) && count($this->campo[$nome]['opcoes']) > 0)) continue;
				$onclick = $d = "";
				$selec = $x = 0;
				while(list($valor,$desc) = each($this->campo[$nome]['opcoes'])){
					$x++;
					$result = $this->mostrar_select_div($desc, $this->aba, $this->campo[$nome]['nome'], $valor,$selec);
					if(is_array($result)){
						$d = !empty($result['d'])?$result['d']:$d;
						$desc = $result['nome'];
					}
					
					if($valor == $this->campo[$nome]['valor']){
						$checked = "checked";
						// adiciona no onload a func para carregar os itens da vez
						if(!empty($d))
							$eva['onload'][] = "mostrar_select_div('{$this->campo[$nome]['valor']}', '{$this->aba}', '{$this->campo[$nome]['nome']}');";
					}else{
						$checked = "";
					}					
					if($selec) $onclick = " onclick=\"mostrar_select_div(this.value, '{$this->aba}', this.name)\" ";
					$campos .= "<input name=\"".$this->campo[$nome]['nome']."\" type=\"radio\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." {$onclick} />
					<label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label>&nbsp;&nbsp;";
				}							
				$campos .= "".$d.$this->campo[$nome]['html'];
			break;
			case "checkbox":
				if(!(is_array($this->campo[$nome]['opcoes']) && count($this->campo[$nome]['opcoes']) > 0)) continue;
				$x = 0;
				if(!empty($this->campo[$nome]['titulo']) && count($this->campo[$nome]['opcoes'])>1)
					$campos .= "<hr size=\"1\" noshade>";
				while(list($valor,$desc) = each($this->campo[$nome]['opcoes'])){
					$x++;
					$checked = (is_array($this->campo[$nome]['valor']) && in_array($valor,$this->campo[$nome]['valor']))? "checked": "";
					//var_dump($this->campo[$nome]['valor']);
					if($alinhamento=="esquerda"){
						$campos .= "<div><input name=\"".$this->campo[$nome]['nome']."[]\" type=\"".$this->campo[$nome]['tipo']."\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." /> <label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label></div>";
					}else{
						$campos .= "<div style='text-align:right'><label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label><input name=\"".$this->campo[$nome]['nome']."[]\" type=\"".$this->campo[$nome]['tipo']."\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." /> </div>";
					}
				}
				if(!eregi("onchange",$this->campo[$nome]['extra']) && $x > 3){
					// if there is a onchange here, get it, to concat more actions
					$onchange = "selecionar_todos(this,'".$this->campo[$nome]['id']."',".$x.");";
					if(eregi("^onchange", $this->campo[$nome]['extra'])){
						$pattern='/onchange=(\\\'|\"|\\\")(.*)\1/Ui';
						preg_match_all($pattern,$this->campo[$nome]['extra'],$oc);
						//var_dump($oc[2][0]);						
						$onchange .= str_replace('"', "'", $oc[2][0]);
					}
					//if(!empty($this->campo[$nome]['titulo']))
						$campos .= "<hr size=\"1\" noshade>";					
					$campos .= "<input id=\"selecionar_".$this->campo[$nome]['id']."\" type=\"checkbox\" onChange=\"{$onchange}\"><label for=\"selecionar_".$this->campo[$nome]['id']."\" class=\"selecao\">".$idioma['selecionar_todos']."</label>";
				}
				$campos .= "".$this->campo[$nome]['html'];
			break;
			case "checkbox_horizontal":
				if(!(is_array($this->campo[$nome]['opcoes']) && count($this->campo[$nome]['opcoes']) > 0)) continue;
				$x = 0;
				while(list($valor,$desc) = each($this->campo[$nome]['opcoes'])){
					$x++;
					//echo "<hr>".$valor."<br>";var_dump($this->campo[$nome]['valor']);
					$checked = (is_array($this->campo[$nome]['valor']) && in_array($valor,$this->campo[$nome]['valor']))? "checked": "";
					//var_dump($this->campo[$nome]['valor']);
					$campos .= "<input name=\"".$this->campo[$nome]['nome']."[]\" type=\"checkbox\" id=\"".$this->campo[$nome]['id'].$x."\" value=\"".$valor."\" ".$checked." ".$this->campo[$nome]['extra']." /> <label for=\"".$this->campo[$nome]['id'].$x."\" class=\"selecao\">".$desc."</label>&nbsp;&nbsp;";
				}
				$campos .= "".$this->campo[$nome]['html'];
			break;
			case "select":
				if(!(is_array($this->campo[$nome]['opcoes']) && count($this->campo[$nome]['opcoes']) > 0)) continue;
				$s = $onchange = $d = "";
				$selec = 0;
				while(list($valor,$desc) = each($this->campo[$nome]['opcoes'])){
					$disabled = '';
					if($valor === 'disabled'){
						$valor = '';
						$disabled = 'disabled';
					}					
					$result = $this->mostrar_select_div($desc, $this->aba, $this->campo[$nome]['nome'], $valor,$selec);
					if(is_array($result)){
						$d = !empty($result['d'])?$result['d']:$d;
						$desc = $result['nome'];
					}
						
					if($valor == $this->campo[$nome]['valor']){
						$selected = "selected";
						// adiciona no onload a func para carregar os itens da vez
						if(!empty($d))
							$eva['onload'][] = "mostrar_select_div('{$this->campo[$nome]['valor']}', '{$this->aba}', '{$this->campo[$nome]['nome']}');";
					}else{
						$selected = "";
					}
					$selected = ($valor == $this->campo[$nome]['valor'])? "selected": "";
					$s .= "<option value=\"".$valor."\" ".$selected." ".$disabled.">".$desc."</option>";
				}
				$list = array();
				if(is_array($this->campo[$nome]['extra'])){
					$list = $this->campo[$nome]['extra'];
					$this->campo[$nome]['extra'] .= ' size="'.$list['size'].'" ';
					if(!empty($list['multiple']) && $list['multiple']){
						$this->campo[$nome]['extra'] .= ' multiple="multiple" ';
						$this->campo[$nome]['html'] = "<br><a href=\"#\" onclick=\"selectAll('{$this->campo[$nome]['id']}')\" >{$idioma['selecionar_desmarcar_todos']}</a>".$this->campo[$nome]['html'];		
					}			
					$this->campo[$nome]['nome'] = $this->campo[$nome]['nome']."[]";
				}
				if($selec) $onchange = " onchange=\"mostrar_select_div(this.value, '{$this->aba}', this.name)\" "	;				
				$s .= "</select>".$this->campo[$nome]['html'].$d;
				
				$campos .= "<select class=\"form\" name=\"".$this->campo[$nome]['nome']."\" id=\"".$this->campo[$nome]['id']."\" ".$this->campo[$nome]['extra']." {$onchange} >
				".$s;
			break;
			case "editor":				
				$this->campo[$nome]['classe'] = 'mceEditor';
				$this->campo[$nome]['html'] .= '<!-- TinyMCE -->';
				// use $eva['tinemce'] para opcoes 0=advanced 1=simple
 			case "textarea":
				$campos .= "<textarea name=\"".$this->campo[$nome]['nome']."\" class=\"input_text".$this->campo[$nome]['classe']."\" id=\"".$this->campo[$nome]['id']."\" wrap=\"virtual\" rows=\"".$this->campo[$nome]['opcoes']."\" ".$this->campo[$nome]['extra']." onKeyPress=\"javascript: if(enter(event)) eva_enter = true;\" style=\"width:100%\">".$this->campo[$nome]['valor']."</textarea>".$this->campo[$nome]['html'];				
			break;
			case "data":
				$this->campo[$nome]['opcoes'] = (trim($this->campo[$nome]['opcoes']) != "")? $this->campo[$nome]['opcoes'] : str_replace(":s", "", $idioma['formato_data_e_seg_mktime']);
				$padrao = "/([^\/\s\:])/i";
				$this->campo[$nome]['formato'] = "^".preg_replace("/[d|m|Y|H|:]/i", '([0-9]{2})', str_replace("i","M",$this->campo[$nome]['opcoes']))."\$";
				$formato_js =  preg_replace($padrao, '%\1', str_replace("i","M",$this->campo[$nome]['opcoes']));
				$this->campo[$nome]['valor'] = (trim($this->campo[$nome]['valor']) != "" && intval($this->campo[$nome]['valor']) > 0)? date($this->campo[$nome]['opcoes'], $this->campo[$nome]['valor']) : "";
				$campos .= "<!-- Calendar.setup --><table id=\"bt_".$this->campo[$nome]['id']."\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td><input name=\"".$nome."\" type=\"text\" class=\"input_text\" id=\"".$this->campo[$nome]['id']."\" value=\"".$this->campo[$nome]['valor']."\" style=\"width: 120;\" ".$this->campo[$nome]['extra']." readonly=\"1\" />";
				/* removi pois nao havia necessidade
				$menu[0]['onclick'] = "eva_elem('".$this->campo[$nome]['id']."').value='';";				
				$menu[0]['img'] = "imagens/16x16/apps/date.png";				
				$menu['fundo'] = false;
				$menu['largura'] = false;
				$campos .= "</td><td>".$eva['modulo_eva_menu']->criar_menu($menu)."</td></tr></table>";	
				*/	
				$campos .= "</td><td><img src=\"imagens/16x16/apps/date.png\"  hspace=\"5\" ></td></tr></table>";	
				$campos .= $this->campo[$nome]['html'];
				$eva['onload'][] = "setTimeout(\"Calendar.setup({inputField: '".$this->campo[$nome]['id']."',ifFormat: '".$formato_js."',showsTime: true,singleClick: true,button: 'bt_".$this->campo[$nome]['id']."',step: 1});\", 2000);";
			break;
			case "cor":
				$eva['incluir']->incluir("geral");	
				$campos .= $eva['geral']->selecionar_cor($this->campo[$nome]['valor'], $this->campo[$nome]['nome'],$this->campo[$nome]['id']);
				//$campos .= "<input name=\"{$this->campo[$nome]['nome']}_antiga\" type=\"hidden\" id=\"{$this->campo[$nome]['id']}_antiga\" value=\"".$this->campo[$nome]['valor']."\" ".$this->campo[$nome]['extra']." />";
			break;
			case "validador":
			// use $eva['validar']->validar_validador('nome_campo') retorna verdade se o validador estiver correto
				$eva['incluir']->incluir("validar");
				$menu[0]['onclick'] = "alt_img_{$nome}();";
				$menu[0]['img'] = "imagens/16x16/apps/sodipodi.png";
				$menu[0]['alt'] = $idioma['recarregar_imagem_validacao'];
				$menu['alt']="camada";
				$menu['fundo'] = false;
				$menu['largura'] = false;
				$campos .= "
				<table border=\"0\" cellspacing=\"2\" cellpadding=\"0\" >
				  <tr>
					<td><img id=\"img_{$nome}\"></td>
					<td><input name=\"".$this->campo[$nome]['nome']."\" type=\"text\" size=\"4\" maxlength=\"4\" id=\"".$this->campo[$nome]['id']."\"></td>
					<td>".$eva['modulo_eva_menu']->criar_menu($menu)."</td>
				  </tr>
				</table>";
				$eva['onload'][] = "			
				alt_img_{$nome}();
				";
				$eva['script'][] = "				
				var img_cont=0;	
				function alt_img_{$nome}(){
					img=eva_elem('img_{$nome}');
					img.src='index.php?comando=true&comando_tipo=validar_img&size=4&nada='+(img_cont++)+'&item={$nome}';
				};
				";
			break;
			case "dados":
				if($alinhamento=="esquerda"){
					$campos .= $this->campo[$nome]['valor'];
				}else{
					$campos .= "<div style='text-align:right'>{$this->campo[$nome]['valor']}</div>";
				}
			break;
			default:
				if($this->sentido == "v"){
					$campos .= "</td></tr><tr><td colspan=\"2\">";
				}
				$campos .= $this->campo[$nome]['valor'];
			break;
		}
		if($mostrar && $apagar){
			$this->campo[$nome] = array();
			unset($this->campo[$nome]);
		}
		if(isset($this->campo[$nome]) && is_array($this->campo[$nome]['opcoes']))
			reset($this->campo[$nome]['opcoes']);
		//echo $campos."<hr>";
		return $campos;
    }//montar_campo

	/**
	 * Uso Interno da classe para fazer a depender de um select quas os camos de um formulario o usuario dever� preencher
	 *
	 * @param array $desc_d
	 * @param string $aba
	 * @param string $nome_d
	 * @param string $valor_d
	 * @param string $selec
	 * @return string
	 */
	function mostrar_select_div($desc_d, $aba, $nome_d, $valor_d, &$selec){
		global $eva;
		if(is_array($desc_d)){
			//coloque aspas simples em cada item
			for($i=0;$i<count($desc_d['campos']);$i++){
				$desc_d['campos'][$i] = "'{$desc_d['campos'][$i]}'"; 
			}
			if(!$selec){
				$eva['script'][] = "
				function mostrar_select_div(valor, aba_valor, nome){
					vet = lista_valor_selec['_'+nome+'_{$aba}'];
					if (!vet) return;
					for(i=0; i<vet.length;i++){
						id='select_div'+vet[i]+'_'+aba_valor;
						elem = eva_elem(id);
						if(!elem)continue;
						elem.style.height = '1px';
						elem.style.witdh = '1px';
						elem.style.display = 'none';
						elem.style.visibility = 'hidden';
					};
					vet = select_valores[valor+'_{$aba}'];
					if (!vet) return;
					for(i=0; i<vet.length;i++){
						id='select_div'+vet[i]+'_'+aba_valor;
						elem = eva_elem(id);
						if(!elem)continue;
						elem.style.visibility = 'visible';
						elem.style.height = '';
						elem.style.width = '';
						elem.style.display = 'block';
					};
				};";
				$eva['script'][] = "
				if(!select_valores)
					var select_valores = new Array();";	
				$r['d'] = "{_".$nome_d."}";
			}
			$selec = 1;
			$eva['script'][] = "select_valores['{$valor_d}_{$aba}'] = new Array(".implode(",", $desc_d['campos']).");";
			$r['nome'] = $desc_d['nome'];
			return $r;
		}else{
			return $desc_d;
		}
	}

    /**
     * Cria o fromulario
     *
     * @access public
     * @param string $exibir_campo Campo que se deseja exibir - nao monta o formulario
     * @param string $sentido Vertical ou horizontal
     * @return string HTML contendo o formulario para exibicao
     */
    function criar($exibir_campo = "", $sentido = "v", $posicao = "h", $limpar = true, $alinhamento="esquerda", $form = true, $table_width = "100%"){
        global $eva;
        global $idioma;
		// Definindo sentido
		if(empty($this->id))
			$this->config();
		$this->sentido = $sentido;
		// Criando menu de botoes
		$this->menu['form_id'] = $this->id;
		$this->menu[0]['alt'] = (!empty($this->menu[0]['alt']))? $this->menu[0]['alt'] : $this->botao;
		$this->menu[0]['action'] = (!empty($this->menu[0]['action']))? $this->menu[0]['action'] : '';
		$this->menu[0]['action'] = (empty($this->menu[0]['action']) && empty($this->menu[0]['url']))? $this->action : $this->menu[0]['action'];
		$this->menu[0]['img'] = (!empty($this->menu[0]['img']))? $this->menu[0]['img'] : "imagens/16x16/actions/filesave.png";
		
		// Adicionando campos
		$_campos = '';
		$_avancados = '';
		$campos_ocultos = "";
		$enctype = "multipart/form-data";
		$cont = 0;
		$count_itens = 0;
		while(list($nome) = each($this->campo)){
			if(eregi("^set_col [0-9]+ [0-9]$", $nome)){
				// cada vez que iniciar um novo set de colunas complete as colunas que faltam
				if($count_itens%$this->colunas!=0){ 
					$$tipo .= "<td colspan='".(($this->colunas-$count_itens%$this->colunas)*2)."' >&nbsp;</td>";
				}
				$count_itens = 0;				
				$this->colunas = intval(substr($nome, -1));
				$colspan = $this->max_colunas/$this->colunas;				
				continue;
			}else if($count_itens==0){		
				$colspan = $this->max_colunas/$this->colunas;
			}
			//echo "<b> $nome </b><br>colspan: {$colspan}<br>maxcol: $this->max_colunas <br>colunas: $this->colunas <hr>";
			
			$tipo = (isset($this->campo[$nome]['avancado']) && $this->campo[$nome]['avancado']===true)? '_avancados' : ((isset($this->campo[$nome]['avancado']) && $this->campo[$nome]['avancado']!==false)?("_".$this->campo[$nome]['avancado']):'_campos');
			
			//echo " $count_itens % $this->colunas == 0 : ".($count_itens%$this->colunas==0)." <br>";
			if($sentido == "v" && $count_itens%$this->colunas==0 && $cont>0){
				@$$tipo .= "</tr><tr>";				
			}
			// no final de tudo complete com td vazio
			else if($cont >= count($this->campo)){
				$$tipo .= "<td colspan='".(($this->colunas-$count_itens%$this->colunas)*2)."' >&nbsp;</td>";
			}
			
			//echo $tipo."<hr>";
			if(!isset($$tipo))$$tipo = "";
			if(!isset($this->campo[$nome]['tipo'])) continue;
			if($this->campo[$nome]['tipo'] == "hidden"){
				$campos_ocultos .= $this->montar_campo($nome,false, true, $alinhamento);
				continue;
			}
			if($this->campo[$nome]['tipo'] == "quebra"){
				$$tipo .= ($sentido == "v")? "</table><table class=\"formulario\" width=\"100%\" >" : "</tr></table><table class=\"formulario\" width=\"100%\"><tr>";
				continue;
			}
			if($tipo != "_avancados" && $tipo!= "_campos"){
				//$val = $this->campo[$nome]['nome'];
				$val = $nome;
				//border-color:#006666; border-style:solid; border-width:thin;
				$select_opt[$tipo][] = "<div id=\"select_div{$nome}_{$this->aba}\" style=\"visibility:hidden; height: 1px; display: none;\"><table width=\"100%\"><tr><td width=\"80\" style=\"text-align:right;\">".(($this->campo[$nome]['titulo'] != "" && $this->campo[$nome]['titulo'] != "*")?"<label for=\"".$this->campo[$nome]['id']."\">".$this->campo[$nome]['titulo'].":</label>":"")."</td><td>".$this->montar_campo($nome, false, true, $alinhamento)."</td></tr></table></div>";
				$lista_valor_selec[$tipo][] = "'{$val}'";
				//echo $tipo."<br>";
				continue;
			}
			$count_itens++;
			if($this->campo[$nome]['titulo'] != ""){
				$classe = (trim($this->campo[$nome]['titulo']) != "" && $sentido == "v")? "class=\"campo\"" : "";
				$$tipo .= "<td ".$classe."  ".($colspan>1?"colspan=".$colspan:"")." >".(($this->campo[$nome]['titulo'] != "" && $this->campo[$nome]['titulo'] != "*")?("<label for=\"".$this->campo[$nome]['id']."\">".$this->campo[$nome]['titulo'].":</label>"):"");
				$$tipo .= ($posicao == "h")? "</td><td ".($colspan>1?"colspan=".$colspan:"")." valign=\"top\" >" : "<br />";
			}else{
				$$tipo .= ($sentido == "v")? "<td colspan=\"".($colspan*2)."\" valign=\"top\">" : "<td>";
				$$tipo .= ($posicao == "v")? "<br />" : "";
			}
			$$tipo .= $this->montar_campo($nome,false, true, $alinhamento)."</td>";
			//echo $$tipo."<br>".$tipo."<hr>";
			
			//$$tipo .= (($sentido == "v" && $count_itens%$this->colunas==0) || $cont == count($this->campo))? "</tr>" : "";
			if(!$this->campo[$nome]['avancado']) $cont++;			
		}
		$colspan=$this->colunas = 1;
				
		if(count($this->avancado) > 0 && trim($_avancados) != ''){
				$eva['script'][] = "
				function form_avancado(id){
					if(eva_elem(id).style.visibility == 'visible'){
						eva_elem(id).style.height = '1px';
						eva_elem(id).style.witdh = '1px';
						eva_elem(id).style.visibility = 'hidden';
						eva_elem(id).style.position = 'absolute';
					}else{
						eva_elem(id).style.position = 'relative';
						eva_elem(id).style.visibility = 'visible';
						eva_elem(id).style.height = '100%';
						eva_elem(id).style.width = '';
					};
				};";
				$indice = $this->contar_menu();
				$this->menu[$indice]['alt'] = $idioma['avancado'];
				$this->menu[$indice]['onclick'] = 'form_avancado(\'avancados_'.$this->id.'\')';
				$this->menu[$indice]['img'] = "imagens/16x16/apps/package_application.png";
		}
		$menu1 = "";
		$menu2 = "";
		// Mantem o menu 1 para criacao do menu 2
		$limpa = ($this->menu_tipo == 0)? false : true;
		// Menu de cima
		if($this->menu_tipo == 0 || $this->menu_tipo == 2){
			$menu1 = $eva['modulo_eva_menu']->criar_menu($this->menu,$limpa);
		}
		// Menu de baixo
		if($this->menu_tipo == 0 || $this->menu_tipo == 1){
			$menu2 = $eva['modulo_eva_menu']->criar_menu($this->menu);
		}
		
		// Iniciando cabecalho do formulario e tabela
		if(trim($this->titulo) != "" || count($this->avancado) > 0){
			$this->titulo = $this->titulo;
		}
		$fieldset = array("", "");
		if(!empty($this->titulo)){
			$fieldset[0] = "<fieldset><legend>".$this->titulo."</legend>";
			$fieldset[1] = "</fieldset>";
		}
		//var_dump(htmlentities($_campos));
		if(!empty($lista_valor_selec)){
			$eva['script'][] = "
			if(!lista_valor_selec)
				var lista_valor_selec = new Array();";
		}
		if(!empty($lista_valor_selec)){
			while(list($k,$v) = each($lista_valor_selec)){	
				$eva['script'][] = "lista_valor_selec['{$k}_{$this->aba}'] = new Array(".implode(",", $v).");";
				//echo implode(",", $v)."<br>";
			}
		}
		if(!empty($select_opt)){
			//faz o replace na variavel campos pelos campos do select
			//var_dump($select_opt);
			//echo implode("<hr>", $select_opt);
			//var_dump($_campos);echo "<hr>";
			while(list($k,$v) = each($select_opt)){//echo "-- {$k}<br>";
				$_campos = str_replace("{".$k."}", implode("", $v), $_campos);
				//var_dump("-- {".$k."}, ".implode("" , $v).", {\$_campos}<hr>");
				//var_dump(htmlentities($_campos));
				//var_dump($_campos);	echo "<hr>";			
			}
		}
		//var_dump($_campos);echo "<hr>";
		$this->form = "	{$fieldset[0]}";
			if($form && $this->menu_tipo<4)
				$this->form .= "<form class=\"".$this->classe."\" id=\"".$this->id."\" name=\"".$this->id."\" target=\"".$this->destino."\" method=\"".$this->metodo."\" action=\"".$this->action."\" enctype=\"".$enctype."\" ".$this->extra.">";
			
			$this->form .= "
			".$menu1."
			".$this->cabecalho."
			<table class=\"formulario\" width=\"{$table_width}\"><tr>
			".$_campos."
			</tr></table>
			<div id=\"avancados_".$this->id."\" style=\"visibility:hidden; height: 1px; position: absolute;\">
			<table class=\"formulario\" width=\"100%\">
			".$_avancados."
			</table>
			</div>
			".$campos_ocultos."
			".$this->rodape."
			".$menu2."
			";	
			if($form && $this->menu_tipo<4)		
				$this->form .= "</form>";
			
			$this->form .= "{$fieldset[1]}";
		
		$html_form = $this->form;
		// Metodo destrutor
		if($limpar) $this->destroy();
		//var_dump($html_form);exit;
		// retornando codigo HTML com o formulario
		return $html_form;
    }//criar
	
	function set_col($i){
		// ajusta o campo para que na hora de criar o script saiba onde mudar a quantidade de colunas
		$this->campo("set_col ".(count($this->campo))." $i");
		
		if($i>$this->max_colunas)
			$this->max_colunas = $i;
		
	}
	
	/**
	 * Cria um javascript para que um certo campo possa ser inserido varias vezes na mesma tela
	 *
	 * @param array $a
	 * @param string $titulo
	 * @param string $direcao
	 * @param array $valores
	 * @param string $extra
	 * @param array $menu_extra
	 * @param boolean $avancado
	 * @return string
	 */
	function campos_multiplos($a, $titulo, $direcao="horizontal", $valores=array(""), $extra='style="border:thin; border-color:#FFFFFF; padding:2px;width:100%;"', $menu_extra=array(), $avancado = false, $sort = false){
		global $eva;
		global $idioma;
		if(empty($eva['aba']->total)) $eva['aba']->total=rand(1,100);
		$eva['incluir']->incluir("arquivo");
		$titulo2=str_replace(" ", "_",$eva['geral']->retirar_acentos($titulo));
		// detecta os campos multiplos
		$multi=array();
		
		// procura se existe algum autocompletar no campo multiplo
		$autoc=false;
		for($i=0;$i<count($a);$i++){
			if(is_array($this->autocompletar) && in_array($a[$i] , $this->autocompletar))
				$autoc=true;
		}
		$eva['script'][]="
			/*insere linhas na tabela com os campos - usada no modulo de enquete*/
			var linha = 0;
			function insere_linha_cm(_ul, array_campos, autoc){	
				var ul=document.getElementById(_ul);
				if(ul){
					for(i=0;i<array_campos.length;i++){	
						s = new String(array_campos[i]);
						s = s.replace(/_eva_/g,_ul+linha);
						
						div = document.createElement('div');
						div.id = \"di_\"+_ul+\"_\"+(linha);
						div.innerHTML+=s;	
						
						li = document.createElement('li');
						li.id = \"li_\"+_ul+\"_\"+(linha);
						
						li.innerHTML=\"<table border=\\\"0\\\" cellpadding=\\\"2\\\" cellspacing=\\\"0\\\" width=\\\"100%\\\" ><tbody><tr><td valign=\\\"top\\\"><div class=\\\"alerta_barra_titulo handle\\\"><table border=\\\"0\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" align=\\\"right\\\"><tr><td><div id='h_\"+div.id+\"'></div></td><td><img src=\\\"{$eva['url_eva']}imagens/transparente.gif\\\" width=\\\"16\\\" height=\\\"16\\\" /></td><td><div class=\\\"botao_minimizar\\\" onMouseOver=\\\"this.style.cursor=eva_mouseover;\\\" onclick=\\\"li_min('\"+div.id+\"', this);\\\"></div></td><td><div class=\\\"alerta_fechar\\\" onMouseOver=\\\"this.style.cursor=eva_mouseover;\\\" onClick=\\\"apagar_li_cm('\"+_ul+\"', '\"+li.id+\"');\\\"></div></td></tr></table></div></td></tr></tbody></table>\";
						
						li.appendChild(div);				
						ul.appendChild(li);	
						
						linha++;					
						
					};	
									
					".($autoc?"autocompleteAutoAttach();":"")."
					if(autoc){
						s = new String(auto_completar[0][1]);
						s = s.replace(/_exibir/g,'');
						acomplete = document.getElementsByName(s);
						j=0;
						for(i=(acomplete.length-1);i>=0;i--){
							if(auto_completar[j] && acomplete[i].form.id == auto_completar[j][2]){
								acomplete[i].value=auto_completar[j++][0];
							}
						}						
					}
				}".(($sort)?"
				dragsort.makeListSortable(eva_elem(_ul), setHandle);":"")."
			};
			function apagar_li_cm(ul_id, li_id){
				if(confirm('{$idioma['tem_certeza']}'))
					eva_elem(ul_id).removeChild(eva_elem(li_id));
			};
			function li_min(li, btn){
				l = eva_elem(li);
				titulo = eva_elem('h_'+li);
				if(l.style.display != 'none'){	
					titulo.innerHTML = li_title_name(li, btn);
					li_title_name(li, btn);
					btn.className = 'botao_restaurar';
					l.style.display = 'none';
					l.style.visibility = 'hidden';
				}else{
					titulo.innerHTML = '';
					btn.className = 'botao_minimizar';
					l.style.display = 'block';
					l.style.visibility = '';
				}
			} 
			function li_title_name(li, btn){
				childNodes = eva_elem(li).firstChild.childNodes;				
				for(i = 0; i <childNodes.length; i++ ) {
					n = childNodes[i].nodeName;
					if(n == 'input' || n == 'INPUT'){
						 return (childNodes[i].value);
					}
					if(n == 'textarea' || n == '#text'){
						 return (childNodes[i].nodeValue);
					}
					if(n == 'select' || n == 'SELECT'){
						 return (childNodes[i].value);
					}
				}
				return '';
			}
		";
		
		if($sort){
			$eva['script'][] = '
			/* toolman_dragsort */
			var junkdrawer = ToolMan.junkdrawer();
			var dragsort = ToolMan.dragsort();

			function setHandle(item) {
				//item.toolManDragGroup.setHandle(findHandle(item));
			}
			
			function findHandle(item) {
				var children = item.getElementsByTagName("div");
				for (var i = 0; i < children.length; i++) {
					var child = children[i];
			
					if (child.getAttribute("class") == null) continue;
			
					if (child.getAttribute("class").indexOf("handle") >= 0)
						return child;
				}
				return item;
			}
			';
			
			//$eva['onload'][] = "dragsort.makeListSortable(eva_elem(\"{$titulo2}_".$eva['aba']->total."\"), setHandle);";
		}
		
		$script="
		cm_{$titulo2}_".$eva['aba']->total."= new Array();
		temp_cm = new Array();
		auto_completar = new Array();
		";
		$comp1=($direcao!="horizontal")?'<fieldset style="border: thin solid #EEEEEE;">':"<fieldset style=\"border: thin solid #EEEEEE;\"><table width=\"100%\"><tr><td>";
		$comp2=($direcao!="horizontal")?'</fieldset>':"</td></tr></table></fieldset>";
		$comp_implode=($direcao!="horizontal")?'<br><br>':"</td><td>"; 
		$cont_autoc = 0;
		for($i=0;!empty($valores) && $i<count($valores[0]);$i++){
			$count=0;
			$m=array();
			while(list($nome) = each($this->campo)){
				$key=array_search($nome, $a);
				if($key!==false){
					// coloca colchetes
					if($this->campo[$nome]['tipo']!="file"){			
						if(!empty($this->campo[$nome]['html'])){
							$mudar = str_replace("_exibir","",$this->campo[$nome]['nome']);
							$palavra[]="name=\"".$mudar."\"";
							$muda[]="name=\"".$mudar."[]\"";
							$this->campo[$nome]['html'] = str_replace($palavra, $muda,$this->campo[$nome]['html']);
						}
						// se for do tipo estrela
						if($this->campo[$nome]['tipo']=="dados" && eregi("star_onclick", $this->campo[$nome]['valor'])){
							$this->campo[$nome]['valor'] = str_replace("\" to=\"\"", "[]\" to=\"\"",$this->campo[$nome]['valor']); 
						}
						$this->campo[$nome]['nome'].="[]";
					}
					
					// se for autocomplete o $valores[$count][$i] ter� o valor do cod e o nome
					//Ex.: array('cod'=>$linha['ND_US_COD'], 'nome'=>$linha['US_NOME']);
					$auto_completar = "false";
					if(!empty($valores[$count][$i]) && is_array($valores[$count][$i])){					
						$script.="
						auto_completar[".($cont_autoc)."] = new Array();
						auto_completar[".($cont_autoc)."][0] = '{$valores[$count][$i]['cod']}';
						auto_completar[".($cont_autoc)."][1] = '{$this->campo[$nome]['nome']}'
						auto_completar[".($cont_autoc++)."][2] = '{$this->id}';";
						//echo "{$valores[$count][$i]['cod']} - {$valores[$count][$i]['nome']}<br>";
						$valores[$count][$i] = $valores[$count][$i]['nome'];												
						$auto_completar = "true";
					}
					$this->campo[$nome]['valor']=(isset($valores[$count][$i]))?$valores[$count][$i]:(!empty($this->campo[$nome]['valor']) && $this->campo[$nome]['tipo'] == "dados"?$this->campo[$nome]['valor']:"");
					//var_dump($valores[$count]);echo "<br>".count($valores[0])."<hr>";
					$count++;					
					$m[]=$this->montar_campo($nome, true, false);
					// retira o colchete
					if($this->campo[$nome]['tipo']!="file")
						$this->campo[$nome]['nome'] = substr($this->campo[$nome]['nome'], 0, strlen($this->campo[$nome]['nome'])-2);
					if($this->campo[$nome]['tipo'] != "dados")
						unset($this->campo[$nome]['valor']);
					//var_dump($a);echo "<br>".$key."<hr>";
					//unset($a[$key]);				
				}				
			}
			
			reset($this->campo);
			
			$var=addslashes(implode($comp_implode,$m));
			$eva['arquivo']->retirar_espacos($var);
			$script.="
					temp_cm[$i] = '{$comp1}{$var}{$comp2}';					
				";
			//echo "{$i}>=".(count($valores[0])-1)."<br>";
			if($i>=(count($valores[0])-1)){
			$script.="
					insere_linha_cm('{$titulo2}_".$eva['aba']->total."', temp_cm, {$auto_completar});
				";
			}
		}
		while(list($nome) = each($this->campo)){
			if(in_array($nome, $a)){
				if($this->campo[$nome]['tipo']!="file")
					$this->campo[$nome]['nome'].="[]";			
				$multi[]=$this->montar_campo($nome);				
			}
		}
		$var=addslashes(implode($comp_implode,$multi));
		$eva['arquivo']->retirar_espacos($var);
		
		$script.="
		cm_{$titulo2}_".$eva['aba']->total."[0]= '{$comp1}{$var}{$comp2}';
		";		
		
		$eva['onload'][]=$script;
		
		reset($this->campo);
		// cria o menu
		$menu['fundo']=false;
		$menu['largura']="24px";
		$menu[0]['url']="javascript: insere_linha_cm('{$titulo2}_".$eva['aba']->total."', cm_{$titulo2}_".$eva['aba']->total.", false);";
		$menu[0]['img']="imagens/16x16/actions/down.png";
		$menu[0]['alt']=$idioma["mais"];
		$menu = array_merge_recursive($menu,$menu_extra);
		$campo_multi = implode("",$multi); 
		$tabela = "<ul id=\"{$titulo2}_".$eva['aba']->total."\" {$extra}></ul>";
		
		
		$this->campo($titulo2."_".$eva['aba']->total,$titulo,"dados","<fieldset style=\"border: thin solid #DDDDDD;\">".$tabela.$eva['modulo_eva_menu']->criar_menu($menu)."</fieldset>", "", "","","","", $avancado);
		
		return $titulo2."_".$eva['aba']->total;
	}//campos_multiplos
	
	/**
	 * Remove campo do form
	 *
	 * @param string $nome
	 */
	function remover_campo($nome){
		$this->campo[$nome] = array();
		unset($this->campo[$nome]);
	}
	
	/**
	 * Altera os valores de um campo
	 *
	 * @param string $nome
	 * @param string $novo_nome
	 * @param string $titulo
	 * @param string $tipo
	 * @param string $valor
	 * @param string $opcoes
	 * @param string $alerta
	 * @param string $formato
	 * @param string $html
	 * @param string $extra
	 * @param string $avancado
	 * @return unknown
	 */
	function alterar_campo($nome, $novo_nome = "",$titulo = "",$tipo = "", $valor = "", $opcoes = "", $alerta = "",$formato = "",$html = "",$extra="", $avancado = NULL){
		global $eva;
        global $idioma;
		
		// Caso o cmpo n�o tenha nome
		if(trim($nome) == "") return;
		if(!isset($this->id) || (isset($this->id) && $this->id == ""))  $this->config();
		// muda o nome do campo
		if (!empty($novo_nome)){
			$this->campo[$novo_nome] = @$this->campo[$nome];
			// apaga o validador
			if(!empty($this->menu['campo'])){
				$key = array_search(@$this->campo[$novo_nome]['id'],$this->menu['campo']);
				$this->menu['campo'][$key]="";
				$this->menu['alerta'][$key]="";
				$this->menu['formato'][$key]="";
			}
			$this->remover_campo($nome);
			$nome = $novo_nome;
			$this->campo[$nome]['nome'] = $nome;
		}		
		if (!empty($titulo))
			$this->campo[$nome]['titulo'] = $titulo;
		if (!empty($tipo))
			$this->campo[$nome]['tipo'] = $tipo;
		if (!empty($valor))
			$this->campo[$nome]['valor'] = $valor;
		if (!empty($extra))
			$this->campo[$nome]['extra'] = $extra;
		if (!empty($html))
			$this->campo[$nome]['html'] = $html;
		if (!empty($opcoes))
			$this->campo[$nome]['opcoes'] = $opcoes;
		if (isset($avancado))
			$this->campo[$nome]['avancado'] = $avancado;

		if(isset($avancado) && $avancado) $this->avancado[$campo['id']] = $nome;
		
		if($alerta != "" || $formato != "" || $tipo=="validador" || $alerta===true){
			$this->menu['campo'][] = $nome.@$eva['aba']->total;
			$this->menu['alerta'][] = (trim($alerta) != "" && !$alerta===true )? $alerta : $idioma['validar_campo']." ".@$campo['titulo'];
			$this->menu['formato'][] = (trim($formato) != "")? $formato : "nao_nulo";
		}
		
		return @$this->campo[$nome]['id'];
    }//campo
	
	/**
	 * Upload de arquivo
	 *
	 * @param string $nome
	 * @param string $titulo
	 */
	function upload($nome, $titulo){
		global $idioma;
		$this->campo($nome,$titulo,"file");
		$this->campo("-","","dados", '<iframe style="width:0px; height:0px; border-style:none;" id="upload_form" name="upload_form"></iframe>');
		$this->campos_multiplos(array($nome), $nome, "vertical");
	}
	
} //End Class
?>