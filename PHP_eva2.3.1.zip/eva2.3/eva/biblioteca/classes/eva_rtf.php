<?php 
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/
include_once("extras/rtfgenerator/class_rtf.php");
class eva_rtf extends rtf{		
	
	/**
	 * Constructor
	 *
	 * @param string $font
	 * @param int $size
	 * @return eva_rtf
	 */
	function eva_rtf($font = 'Arial', $size = 11){		
		global $fonts_array, $inch ,$cm ,$mm;
		include("extras/rtfgenerator/source_rtf.php");
		$this->rtf("rtf_config.php");
		$this->setPaperSize(5);
		$this->setPaperOrientation(1);
		$this->setDefaultFontFace(0);
		$this->setDefaultFontSize(24);
		$this->setAuthor("noginn");
		$this->setOperator("me@noginn.com");
		$this->setTitle("RTF Document");
		$this->addColour("#000000");
	}	
	
	/**
	 * Transforma html em RTF
	 *
	 * @param string $html
	 * @param string $name
	 * @param char $dest I = Send to standard output; D=Download file F=Save to local file; S=Return as a string
	 * @return string
	 */
	function html2rtf($html, $name='',$dest='S'){ // coloque $dest='D' para download;
		global $eva;
		//$html = strip_tags($html, '<tt><kbd><samp><option><outline><newpage><page_break><s><strike><del><bdo><big><small><address><ins><cite><font><center><sup><sub><input><select><option><textarea><title><form><ol><ul><li><h1><h2><h3><h4><h5><h6><pre><b><u><i><a><img><p><br><strong><em><code><th><tr><blockquote><hr><td><tr><table><div>');
		$html = strip_tags($html, '<ul><li><p><strong><b><em><i><u><strike><sub><sup><h1><h2><h3><hr><br><tab>');
		$html = $eva['geral']->unhtmlentities($html);		
		$this->addText($html);
		return $this->gerar_rtf($name,$dest);
	}
	
	/**
	 * Cria o RTF
	 *
	 * @param string $name
	 * @param char $dest I = Send to standard output; D=Download file F=Save to local file; S=Return as a string
	 * @return buffer
	 */
	function gerar_rtf($name='',$dest='S'){
		$this->buffer .= "{";
		// Header
		$this->buffer .= $this->getHeader();
		// Font table
		$this->buffer .= $this->getFontTable();
		// Colour table
		$this->buffer .= $this->getColourTable();
		// File Information
		$this->buffer .= $this->getInformation();
		// Default font values
		$this->buffer .= $this->getDefaultFont();
		// Page display settings
		$this->buffer .= $this->getPageSettings();
		// Parse the text into RTF
		$this->buffer .= $this->parseDocument();
		$this->buffer .= "}";
		
		switch($dest){
			case 'I':
				//Send to standard output
				if(isset($HTTP_SERVER_VARS['SERVER_NAME']))
				{
					//We send to a browser
					Header('Content-Type: application/rtf');
					if(headers_sent())
						$this->Error('Some data has already been output to browser, can\'t send RTF file');
					Header('Content-Length: '.strlen($this->buffer));
					Header('Content-disposition: inline; filename='.$name);
				}
				echo $this->buffer;
				break;
			case 'D':
				//Download file
				if(isset($HTTP_SERVER_VARS['HTTP_USER_AGENT']) and strpos($HTTP_SERVER_VARS['HTTP_USER_AGENT'],'MSIE'))
					Header('Content-Type: application/force-download');
				else
					Header('Content-Type: application/octet-stream');
				if(headers_sent())
					$this->Error('Some data has already been output to browser, can\'t send RTF file');
				Header('Content-Length: '.strlen($this->buffer));
				Header('Content-disposition: attachment; filename='.$name);
				echo $this->buffer;
				break;
			case 'F':
				//Save to local file
				$f=fopen($name,'wb');
				if(!$f) $this->Error('Unable to create output file: '.$name);
				fwrite($f,$this->buffer,strlen($this->buffer));
				fclose($f);
				break;
			case 'S':
				//Return as a string
				return $this->buffer;
			default:
				$this->Error('Incorrect output destination: '.$dest);
		}
	}
	
	

}
?>