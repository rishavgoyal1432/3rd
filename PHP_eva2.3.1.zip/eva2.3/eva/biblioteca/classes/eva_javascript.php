<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/


// Classe para controle de incluir e gerar classes
require_once("eva_incluir.php");
$eva['incluir'] = (isset($eva['incluir']))? $eva['incluir'] : new eva_incluir();
$eva['incluir']->incluir('geral', 'alerta');

class eva_javascript{	
	
	/**
	 * Carrega o m�dulo indicado na posi��o do tema
	 *
	 * @param string $exibir
	 */
	function incluir($exibir){
		global $eva;
		global $config;
		
		$registro = array();	
		$url="biblioteca/javascripts/";
			
		$palavra = array();
		$palavra['Calendar\.setup']=array(0=>"jscalendar/skins/aqua/theme.css");	
		$palavra['Active\.Controls\.Grid']=array(0=>"grid/runtime/styles/xp/grid.css");
		$palavra['ctDraw']=array(0=>"jscooktree/theme/theme.css");
		
		// Adicionando CSS	
		foreach($palavra as $key => $val) {
			if(ereg($key, $exibir)){
				for($i=0;$i<count($val);$i++){
					if(!in_array($val[$i],$registro)){
						$registro[]=$val[$i];
						if(isset($_GET['comando_tipo']) && $_GET['comando_tipo']=='xml'){
							$eva['head_css'][] = (($eva['caminho_eva'] == 'eva/' || !eregi("(tiny_mce\/|image_manager)",$val[$i]))?$eva['url_eva'] : $eva['config']['url']).$url.$val[$i];
						}else{
							$eva['head'][] = "<link rel=\"stylesheet\" type=\"text/css\" href=\"".$eva['url_eva'].$url.$val[$i]."\" />";
						}
					}
				}
			}
		}
		
		$palavra['Calendar.setup']=array(0=>"jscalendar/calendar.js?no_jsmini=1",1=>"funcoes_calendario.js.php",2=>"jscalendar/calendar-setup.js");
		$palavra['TinyMCE']=array(0=>"tiny_mce/tiny_mce_gzip.php?no_jsmini=1",1=>"funcoes_tiny_mce.js.php?no_jsmini=1".(!empty($eva['tinemce'])?"?tipo=1":""));
		// variavel usada para definir o tipo do editor ver eva_form.php linha 510 e funcoes_tiny_mce.js.php linha 30
		if(isset($eva['tinemce'])) unset($eva['tinemce']);
		$palavra['toolman']=array(0=>"tool-man/core.js",1=>"tool-man/events.js",2=>"tool-man/css.js",3=>"tool-man/coordinates.js",4=>"tool-man/drag.js",5=>"tool-man/dragsort.js");	
		$palavra['dragsort']=array(0=>"tool-man/core.js",1=>"tool-man/events.js",2=>"tool-man/css.js",3=>"tool-man/coordinates.js",4=>"tool-man/drag.js",5=>"tool-man/dragsort.js");	
		$palavra['tabela_de_cores']=array(0=>"funcoes_tabela_de_cores.js.php");
		$palavra['_aba']=array(0=>"funcoes_abas.js");
		$palavra['selecionar_imagem\(']=array(0=>"tiny_mce/plugins/imgmanager/ImageManager/assets/dialog.js",1=>"tiny_mce/plugins/imgmanager/ImageManager/IMEStandalone.js",2=>"extras/funcoes_image_manager.js.php");
		$palavra['Active\.Controls\.Grid']=array(0=>"grid/runtime/lib/grid.js", 1=>"grid/patches/paging1.js");
		$palavra['cmDraw']=array(0=>"jscookmenu/jscookmenu.js", 1=>"jscookmenu/theme/theme.js");
		$palavra['ctDraw']=array(0=>"jscooktree/jscooktree.js", 1=>"jscooktree/theme/theme.js");	
		$palavra['eva_autocompletar']=array(0=>"autocomplete/drupal.js", 1=>"autocomplete/autocomplete.js");		
		
		if(empty($_GET['comando']))
			if(file_exists($eva['caminho']."arquivos/config.php"))
				$js[] = 'funcoes.js';
			else
				$eva['head'][] = "<script type=\"text/javascript\" src=\"{$eva['url_eva']}biblioteca/javascripts/funcoes.js\"></script>";
				
			
			/*if(!$eva['seguranca']->verificar_acesso()){
				echo "<script type=\"text/javascript\" src=\"index.php?comando=jsmini&url={$eva['url_eva']}biblioteca/javascripts/funcoes.js\"></script>";echo "<br>".__LINE__;echo "--".$eva['url_eva']."<hr>";exit;				
				$eva['head'][] = "<script type=\"text/javascript\" src=\"index.php?comando=jsmini&url={$eva['url_eva']}biblioteca/javascripts/funcoes.js\"></script>";
			}else{ // senao mostre todos js em um unico arquivo
				$qs = str_replace("=", "", base64_encode($_SERVER['QUERY_STRING']));
				$_SESSION['script'][$qs] = $eva['arquivo']->ler($eva['caminho_eva'].'biblioteca/javascripts/funcoes.js')."\n";
				$eva['head'][] = "<script type=\"text/javascript\" src=\"index.php?comando={$qs}&comando_tipo=js_sessao\"></script>";
			}*/
		
		// Adicionando Scripts
		//var_dump($exibir);echo "\n";echo "\n";exit;
		foreach($palavra as $key => $val) {
			//echo "<hr>";var_dump($key);echo "\n";echo "\n";echo "<br>";
			if(ereg($key, $eva['include']) || ereg($key, $exibir)){
				for($i=0;$i<count($val);$i++){
					if(!in_array($val[$i],$registro)){
						$registro[]=$val[$i];
						//echo "<hr>".$val[$i];
						/*var_dump($eva['caminho_eva'] == 'eva/');
						var_dump(!eregi("(tiny_mce\/|image_manager)",$val[$i]));echo "<hr>";*/
						if(isset($_GET['comando_tipo']) && $_GET['comando_tipo']=='xml'){
							$eva['head_xml'][] = ((!eregi("no_jsmini", $val[$i]) && !eregi("\.php(\?)?", $val[$i]))?"index.php?comando=jsmini&url=":"").(($eva['caminho_eva'] == 'eva/' || !eregi("(tiny_mce\/|image_manager)",$val[$i]))?$eva['url_eva'] : $eva['config']['url']).$url.str_replace("?no_jsmini=1", "", $val[$i]);
						}else{
							if(!eregi("no_jsmini", $val[$i]) && !eregi("\.php(\?)?", $val[$i]) && !eregi("(tiny_mce\/|image_manager)",$val[$i]) && file_exists($eva['caminho']."arquivos/config.php")){
								/*$_SESSION['script'][$qs] .= $eva['arquivo']->ler($eva['caminho_eva'].$url.str_replace("?no_jsmini=1", "", $val[$i]))."\n";*/
								//echo $val[$i]."<br>";
								$js[] = str_replace("?no_jsmini=1", "", $val[$i]);
							}else{									
								$eva['head'][] = "<script type=\"text/javascript\" src=\"".((!eregi("no_jsmini", $val[$i]) && !eregi("\.php(\?)?", $val[$i]))?"index.php?comando=jsmini&url=":"").(($eva['caminho_eva'] == 'eva/' || !eregi("(tiny_mce\/|image_manager)",$val[$i]))?$eva['url_eva'] : $eva['config']['url']).$url.str_replace("?no_jsmini=1", "", $val[$i])."\"></script>";
							}
						}
					}
				}				
			} 
		}		
		
		// insere o modelo de alerta visivel em todas as paginas que nao sejam $_GET['comando']
		if(empty($_GET['comando'])){
			if(file_exists($eva['caminho']."arquivos/config.php"))
				$js[] = 'tipmessage/main.js';	
			else
				$eva['head'][] = "<script type=\"text/javascript\" src=\"{$eva['url_eva']}biblioteca/javascripts/tipmessage/main.js\"></script>";		
							
			if(!empty($config['modelo_alerta']) && $alerta =  file_get_contents($eva['caminho']."arquivos/temas/".$eva['site']['tema']."/".$config['modelo_alerta'])){
				$alerta = str_replace( "'", "\'", $alerta);
				$estilo = "'styleClass', 'null', ";
				$fechar = "";
				$alerta = $eva['carregar']->tratar_src($alerta);
			}else{
				$fechar = "{fechar}";
				$alerta = "{bloco}";
			}
			$alerta = str_replace( "{titulo}", "", $alerta);
			$alerta = str_replace( "{bloco}", "<div class=\"alerta\" id=\"alerta_div\"><table width=\"100%\"><tr><td vlaign=\"top\">[eva_alerta_texto]</td>{$fechar}</tr></table></div>", $alerta);
			$eva['arquivo']->retirar_espacos($alerta);
			$alerta = addslashes($alerta);
			$alerta = explode("[eva_alerta_texto]",$alerta);
			$alerta2 = str_replace( "{fechar}", "", $alerta[1]);			
			$alerta3 = str_replace( "{fechar}", "<td width=\"2\" align=\"right\" valign=\"top\"><div class=\"alerta_fechar\" onMouseOver=\"this.style.cursor=eva_mouseover;\" onclick=\"stickyhide();\"></div></td>", $alerta[1]);
			
			//if(empty($_GET['comando']) && empty($_GET['ajax_funcao'])){
			if(empty($_GET['comando'])){
				$eva['script'][] = "
				var eva_alerta_modelo1;
				var eva_alerta_modelo2;
				var eva_alerta_modelo3;
				eva_alerta_modelo1='{$alerta[0]}';
				eva_alerta_modelo2='{$alerta2}';
				eva_alerta_modelo3='{$alerta3}';
				tag_imagem=".'\'<img src="eva_imagem.png" border="0" align="middle" align="right" hspace="3">\''.";
				";
			}
		}
		if(!empty($js))
			$eva['head'][] = "<script type=\"text/javascript\" src=\"index.php?comando=".base64_encode(serialize($js))."&comando_tipo=js_list\"></script>";
	}
	
	/**
	 * Configura uma pagina para exibir um js formaando o header e incluindo as classes do eva necessarias
	 *
	 * @param string $acao
	 */
	function config($acao){
		global $idioma;
		global $eva;
		
		switch($acao){
			case 'inicio':
				// Classe para controle de incluir e gerar classes
				//header("Content-disposition: inline; filename=eva.js");
				header("content-type: application/x-javascript");
				require_once('../../biblioteca/classes/eva_incluir.php');
				$eva['incluir'] = new eva_incluir();				
				// Incuindo classes principais
				$eva['incluir']->incluir('seguranca', "arquivo");
				// Incluindo arquivos de idiomas
				include_once("../../../arquivos/config.php");
				$config['idioma_padrao'] = (trim($config['idioma_padrao']) != "")? $config['idioma_padrao'] : "br" ;
				//include("funcoes.php");
				include("../idiomas/".$config['idioma_padrao'].".php");		
				// Criando sess�es
				// Definindo o nome e inicializando sess�o
				session_name(md5($config['url']));
				session_start();
				
				if(!empty($_SESSION[__FILE__])){echo $_SESSION[__FILE__];exit;}
				error_reporting(0);
				
				$eva['seguranca']->inicia_ob_start();
			break;
			case 'fim':
				$eva['incluir']->incluir('jsmini');
				$_SESSION[__FILE__] = $eva['jsmini']->compactar(ob_get_contents(), "packer");
				ob_end_flush();
			break;
		}
	}
}
?>