<?php
/**
* @package eva framework
* @copyright (C) 2004 EVA cms. Todos os direitos reservados
* @license http://www.gnu.org/licenses/lgpl.html LGPL License
* @author Alessandro Nunes <alessandro@evacms.com.br>
* @author Daniel Neto <daniel@evacms.com.br>
* @link http://www.evacms.com.br Site oficial do projeto EVA
**/

$eva['incluir']->incluir("alerta");

/**
* Gerencia a criacao e a manipulacao de arquivos do sistema
*/
class eva_arquivo{	

	/**
	* Construtor da classe
	*/
	function eva_arquivo(){
	} //eva_arquivo
	
	/**
	* Grava um arquivo
	* @param string Caminho e nome do arquivo a ser gravado
	* @param string Informa��o a ser armazenada no arquivo
	* @return int Tamanho em bytes do arquivo gravado
	*/	
	function gravar($arquivo, $dados=''){
		global $eva;
		$diretorio=explode("/",$arquivo);
		unset($diretorio[count($diretorio)-1]);
		$diretorio=implode("/",$diretorio);	
		if($this->verificar_diretorio($diretorio)){
			if(!eregi("^{$eva['caminho']}", $arquivo))
				@chdir($eva['caminho']);
			//echo $diretorio."<br>".$arquivo;
			//var_dump(is_dir($diretorio));			
			//@chdir($c_old);
			if($a = fopen($arquivo, "w")){
				$bytes = fwrite($a, $dados);
				fclose($a);	
			}
			if(!eregi("^{$eva['caminho']}", $arquivo))
				@chdir($eva['caminho_eva']);
			return $bytes;
		}				
		//@chdir($eva['caminho_eva']);		
		@chdir($eva['caminho_eva']);
		return false;
	} //gravar
	
	/**
	* Grava um arquivo
	* @param string Caminho e nome do arquivo a ser gravado
	* @param string Informa��o a ser armazenada no arquivo
	* @return int Tamanho em bytes do arquivo gravado
	*/	
	function gravar_temp($dados=''){
		global $eva;
		//var_dump($dados);
		if(empty($dados)) return false;
		@chdir($eva['caminho']);
		$dir = "arquivos/downloads/tmp";
		if($this->verificar_diretorio($dir)){
			$arquivo = tempnam ($eva['caminho'].$dir, "EVA_");
			$arquivo = str_replace($eva['caminho'], "", $arquivo);	
			//var_dump($eva['caminho'].$dir);var_dump($arquivo);	exit;	
			//$arquivo = $dir."/".mktime();
			//var_dump($arquivo);	exit;echo "<hr>";
			$fw = $this->gravar($arquivo, $dados);
			//var_dump($fw); echo "<hr>";
			@chdir($eva['caminho_eva']);
			if($fw)
				return $arquivo;
		}
		@chdir($eva['caminho_eva']);
		return false;
		
	} //gravar
	
	/**
	* Transformna um valor em bytes em seu respectivo em Tb, Gb, Mb, Kb ou bytes
	* @param string Valor em bytes
	* @return string Valor convertido para apresenta��o
	*/	
	function tratar_bytes($b){
		global $eva;
		if(is_string($b)){
			$b=filesize($eva['caminho'].$b);
		}
		if($b > pow(1024,4)){
			return number_format($b/pow(1024,4), 2, '.', ' ')." Tb";   
		}elseif($b > pow(1024,3)){
			return number_format($b/pow(1024,3), 2, '.', ' ')." Gb";   
		}elseif($b > pow(1024,2)){
			return number_format($b/pow(1024,2), 2, '.', ' ')." Mb";   
		}elseif($b > 1024){
			return number_format($b/1024, 1, '.', ' ')." Kb";   
		}else{
			return number_format($b, 0, '.', ' ')." bytes";
		}
	} //tratar_bytes
	
	/**
	* Lista os arquivos de uma pasta
	* @param string Pasta a ser listada
	* @return string Lista de arquivos (n�o diret�rios)
	*/	
	function listar_arquivos($diretorio){
		$arquivos = array();
		if ($handle = opendir($diretorio)) {	
			while (false !== ($file = readdir($handle))) {
				if ($file != "." && $file != ".." && !is_dir($diretorio."/".$file)) {
					$arquivos[] = $file;
				}
			}
		}
		return $arquivos;
	} //listar_arquivos
	
	/**
	* Verifica se um diret�rio existe, suas permiss�es, e o criar caso n�o exista
	* @param string Pasta a ser analisada
	* @param int Permiss�o desejada
	* @return boolean True caso exista ou seja criado, ou false
	*/	
	function verificar_diretorio($diretorio = "", $permissao = 0777){
		global $eva;
		//var_dump($eva['caminho']);exit;
		//if($_GET['modulo']!='eva_index' && $_GET['acao']!='chmod')
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho']);
		//echo getcwd();
		//chdir("../");
		if(trim($diretorio) == ""){
			return false;
		}
		// verify if the folder exists
		$folders=explode("/",$diretorio);
		$pasta="";
		$valor=false;
		$valor2=true;
		
		for($i=0;$i<count($folders);$i++){
			$pasta.=(trim($folders[$i]))?($folders[$i]."/"):"";
			if(is_dir($pasta)){
				//echo "<br>".$pasta."<br>";
				if(is_writable($pasta)){
					$valor=true;
				}					
				if(@chmod($diretorio, $permissao)){
					$valor=true;
				}
			}else{
				$valor2=$valor=(@mkdir($pasta, $permissao) && $valor2)?true:false;
			}
		}	
		//if(!eregi("^{$eva['caminho']}", $diretorio))
			//@chdir($eva['caminho_eva']);
		return $valor;
	} //verificar_diretorio
	
	/**
	* Verifica o tamanho de um diret�rio
	* @param string Pasta a ser analisada
	* @return string Tamanho total, em bytes, dos arquivos e subpastas
	*/	
	function tamanho_diretorio($diretorio){
		global $eva;
		$tamanho = 0;
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho']);
		if ($handle = @opendir($diretorio)) {		
			while (false !== ($file = readdir($handle))) {
				if ($file != "." && $file != "..") {
					if(is_dir($diretorio."/".$file)){
						$tamanho += $this->tamanho_diretorio($diretorio."/".$file);
					}else{
						$tamanho += @filesize($diretorio."/".$file);
					}
				}
			}
		}else{
			$tamanho = 0;
		}
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho_eva']);
		return $tamanho;
	} //tamanho_diretorio
	
	/**
	* Apaga um diret�rio
	* @param string Pasta a ser apagada
	* @return bolean True ou false
		
	function apagar_diretorio($diretorio){
		global $eva;
		$apagar = true;
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho']);
		if ($handle = opendir($diretorio)) {		
			while(false !== ($arquivo = readdir($handle))) {echo __LINE__." {$arquivo}\n";
				if ($arquivo != "." && $arquivo != "..") {
					if(is_dir($diretorio."/".$arquivo)){
						$apagar = $this->apagar_diretorio($diretorio."/".$arquivo);
						@chmod($this->diretorio.$arquivo,0777);
						$apagar = @rmdir($this->diretorio.$arquivo);
					}else{
						$apagar = @chmod($this->diretorio.$arquivo,0777);
						$apagar = @unlink($this->diretorio.$arquivo);
					}
				}
				//if(!$apagar) return $apagar;
			}
			$apagar = @rmdir($this->diretorio);
		}
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho_eva']);
		return $apagar;
	}// apagar_diretorio*/
	
	/**
	* Delete a file, or a folder and its contents
	*
	* @author      Aidan Lister <aidan@php.net>
	* @version     1.0.3
	* @link        http://aidanlister.com/repos/v/function.rmdirr.php
	* @param       string   $diretorio    Directory to delete
	* @return      bool     Returns TRUE on success, FALSE on failure
	*/	
	function apagar_diretorio($diretorio){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho']);
		// Sanity check
		if (!file_exists($diretorio)) {
			return false;
		}
		
		// Simple delete for a file
		if (is_file($diretorio) || is_link($diretorio)) {
			return unlink($diretorio);
		}
		
		// Loop through the folder
		$dir = dir($diretorio);
		while (false !== $entry = $dir->read()) {
			// Skip pointers
			if ($entry == '.' || $entry == '..') {
				continue;
			}
		
			// Recurse
			$this->apagar_diretorio($diretorio . DIRECTORY_SEPARATOR . $entry);
		}
		
		// Clean up
		$dir->close();
		$r = rmdir($diretorio);
		if(!eregi("^{$eva['caminho']}", $diretorio))
			@chdir($eva['caminho_eva']);
		return $r;
	}// apagar_diretorio
	
	/**
	* Remove espa�os, quebras de linha e coment�rios
	* @param string Codigo html
	*/	
	function retirar_espacos(&$exibir){
		// Retira comentarios com // e espa�os
		//$pattern="/(\/\*[^\/]*\*\/)|([^:]\/\/[^\r\n]+)|([\r\t\n\s]+)/";
		//$pattern="/(\/\*[^\/]*\*\/)/";
		//$pattern="/([^:]\/\/[^\r\n]+)|([\r\t\n\s]+)/";
		$pattern = "/([\r\t\n\s]+)/";
		if(!is_array($exibir)){
			$exibir = preg_replace($pattern," ",$exibir);
		}else{
			while (list($key, $value) = each($exibir)) {
				$exibir[$key] = preg_replace($pattern," ",$value);
			}
		}
	} //retirar_espacos
	
	/**
	* Recebe arquivos enviados atrav�s de m�todo POST e armazena no servidor
	* @param string Nome do campo de arquivos enviado via POST, o POST deve ser um array
	* @param string Pasta onde o arquivo ser� gravado
	* @param string Tamanho m�ximo de arquivos permitido
	* @param boolean Sobrescrever caso o arquivo j� exista
	* @param string Lista de arquivos permitidos (+) ou n�o (-)
	* @param int Permissao do arquivo a ser gravado
	* @param int Tamanho m�ximo de caracteres para nome de arquivo
	* @return array Vetor contendo nome, tamanho, erro
	*/	
	function gravar_upload($campo, $caminho, $tamanho_limite = 0, $sobrescrever = false, $tipo="", $permissao = 0755, $tamanho_nome_arquivo = 50){
		global $config;
		global $eva;
		$arquivos = $_FILES[$campo];
		$resposta = array();
		$resposta['erro'] = array();
		$resposta['arquivos'] = $arquivos;
		//echo getcwd()."<br>";
		@chdir($eva['caminho']);	
		
		if (!isset($_FILES[$campo]['name']) || count($_FILES[$campo]['name']) <= 0){
			$resposta['erro'][0] = "Error on send file, please verify the file size and the file type and try again.";
			return $resposta;
		}
		
		if (!ereg("/$", $caminho)){
			$caminho = $caminho."/";
		}
		
		if($tipo != ""){
			$tipo_acao = substr($tipo, 0, 1);
			$tipo_lista = explode(";",substr($tipo, 1));
		}else{
			$tipo_acao = "-";
			$tipo_lista = array();
		}
		
		while(list($key,$name) = each($arquivos['name'])){
			if(empty($arquivos['name'][$key])) continue;
			//Verifica a extensao do arquivo
			if (($tipo_acao == "+" && !in_array(substr($arquivos['name'][$key],-3),$tipo_lista)) || ($tipo_acao == "-" && in_array(substr($arquivos['name'][$key],-3),$tipo_lista))){
				if($tipo_acao == "+"){
					$resposta['erro'][$key] = "<br />File type not allowed: <strong><font color=#FF0000>".substr($arquivos['name'][$key],-3)."</font></strong>.<br/> Types allowed: ";
				}else{
					$resposta['erro'][$key] = "<br />File type not allowed: <strong><font color=#FF0000>".substr($arquivos['name'][$key],-3)."</font></strong>.<br/> Types not allowed: ";
				}
				
				foreach($tipo_lista as $tipo_sigla){
					$resposta['erro'][$key] .=  "<strong><font color=#FF0000>".$tipo_sigla."</font></strong>,";
				}
	
			  return $resposta;
			}
			
			// Verifica o tamanho m�ximo do arquivo em bytes
			if($tamanho_limite > 0 && intval($arquivos['size'][$key]) > 0 && ($arquivos['size'][$key] > $tamanho_limite || $arquivos['size'][$key] > intval(ini_get('upload_max_filesize')))){
				$resposta['erro'][$key] =  "File size (".$this->tratar_bytes($arquivos['size'][$key]).") bigger then the allowed limit: ".$this->tratar_bytes($tamanho_limite).".<br/>";   
				return $resposta;
			}
			
			$tipo_arquivo = "";
			$eva['incluir']->incluir("geral");
			// Limpa o nome do arquivo, removendo os acentos e caracteres estranhos
			$arquivo = $eva['geral']->retirar_acentos($name);
			//$arquivo = ereg_replace("[^a-z0-9._]", "",str_replace(" ", "_",str_replace("%20", "_", strtolower($arquivo))));
			$arquivo = str_replace(" ", "_",str_replace("%20", "_", strtolower($arquivo)));
			
			//para tratar tamanho do nome do arquivo
			if ( strlen($arquivo) > $tamanho_nome_arquivo ){
				$array_nome_arquivo = explode(".",$arquivo); // exemplo .pdf
				$extensao = $array_nome_arquivo[count($array_nome_arquivo)-1];
				$arquivo = substr($arquivo,0,($tamanho_nome_arquivo-10)).".".$extensao; //remove dez caracteres e adiciona a extensao ao final
			}
	
			$resposta['arquivos']['original'][$key] = $arquivo;		
			
			if((file_exists($caminho.$arquivo) && $sobrescrever) || (!file_exists($caminho.$arquivo))){
				// se nao existir o diretorio crie um
				$mensagem = $this->verificar_diretorio($caminho);
				if($mensagem !== true){
					$resposta['erro'][$key] =  $mensagem;
					return $resposta;
				}
				//echo $arquivos['tmp_name'][$key]."<br>".$caminho.$arquivo."<hr>";
				if(!move_uploaded_file($arquivos['tmp_name'][$key],$caminho.$arquivo)){
					$resposta['erro'][$key] =  "Error on record file '".$name."' in the folder [".$caminho."].<br/>";
					return $resposta;
				}
				@unlink($arquivos['tmp_name'][$key]);
				chmod($caminho.$arquivo, $permissao);
			}else if ( file_exists($caminho.$arquivo) && $sobrescrever == false) {
				$renomeado = false; 
				$cont = 1;
				//pega - ex.: .doc
				$extensao = substr($arquivo,-4);
				
				//loop para verificar se o arquivo existe no diretorio e renomea-lo
				while($renomeado == false){
					if(file_exists($caminho.$arquivo)){
						//pega o nome antes do ponto
						//$nome = substr($arquivo,0,-4);
						//$arquivo = str_replace(substr($arquivo,-5), ($cont.$extensao));
						preg_match("/(_([0-9]))?(\..{2,4})$/", $arquivo, $x);
						$arquivo = str_replace($x[0], "_".($x[2]+1).$x[3], $arquivo);
						//echo $arquivo;exit;
					}else{
						$renomeado = true;
					}
					$cont++; 
					if($cont == 20) break;
				}
				
				if(!move_uploaded_file($arquivos['tmp_name'][$key],$caminho.$arquivo)){
					$resposta['erro'][$key] =  "Error on record file '".$name."' in the folder [".$caminho."].<br/>";
					return $resposta;
				}
				
				@unlink($arquivos['tmp_name'][$key]);
				chmod($caminho.$arquivo, $permissao);
			}else{
				$resposta['erro'][$key] =  "There is already a filename '".$name."'. Try to send a file with a different name.<br/>";
				return $resposta;
			}
			$resposta['arquivos']['name'][$key] = $arquivo;
		}
		return $resposta;
	} //gravar_upload
		
	/**
	 * Le um arquivo
	 *
	 * @param string $arquivo
	 * @return string
	 */
	function ler($arquivo){
		if(empty($arquivo)) return '';
		global $eva;		
		if(!eregi("^modulos/", $arquivo)){
			if(!eregi("^{$eva['caminho']}", $arquivo)){
				@chdir($eva['caminho']);
			}
		}else{ @chdir($eva['caminho_eva']); }
		//echo getcwd();
		ini_set('allow_url_fopen', '1');
		$f = file_get_contents($arquivo);
		if(!eregi("^modulos/", $arquivo))
			if(!eregi("^{$eva['caminho']}", $arquivo))
				@chdir($eva['caminho_eva']);
		return $f;
	}
	
	/**
	 * Apaga um arquivo
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function apagar($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$x = unlink($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return $x;
	}
	
	/**
	 * Verifica se o arquivo existe
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function existe($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$resp = file_exists($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return($resp);
	}
	
	/**
	 * Inclui
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function eva_include($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$resp = include($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return($resp);
	}
	
	/**
	 * Inclui
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function eva_include_once($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$resp = include_once($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return($resp);
	}
	
	/**
	 * Requer
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function eva_require($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$resp = require($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return($resp);
	}
	
	/**
	 * Requer
	 *
	 * @param string $arquivo
	 * @return boolean
	 */
	function eva_require_once($arquivo){
		global $eva;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);
		$resp = require_once($arquivo);
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return($resp);
	}
	
	/**
	 * Copia arquivo
	 *
	 * @param string $arquivo
	 * @param string $arquivo
	 * @return boolean
	 */
	function copiar($arquivo_origem, $arquivo_destino){
		global $eva;	
		$resp = false;
		$diretorio=explode("/",$arquivo_destino);
		unset($diretorio[count($diretorio)-1]);
		$diretorio=implode("/",$diretorio);	
		if($this->verificar_diretorio($diretorio)){	
			@chdir($eva['caminho']);
			$resp = @copy($arquivo_origem, $arquivo_destino);
			@chdir($eva['caminho_eva']);
		}
		return($resp);
	}
	
	/**
	 * Retorna um icone dependendo do tipo do arquivo
	 *
	 * @param string $arquivo
	 * @param string $img_url
	 * @param string $extra
	 * @return string
	 */
	function icone($arquivo, $img_url = false, $extra=""){
		// include
		include_once('extras/FileIcon.inc.php');	
		// get the file
		$file = new FileIcon($arquivo);		
		// print the icon plus some data
		$array = $file->getIcon();
		if(!$img_url)
			return '<img src="'.$file->url.$array[0].'.gif" alt="'.$array[1].'" border="0" hspace="3" vspace="3" {$extra} />';
		else
			return $file->url.$array[0].'.gif';
	}
	
	/**
	 * Cria um arquivo zip com varios arquivos
	 *
	 * @param array $arquivos
	 * @return buffer
	 */
	function zip($arquivos = array()){
		if(empty($arquivos)) return false;
		// include
		include_once('extras/createzip.inc.php');	
		$createZip = new createZip;	
		for($i=0;$i<count($arquivos);$i++){	
			if(is_array($arquivos[$i])){
				$path = $arquivos[$i]['path'];
				$nome = $arquivos[$i]['nome'];
			}else{
				$path = $arquivos[$i];
				$nome = explode("/", $arquivos[$i]);
				$nome = end($nome);
			}	
			$fileContents = $this->ler($path); 
			$createZip->addFile($fileContents, $nome); 	
		}
		return $createZip->getZippedfile();
	}
	
	/**
	 * Cria um nome valido para um arquivo
	 *
	 * @param string $nome
	 * @param string $extensao
	 * @return string
	 */
	function nome_de_arquivo($nome, $extensao=""){
		global $eva;
		$eva['incluir']->incluir("geral");
		if(empty($nome)){
			$nome = mktime();
		}else{
			$nome = substr(ereg_replace("[^A-Za-z0-9]","",$eva['geral']->retirar_acentos($nome)), 0, 50);
		}
		return $nome.(!empty($extensao)?".".$extensao:"");
	}
	
	/**
	 * Retorna o tamanho formatado de um arquivo
	 *
	 * @param string $arquivo
	 * @return string
	 */
	function tamanho($arquivo){
		global $eva;
		return $this->tratar_bytes(filesize(!eregi("^".$eva['caminho'], $arquivo)?($eva['caminho']."/".$arquivo):$arquivo));
	}
	
	/**
	 * retorna um link para download do arquivo ou para visualizar o arquivo
	 *
	 * @param string $arquivo
	 * @param string $nome
	 * @param int $download; $download = 1 force download, $download = 0 open, $download = -1 open if is image else download
	 * @param string $modelo; 
	 * @return string
	 */
	function link_download($arquivo, $nome="", $download=-1, $modelo=""){ 
		// $download = 1 force download
		// $download = 0 open
		// $download = -1 open if is image or HTML
		global $eva;
		if(empty($nome)){
			$nome = explode("/" , $arquivo);
			$nome = end($nome);
		}
		if($download<0){			
			$eva['incluir']->incluir("img");
			$download=($eva['img']->is_image($arquivo)||$eva['img']->is_html($arquivo))?0:1;
		}
		if(!empty($modelo)){
			$modelo = "&modelo={$modelo}";
		}
		if(!$this->existe($arquivo)) return 0;
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho']);			
		$link = "index.php?comando=arquivo&comando_tipo=arquivo&arquivo_path={$arquivo}&arquivo_nome={$nome}&ctype=".$this->mime_get_type($arquivo)."&download={$download}{$modelo}";
		if(!eregi("^{$eva['caminho']}", $arquivo))
			@chdir($eva['caminho_eva']);
		return $link;
	}
	
	/**
	 * retorna um icone com o nome e o link para download do arquivo ou para visualizar o arquivo
	 *
	 * @param string $arquivo
	 * @param string $resizedImageName
	 * @param int $newWidth
	 * @param int $newHeight
	 * @param boolean $overwrite
	 * @param string $nome caso fique em branco aparece o nome do arquivo
	 * @param int $download; $download = 1 force download, $download = 0 open, $download = -1 open if is image else download
	 * @param string $modelo; 
	 * @return string
	 */
	function icone_download($arquivo, $resizedImageName, $newWidth, $newHeight, $overwrite = true, $nome="", $download=-1, $modelo=""){ 
		global $eva;
		if(empty($nome)){
			$nome = explode("/" , $arquivo);
			$nome = end($nome);
		}
		$eva['incluir']->incluir("img");
		// $download = 1 force download
		// $download = 0 open
		// $download = -1 open if is image or HTML
		$r = $eva['img']->resize_img($arquivo, $resizedImageName, $newWidth, $newHeight, $overwrite);
		$href = $this->link_download($arquivo, $nome, $download, $modelo);
		$target = "";
		if($eva['img']->is_image($arquivo))
			$target = "target='_blank'";
		$r .= "<a href='{$href}' {$target}>{$nome}</a>";
		return $r;
	}
	
	/**
	 * Se for uma imagem abre uma nova janela com js, se for um arquivo cria um link <a> para a mesma janela
	 *
	 * @param string $arquivo
	 * @param string $nome
	 * @param int $download; $download = 1 force download, $download = 0 open, $download = -1 open if is image else download
	 * @param string $modelo; 
	 * @param string $conteudo; HTML do conteudo
	 * @return string
	 */
	function file_open($arquivo, $nome="", $download=-1, $modelo="", $conteudo=""){ 
		if(empty($arquivo)) return "";
		global $eva;		
		$eva['incluir']->incluir("img");
		$link = $this->link_download($arquivo, $nome, $download, $modelo);
		if(!$eva['img']->is_image($arquivo) && !$eva['img']->is_html($arquivo)){
			return "<a href=\"{$link}\" >{$conteudo}</a>";
		}else{
			return "<a onMouseover=\"this.style.cursor=eva_mouseover;\" onClick=\"window.open('{$link}','','toolbar=no,
location=no,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,
resizable=yes');\" >{$conteudo}</a>";
		}
	}
	
	
	/* Functions for working with mimetypes.
	 *
	 * Written by: Chris Studholme
	 * Copyright:  GPL (http://www.fsf.org/copyleft/gpl.html)
	 * $Id: eva_arquivo.php,v 1.1 2007/05/02 15:23:08 danielosneto Exp $
	 */
	/* Return array of known (popular, interesting) mime types.
	 */
	function mime_known_types() {
	  return array("application/x-gtar", // gzipped tar file containing images
			   "application/x-tar",  // tar file containing images
			   "application/zip",    // zip file containing images
			   "image/gif",          // gif image; animated or not
			   "image/jpeg",         // jpeg image
			   "image/png",          // png image
			   "image/tiff",         // tiff image
			   "image/x-kdc",        // Kodak Digital Camera image
			   "image/x-pcd",        // Kodak PhotoCD image
			   "video/mpeg",         // mpeg video file
			   "video/x-mng",        // multi-image png file
			   );
	}
	
	
	/* Check that $mt is (syntactically) a valid mimetype.
	 */
	function mime_valid_type($mt) {
	  $categories = array("application",
				  "audio",
				  "chemical",
				  "image",
				  "inode",
				  "message",
				  "model",
				  "multipart",
				  "text",
				  "video",
				  );
	  if (!ereg("^([a-z][a-z]*)/([0-9A-Za-z][0-9A-Za-z.+-]*)$",$mt,$regs))
		return false;
	  if (!in_array($regs[1],$categories))
		return false;
	  return true;
	}
	
	// figure out mime type using GetImageSize() function
	function mime_get_type_GetImageSize($filename) {
	  $type_mapping = 
		array("1"=>"image/gif",
		  "2"=>"image/jpeg",
		  "3"=>"image/png",
		  "4"=>"application/x-shockwave-flash",
		  //"5"=>"PSD",
		  "6"=>"image/bmp");
	  @$size = GetImageSize($filename);
	  if (!empty($size[2])&&!empty($type_mapping[$size[2]]))
		return $type_mapping[$size[2]];
	  return false;
	}
	
	// figure out mime type from file data using /etc/mime-magic
	function mime_get_type_etc_mime_magic($filename) {
	  if (filesize($filename)<=0)
		return false;
	  // WORK NEEDED HERE!
	  return false;
	}
	
	// figure out mime type from filename extension using /etc/mime.types
	function mime_get_type_etc_mime_types($filename) {
	  // WORK NEEDED HERE!
	  return false;
	}
	
	// figure out mime type from filename using built-in table
	function mime_get_type_builtin($filename) {
	  $extensions = array(
			'ez'        => 'application/andrew-inset',
			'hqx'        => 'application/mac-binhex40',
			'cpt'        => 'application/mac-compactpro',
			'doc'        => 'application/msword',
			'bin'        => 'application/octet-stream',
			'dms'        => 'application/octet-stream',
			'lha'        => 'application/octet-stream',
			'lzh'        => 'application/octet-stream',
			'exe'        => 'application/octet-stream',
			'class'        => 'application/octet-stream',
			'so'        => 'application/octet-stream',
			'dll'        => 'application/octet-stream',
			'oda'        => 'application/oda',
			'pdf'        => 'application/pdf',
			'ai'        => 'application/postscript',
			'eps'        => 'application/postscript',
			'ps'        => 'application/postscript',
			'smi'        => 'application/smil',
			'smil'        => 'application/smil',
			'mif'        => 'application/vnd.mif',
			'xls'        => 'application/vnd.ms-excel',
			'ppt'        => 'application/vnd.ms-powerpoint',
			'wbxml'        => 'application/vnd.wap.wbxml',
			'wmlc'        => 'application/vnd.wap.wmlc',
			'wmlsc'        => 'application/vnd.wap.wmlscriptc',
			'bcpio'        => 'application/x-bcpio',
			'vcd'        => 'application/x-cdlink',
			'pgn'        => 'application/x-chess-pgn',
			'cpio'        => 'application/x-cpio',
			'csh'        => 'application/x-csh',
			'dcr'        => 'application/x-director',
			'dir'        => 'application/x-director',
			'dxr'        => 'application/x-director',
			'dvi'        => 'application/x-dvi',
			'spl'        => 'application/x-futuresplash',
			'gtar'        => 'application/x-gtar',
			'hdf'        => 'application/x-hdf',
			'js'        => 'application/x-javascript',
			'skp'        => 'application/x-koan',
			'skd'        => 'application/x-koan',
			'skt'        => 'application/x-koan',
			'skm'        => 'application/x-koan',
			'latex'        => 'application/x-latex',
			'nc'        => 'application/x-netcdf',
			'cdf'        => 'application/x-netcdf',
			'sh'        => 'application/x-sh',
			'shar'        => 'application/x-shar',
			'swf'        => 'application/x-shockwave-flash',
			'sit'        => 'application/x-stuffit',
			'sv4cpio'    => 'application/x-sv4cpio',
			'sv4crc'    => 'application/x-sv4crc',
			'tar'        => 'application/x-tar',
			'tcl'        => 'application/x-tcl',
			'tex'        => 'application/x-tex',
			'texinfo'    => 'application/x-texinfo',
			'texi'        => 'application/x-texinfo',
			't'            => 'application/x-troff',
			'tr'        => 'application/x-troff',
			'roff'        => 'application/x-troff',
			'man'        => 'application/x-troff-man',
			'me'        => 'application/x-troff-me',
			'ms'        => 'application/x-troff-ms',
			'ustar'        => 'application/x-ustar',
			'src'        => 'application/x-wais-source',
			'xhtml'        => 'application/xhtml+xml',
			'xht'        => 'application/xhtml+xml',
			'zip'        => 'application/zip',
			'au'        => 'audio/basic',
			'snd'        => 'audio/basic',
			'mid'        => 'audio/midi',
			'midi'        => 'audio/midi',
			'kar'        => 'audio/midi',
			'mpga'        => 'audio/mpeg',
			'mp2'        => 'audio/mpeg',
			'mp3'        => 'audio/mpeg',
			'aif'        => 'audio/x-aiff',
			'aiff'        => 'audio/x-aiff',
			'aifc'        => 'audio/x-aiff',
			'm3u'        => 'audio/x-mpegurl',
			'ram'        => 'audio/x-pn-realaudio',
			'rm'        => 'audio/x-pn-realaudio',
			'rpm'        => 'audio/x-pn-realaudio-plugin',
			'ra'        => 'audio/x-realaudio',
			'wav'        => 'audio/x-wav',
			'pdb'        => 'chemical/x-pdb',
			'xyz'        => 'chemical/x-xyz',
			'bmp'        => 'image/bmp',
			'gif'        => 'image/gif',
			'ief'        => 'image/ief',
			'jpeg'        => 'image/jpeg',
			'jpg'        => 'image/jpeg',
			'jpe'        => 'image/jpeg',
			'png'        => 'image/png',
			'tiff'        => 'image/tiff',
			'tif'        => 'image/tiff',
			'djvu'        => 'image/vnd.djvu',
			'djv'        => 'image/vnd.djvu',
			'wbmp'        => 'image/vnd.wap.wbmp',
			'ras'        => 'image/x-cmu-raster',
			'pnm'        => 'image/x-portable-anymap',
			'pbm'        => 'image/x-portable-bitmap',
			'pgm'        => 'image/x-portable-graymap',
			'ppm'        => 'image/x-portable-pixmap',
			'rgb'        => 'image/x-rgb',
			'xbm'        => 'image/x-xbitmap',
			'xpm'        => 'image/x-xpixmap',
			'xwd'        => 'image/x-xwindowdump',
			'igs'        => 'model/iges',
			'iges'        => 'model/iges',
			'msh'        => 'model/mesh',
			'mesh'        => 'model/mesh',
			'silo'        => 'model/mesh',
			'wrl'        => 'model/vrml',
			'vrml'        => 'model/vrml',
			'css'        => 'text/css',
			'html'        => 'text/html',
			'htm'        => 'text/html',
			'asc'        => 'text/plain',
			'txt'        => 'text/plain',
			'rtx'        => 'text/richtext',
			'rtf'        => 'text/rtf',
			'sgml'        => 'text/sgml',
			'sgm'        => 'text/sgml',
			'tsv'        => 'text/tab-separated-values',
			'wml'        => 'text/vnd.wap.wml',
			'wmls'        => 'text/vnd.wap.wmlscript',
			'etx'        => 'text/x-setext',
			'xsl'        => 'text/xml',
			'xml'        => 'text/xml',
			'mpeg'        => 'video/mpeg',
			'mpg'        => 'video/mpeg',
			'mpe'        => 'video/mpeg',
			'qt'        => 'video/quicktime',
			'mov'        => 'video/quicktime',
			'mxu'        => 'video/vnd.mpegurl',
			'avi'        => 'video/x-msvideo',
			'movie'        => 'video/x-sgi-movie',
			'ice'        => 'x-conference/x-cooltalk',
		);
	  reset($extensions);
	  while (list($ext,$mt)=each($extensions))
		if (eregi("[.]".$ext."$",$filename))
		  return $mt;
	  return false;
	}
	
	// determine if mime type should be specialized
	function mime_get_type_specialize($mt) {
	  if ($mt=="image/tiff") {
		// check for image/x-kdc
	  }
	  return $mt;
	}
	
	
	/* Determine the mime type of the specified file by any means possible.
	 */
	function mime_get_type($filename) {
	  // verify that the file exists and is readable
	  if (!is_readable($filename))
		return false;
	
	  // try the php GetImageSize() function
	  $mt = $this->mime_get_type_GetImageSize($filename);
	  if ($mt) return $this->mime_get_type_specialize($mt);
	
	  // try the /etc/mime-magic file (if it exists)
	  $mt = $this->mime_get_type_etc_mime_magic($filename);
	  if ($mt) return $this->mime_get_type_specialize($mt);
	
	  // try the /etc/mime.types file (if it exists)
	  $mt = $this->mime_get_type_etc_mime_types($filename);
	  if ($mt) return $this->mime_get_type_specialize($mt);
	
	  // use the built-in mime type table
	  $mt = $this->mime_get_type_builtin($filename);
	  if ($mt) return $this->mime_get_type_specialize($mt);
	
	  // failed
	  return false;
	}
	
	function eva_eval($content) {
		global $eva;
		$before = ob_get_contents();
		@ob_end_clean();
		eval($content);
		$content = ob_get_contents();
		@ob_end_clean();
		echo $before;
		$eva['seguranca']->inicia_ob_start();
		return $content;
	}
	
} //eva_arquivo
?>
