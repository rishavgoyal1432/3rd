<?php

/*	

+-----------------------------------------------------------------------------+

| EVA - Sistema Gerenciador de Conte�do                                       |

| Copyright (c) 2004 EVA CMS (www.evacms.com.br)                              |

+-----------------------------------------------------------------------------+

| Este programa � de c�digo livre e pode ser redistribu�do ou modificado      |

| sob os termos da GNU General Public License como publicado pela Free        |

| Software Foundation; segundo a vers�o 2 da licen�a ou vers�o atualizada.    |

+-----------------------------------------------------------------------------+

| PHP vers�o 4.3.7                                                            |

+-----------------------------------------------------------------------------+

| M�dulo: Usu�rio                                                             |

| Descri��o: Sistema indispens�vel para o eva onde o mesmo gerencia os        |

| usu�rios e grupos do sistema                                                |

| Data de Cria��o: Setembro de 2004                                           |

| Autores:                                                                    |

| - Alessandro Nunes (alessandro@evacms.com.br, alessandro.rpgrock.net)       |

| - Daniel Neto (daniel@evacms.com.br, www.danielneto.com)                    |

+-----------------------------------------------------------------------------+

| Arquivo: br.php                                                             |

| Descri��o: Arquivo do idioma portugu�s para a biblioteca de funcoes         |

+-----------------------------------------------------------------------------+

| Data de Modifica��o: 30/08/2004                                             |

| Colaboradores:                                                              |

+-----------------------------------------------------------------------------+

*/

?><?php
global $idioma;

$idioma['idioma']="Language";



$idioma['sim']="Yes";

$idioma['nao']="No";

$idioma['sempre']="Allways";

$idioma['nunca']="Never";

$idioma['de']="of";

$idioma['do']="of";

$idioma['da']="of";

$idioma['para']="to";

$idioma['em']="in";

$idioma['por']="by";



// A��es para formul�rios

$idioma['formulario']="Form";

$idioma['novo']="New";

$idioma['nova']="New";

$idioma['ativo']="Active";

$idioma['inativo']="Inactive";

$idioma['cadastrar']="Register";

$idioma['apagar']="Delete";

$idioma['abrir']="Open";

$idioma['fechar']="Close";

$idioma['limpar']="Clean";

$idioma['recarregar']="Reload";

$idioma['listar']="List";

$idioma['buscar'] = "Search";

$idioma['verificar']="Verify";

$idioma['editar']="Edit";

$idioma["salvar"]="Save";

$idioma['alterar']="Change";

$idioma['adicionar']="Add";

$idioma['remover']="Remove";

$idioma['cancelar']="Cancel";

$idioma['confirmar']="Confirm";

$idioma['ler'] = "Read";

$idioma['ver'] = "See";

$idioma['responder'] = "Reply";

$idioma['encaminhar'] = "Forward";

$idioma['exibir']="Show";

$idioma['enviar']="Send";

$idioma['ativar']="Enable";

$idioma['desativar']="Disable";

$idioma['instalar']="Install";

$idioma['desinstalar']="Uninstall";

$idioma['inicio']="Begin";

$idioma['fim']="End";

$idioma['avancar']="Forward";

$idioma['voltar']="Back";

$idioma['primeiro']="First";

$idioma['ultimo']="Last";

$idioma['proximo']="Next";

$idioma['anterior']="Previous";

$idioma['opcoes']="Options";

$idioma['total']="Total";

$idioma['blocos']="Blocks";

$idioma['modulos']="Modules";

$idioma['sites']="Sites";

$idioma['site']="Site";

$idioma['codigo']="ID";

$idioma['numero']="Number";

$idioma['dados']="Data";

$idioma['data']="Date";

$idioma['entre']="Between";

$idioma['anterior_a']="Before";

$idioma['apos']="After";



$idioma['operacao_sucesso'] = "Operation Successfull!";

$idioma['operacao_falha'] = "Operation fail.";



$idioma['erro_verificar_diretorio'] = "Fail trying to access folder. Please create the folder \'{pasta}\' with read and write permissions or contact the system administrator.";



$idioma['secao']="Section";

$idioma['secoes']="Sections";

$idioma['nao_enviar'] = "Don't send";

$idioma['enviar_link'] = "Send link";

$idioma['enviar_texto'] = "Send full text";

$idioma['usuario_escolhe'] = "User choose";

$idioma['exibir_enviar'] = "Send to a friend";

$idioma['exibir_imprimir'] = "Print friendly";

$idioma['imprimir'] = "Print";

$idioma['exibir_data'] = "Show date";

$idioma['ordenar_conteudo_por'] = "Order content by";

$idioma['exibir_desc'] = "Show description";

$idioma['esquerda'] = "Left";

$idioma['direita'] = "Right";

$idioma['centralizado'] = "Center";

$idioma['justificado'] = "Justify";

$idioma['secao_pai'] = "Upper";

$idioma['topo'] = "Top";

$idioma['imagem_secao'] = "Image";

$idioma['nome']="Name";

$idioma['alinhamento']="Alignment";

$idioma['exibir_conteudo']="Show in content";

$idioma['permissoes_grupos']="Permissions for groups";

$idioma['todos_usuarios']="All users";

$idioma['todos']="All";

$idioma['visitantes']="Visitors";

$idioma['visitante']="Visitor";

$idioma['usuarios']="Users";

$idioma['usuario']="User";

$idioma['administradores']="Administrators";

$idioma['administrador']="Administrator";

$idioma['contatos_online']="Online Contacts";

$idioma['nova_secao']="New";

$idioma['listar_secoes']="List";

$idioma['nenhuma_secao_encontrada'] = "No item founded";

$idioma['selecione_secao'] = "Select";



$idioma['erro'] = "Error";

$idioma['sem_erros'] = "No error founded";

$idioma['exibir_erros']="Show error";

$idioma['erro_desc'] = "An error occurred while executing this script. Please contact the <a href=mailto:webmaster@somedomain.com>webmaster</a> to report this error.";

$idioma['erro_informacoes'] = "Here is the information provided by the script";

$idioma['erro_codigo'] = "Error code";

$idioma['erro_mensagem'] = "Error message";

$idioma['erro_linha'] = "Script name and line number of error";

$idioma['erro_arquivo'] = "File";

$idioma['erro_linha'] = "Line";

$idioma['erro_variaveis'] = "Variable state when error occurred";

$idioma['configurar_blocos'] = "Blocks Settings";

$idioma['pagina_criada'] = "Page generated in";

$idioma['segundos'] = "seconds";



$idioma['codigo_fonte']="Source code";



$idioma['abrir_todos'] = "Open all";

$idioma['fechar_todos'] = "Close all";

$idioma['selecionar_todos'] = "Select all";



$idioma['editar_ajuda_modulo']="Edit help for this module";

$idioma['ajuda']="Help";



$idioma['padrao']="Default";

$idioma['vazio']="Empty";



$idioma['avancar']="Forward";

$idioma['voltar']="Back";

$idioma['atualizar']="Reload";



$idioma['pagina']="Page";

$idioma['carregando']="Loading...";

$idioma['nenhum_item']="No data found";

$idioma['sem_permissao']="No access to this module.";

$idioma['erros_encontrados'] = "Os seguintes erros foram encontrados nas informa��es enviadas";

$idioma['erro_site']="No site found. Please contact the system administrator or verify the EVA cms instalation.";



$idioma['deseja']="Do you wanna";

$idioma['o_bloco']="the block";

$idioma['o_modulo']="the module";

$idioma['clique_arraste'] = "Drag and drop to change block position";



$idioma['sentido'] = "Direction";

$idioma['vertical'] = "Vertical";

$idioma['horizontal'] = "Horizontal";

$idioma['estilo_css'] = "Class (CSS)";



$idioma['alerta_caracteres'] = "Your message should not have more than";

$idioma['caracteres'] = "characters";

$idioma['caracteres_digitados'] = "Characters typed";

$idioma['maximo'] = "Max";

$idioma['digite_msg'] = "Type a message";

$idioma['digite_assunto'] = "Type a subject";

$idioma['titulo'] = "Title";

$idioma['nome'] = "Name";

$idioma['texto'] = "Text";

$idioma['mensagem'] = "Message";

$idioma['assunto'] = "Subject";



$idioma['deseja_prosseguir'] = "Do you really want to proceed?\\nAll data will be lost";

$idioma['tem_certeza'] = "Do you really want to proceed?";

$idioma['confirma_apagar'] = "Do you wish to delete selected item?";

$idioma['confirma_fechar'] = "Do you wish to close selected item?";





// Calendar

$idioma['dia_domingo'] = "Sunday";

$idioma['dia_segunda'] = "Monday";

$idioma['dia_terca'] = "Tuesday";

$idioma['dia_quarta'] = "Wednesday";

$idioma['dia_quinta'] = "Thursday";

$idioma['dia_sexta'] = "Friday";

$idioma['dia_sabado'] = "Saturday";

$idioma['dia_domingo'] = "Sunday";



$idioma['dia_domingo_menor'] = "Sun";

$idioma['dia_segunda_menor'] = "Mon";

$idioma['dia_terca_menor'] = "Tue";

$idioma['dia_quarta_menor'] = "Wed";

$idioma['dia_quinta_menor'] = "Thu";

$idioma['dia_sexta_menor'] = "Fri";

$idioma['dia_sabado_menor'] = "Sat";

$idioma['dia_domingo_menor'] = "Sun";

 

$idioma['mes_janeiro'] = "January";

$idioma['mes_fevereiro'] = "February";

$idioma['mes_marco'] = "March";

$idioma['mes_abril'] = "April";

$idioma['mes_maio'] =  "May";

$idioma['mes_junho'] = "June";

$idioma['mes_julho'] = "July";

$idioma['mes_agosto'] = "August";

$idioma['mes_setembro'] = "September";

$idioma['mes_outubro'] = "October";

$idioma['mes_novembro'] = "November";

$idioma['mes_dezembro'] = "December";



$idioma['mes_janeiro_menor'] = "Jan";

$idioma['mes_fevereiro_menor'] = "Feb";

$idioma['mes_marco_menor'] = "Mar";

$idioma['mes_abril_menor'] = "Apr";

$idioma['mes_maio_menor'] = "May";

$idioma['mes_junho_menor'] = "Jun";

$idioma['mes_julho_menor'] = "Jul";

$idioma['mes_agosto_menor'] = "Aug";

$idioma['mes_setembro_menor'] = "Sep";

$idioma['mes_outubro_menor'] = "Oct";

$idioma['mes_novembro_menor'] = "Nov";

$idioma['mes_dezembro_menor'] = "Dec";



$idioma['info_calendario'] = "About the calendar";

$idioma['sobre_calendario'] = "DHTML Date/Time Selector\\n 

(c) dynarch.com 2002-2005 / Author: Mihai Bazon\\n 

For latest version visit: http://www.dynarch.com/projects/calendar/\\n 

Distributed under GNU LGPL.  See http://gnu.org/licenses/lgpl.html for details. 

\\n\\n 

Date selection:\\n 

- Use the \xab, \xbb buttons to select year\\n 

- Use the \" + String.fromCharCode(0x2039) + \", \" + String.fromCharCode(0x203a) + \" buttons to select month\\n 

- Hold mouse button on any of the above buttons for faster selection.";



$idioma['sobre_hora'] = "\\n\\n 

Time selection:\\n 

- Click on any of the time parts to increase it\\n 

- or Shift-click to decrease it\\n 

- or click and drag for faster selection.";



$idioma['ano_anterior'] = "Prev. year (hold for menu)";

$idioma['mes_anterior'] = "Prev. month (hold for menu)";

$idioma['data_atual'] = "Go Today";

$idioma['proximo_mes'] = "Next month (hold for menu)";

$idioma['proximo_ano'] = "Next year (hold for menu)";

$idioma['selecione_data'] = "Select date";

$idioma['clique_para_mover'] = "Drag to move";

$idioma['dia_hoje'] = " (today)";

$idioma['exibir_primeiro'] = "Display %s first";



// Inicio ne fim da semana -> 0 = domingo, 6 = sabado

$idioma['semana_inicio'] = "0,6";



$idioma['hoje'] =  "Today";

$idioma['mudar_hora'] = "(Shift-)Click or drag to change value";



// date formats

$idioma['formato_data_calendar'] = "%Y-%m-%d";
$idioma['formato_data_desc_calendar'] = "%a, %b %e";

if(file_exists($eva['caminho'].'/arquivos/config.php')){
	include_once($eva['caminho'].'/arquivos/config.php');
	$idioma['formato_data_e_seg_mktime'] = $config['formato_data'];
	$d = explode(" ", $config['formato_data']);
	$idioma['formato_data_mktime'] = $d[0];
}


$idioma['semana_menor'] = "wk";

$idioma['hora'] = "Time:";



$idioma["mais"]="More";

$idioma["menos"]="Less";



$idioma["enviar_email"]="Send Email";

$idioma["enviar_mensagem"]="Send Message";

$idioma["editar_usuario"]="Edit User";



$idioma['descricao']="Description";

$idioma['validar_campo']="Please, verify the field: ";

$idioma['recarregar_imagem_validacao']="Reload validation image";



$idioma['validacao_incorreta']="Incorrect validation";



$idioma['grupos']="Groups";

$idioma['arquivo']="File";



$idioma['conectados'] = "Connected";

$idioma['desconectados'] = "Disconnected";



$idioma['avancado'] = "Advanced";



$idioma['eva_item'] = "�tens";

$idioma['it_cod'] = "�tem";

$idioma['it_pai']="Pai";

$idioma['it_se_cod']="Se��o";

$idioma['it_si_cod']="Sites";

$idioma['it_nome']="Nome";

$idioma['it_desc']="Descri��o";

$idioma['it_autor']="Autor";

$idioma['it_data_criacao']="Data";

$idioma['it_data_publicacao']="Data de publica��o";

$idioma['it_data_validade']="Data de validade";

$idioma['it_data_modificacao']="Data de modifica��o";

$idioma['it_us_cod_criacao']="Criado por";

$idioma['it_us_cod_modificacao']="Modificado por";

$idioma['it_situacao']="Situa��o";

$idioma['it_contador']="Acessos";

$idioma['it_grupo']="Grupos";

$idioma['it_mo_cod']="M�dulo";

$idioma['it_texto']="Text";





$idioma['selecionar_it_se_cod']="Select a section";

$idioma['selecionar_it_pai']="Top";



$idioma['cadastre_secao']="Please register a section.";



// Instalar modulos

$idioma['modulo_instalado'] = "Module success installed!";

$idioma['erro_instalar_modulo'] = "Error on try to install module.";

$idioma['erro_permissoes'] = "Error on create group permissions.";

$idioma['erro_blocos'] = "Error on try to show block permissions.";

$idioma['erro_criar_tabelas'] = "Error on create table.";





$idioma['erro_bd'] = "Error on database conection. Please verify the system instalation or contact the system administrator.";

$idioma['atualizado_sucesso'] = "module successful updated";
$idioma['global_on'] = "Sorry, for security reasons Eva will not work with <strong>register_global = On</strong>, please change your php.ini to <strong>register_global = Off</strong>";

$idioma['base_dn'] = "Base DN";
$idioma['bind_dn'] = "Bind DN";
$idioma['senha_bind'] = "Bind password";
$idioma['filtro'] = "filter";
$idioma['atributo_senha'] = "Password attribute";

$idioma['formato_data']="Date Format";
$idioma['servidor'] = "Server";
$idioma['porta'] = "Port";
$idioma['modulo'] = "Module";
$idioma['grupo'] = "Group";
$idioma['exibe_titulo'] = "Show Title";
$idioma['selecionar_desmarcar_todos'] = "Select/Deselect all";

$idioma['adicionar_novo'] = "Add New";
$idioma['adicionar_novo_editar'] = "Add New/Edit";

$idioma['login_erro']="Invalid User and/or Pass. Please, try again";
$idioma['visitantes_e_usuarios']="Specific Guests and users";
$idioma['dias'] = "Days";
$idioma['dia'] = "Day";
$idioma['minutos'] = 'Minutes';
$idioma['minuto'] = 'Minute';

$idioma['horas'] = 'Hours';
$idioma['hora'] = 'Hour';

?>