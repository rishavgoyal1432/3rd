<?php

/*	

+-----------------------------------------------------------------------------+

| EVA - Sistema Gerenciador de Conte�do                                       |

| Copyright (c) 2004 EVA CMS (www.evacms.com.br)                              |

+-----------------------------------------------------------------------------+

| Este programa � de c�digo livre e pode ser redistribu�do ou modificado      |

| sob os termos da GNU General Public License como publicado pela Free        |

| Software Foundation; segundo a vers�o 2 da licen�a ou vers�o atualizada.    |

+-----------------------------------------------------------------------------+

| PHP vers�o 4.3.7                                                            |

+-----------------------------------------------------------------------------+

| M�dulo: Usu�rio                                                             |

| Descri��o: Sistema indispens�vel para o eva onde o mesmo gerencia os        |

| usu�rios e grupos do sistema                                                |

| Data de Cria��o: Setembro de 2004                                           |

| Autores:                                                                    |

| - Alessandro Nunes (alessandro@evacms.com.br, alessandro.rpgrock.net)       |

| - Daniel Neto (daniel@evacms.com.br, www.danielneto.com)                    |

+-----------------------------------------------------------------------------+

| Arquivo: br.php                                                             |

| Descri��o: Arquivo do idioma portugu�s para a biblioteca de funcoes         |

+-----------------------------------------------------------------------------+

| Data de Modifica��o: 30/08/2004                                             |

| Colaboradores:                                                              |

+-----------------------------------------------------------------------------+

*/

?><?php
global $idioma;

$idioma['idioma']="Idioma";



$idioma['sim']="Sim";

$idioma['nao']="N�o";

$idioma['sempre']="Sempre";

$idioma['nunca']="Nunca";

$idioma['de']="de";

$idioma['do']="do";

$idioma['da']="da";

$idioma['para']="para";

$idioma['em']="em";

$idioma['por']="por";



// A��es para formul�rios

$idioma['formulario']="Formul�rio";

$idioma['novo']="Novo";

$idioma['nova']="Nova";

$idioma['ativo']="Ativo";

$idioma['inativo']="Inativo";

$idioma['cadastrar']="Cadastrar";

$idioma['apagar']="Apagar";

$idioma['abrir']="Abrir";

$idioma['fechar']="Fechar";

$idioma['limpar']="Limpar";

$idioma['recarregar']="Recarregar";

$idioma['listar']="Listar";

$idioma['buscar'] = "Procurar";

$idioma['verificar']="Verificar";

$idioma['editar']="Editar";

$idioma['salvar'] = "Salvar";
$idioma['salvar_novo'] = "Salvar Novo";

$idioma['alterar']="Alterar";

$idioma['adicionar']="Adicionar";

$idioma['remover']="Remover";

$idioma['cancelar']="Cancelar";

$idioma['confirmar']="Confirmar";

$idioma['ler'] = "Ler";

$idioma['ver'] = "Ver";

$idioma['responder'] = "Responder";

$idioma['encaminhar'] = "Encaminhar";

$idioma['exibir']="Exibir";

$idioma['enviar']="Enviar";

$idioma['ativar']="Ativar";

$idioma['desativar']="Desativar";

$idioma['instalar']="Instalar";

$idioma['desinstalar']="Desinstalar";

$idioma['inicio']="Inicio";

$idioma['fim']="Fim";

$idioma['avancar']="Avan�ar";

$idioma['voltar']="Voltar";

$idioma['primeiro']="Primeiro";

$idioma['ultimo']="�ltimo";

$idioma['proximo']="Pr�ximo";

$idioma['anterior']="Anterior";

$idioma['opcoes']="Op��es";

$idioma['total']="Total";

$idioma['blocos']="Blocos";

$idioma['modulos']="M�dulos";

$idioma['sites']="Sites";

$idioma['site']="Site";

$idioma['codigo']="C�digo";

$idioma['numero']="N�mero";

$idioma['dados']="Dados";

$idioma['data']="Data";

$idioma['entre']="Entre";

$idioma['anterior_a']="Anterior a";

$idioma['apos']="Ap�s";





$idioma['operacao_sucesso'] = "Opera��o executada com sucesso!";

$idioma['operacao_falha'] = "Falha ao executar opera��o.";



$idioma['erro_verificar_diretorio'] = "Erro ao acessar a pasta de arquivos. Por favor crie a pasta \'{pasta}\' com permiss�o de escrita e leitura ou entre em contato com o administrador do sistema.";



$idioma['secao']="Se��o";

$idioma['secoes']="Se��es";

$idioma['nao_enviar'] = "N�o enviar";

$idioma['enviar_link'] = "Enviar link";

$idioma['enviar_texto'] = "Enviar texto";

$idioma['usuario_escolhe'] = "O usu�rio escolhe";

$idioma['exibir_enviar'] = "Enviar para um amigo";

$idioma['exibir_imprimir'] = "Vers�o para impress�o";

$idioma['imprimir'] = "Imprimir";

$idioma['exibir_data'] = "Exibir data";

$idioma['ordenar_conteudo_por'] = "Ordenar conte�do por";

$idioma['exibir_desc'] = "Exibir descri��o da se��o";

$idioma['esquerda'] = "Esquerda";

$idioma['direita'] = "Direita";

$idioma['centralizado'] = "Centralizado";

$idioma['justificado'] = "Justificado";

$idioma['secao_pai'] = "Pai";

$idioma['topo'] = "Topo";

$idioma['imagem_secao'] = "Imagem";

$idioma['nome']="Nome";

$idioma['alinhamento']="Alinhamento";

$idioma['exibir_conteudo']="Exibir no conte�do";

$idioma['permissoes_grupos']="Permiss�es para grupos";

$idioma['todos_usuarios']="Todos os usu�rios";

$idioma['todos']="Todos";

$idioma['visitantes']="Visitantes";

$idioma['visitante']="Visitante";

$idioma['usuarios']="Usu�rios";

$idioma['usuario']="Usu�rio";
$idioma['senha']="Senha";

$idioma['administradores']="Administradores";

$idioma['administrador']="Administrador";

$idioma['contatos_online']="Contatos Online";

$idioma['nova_secao']="Nova";

$idioma['listar_secoes']="Listar";

$idioma['nenhuma_secao_encontrada'] = "Nenhum item encontrado";

$idioma['selecione_secao'] = "Selecione";

$idioma['conectado'] = "Conectado";

$idioma['desconectado'] = "Desconectado";



$idioma['erro'] = "Erro";

$idioma['sem_erros'] = "Nenhum erro encontrado";

$idioma['exibir_erros']="Exibir erros";

$idioma['erro_desc'] = "Um erro ocorreu na execu��o deste script. Por favor, entre em contato com o administrador do sistema.";

$idioma['erro_informacoes'] = "Informa��es sobre o erro";

$idioma['erro_codigo'] = "C�digo";

$idioma['erro_mensagem'] = "Mensagem";

$idioma['erro_arquivo'] = "Arquivo";

$idioma['erro_linha'] = "Linha";

$idioma['erro_variaveis'] = "Estado das vari�veis quando o erro ocorreu";

$idioma['configurar_blocos'] = "Configurar Blocos";

$idioma['pagina_criada'] = "P�gina criada em";

$idioma['segundos'] = "segundos";



$idioma['codigo_fonte']="C�digo fonte";



$idioma['abrir_todos'] = "Abrir todos";

$idioma['fechar_todos'] = "Fechar todos";

$idioma['selecionar_todos'] = "Selecionar todos";



$idioma['editar_ajuda_modulo']="Editar ajuda deste m�dulo";

$idioma['ajuda']="Ajuda";



$idioma['padrao']="Padr�o";

$idioma['vazio']="Vazio";



$idioma['avancar']="Avan�ar";

$idioma['voltar']="Voltar";

$idioma['atualizar']="Atualizar";



$idioma['pagina']="P�gina";

$idioma['carregando']="Carregando...";

$idioma['nenhum_item']="Nenhum item encontrado";

$idioma['sem_permissao']="Sem permiss�o para acessar este m�dulo";

$idioma['erros_encontrados']="Os seguintes erros foram encontrados nas informa��es enviadas";

$idioma['erro_site']="Nenhum site encontrado. Por favor entre em contato com o administrador do sistema ou verifique a instala��o do EVA cms.";



$idioma['deseja']="Deseja";

$idioma['o_bloco']="o bloco";

$idioma['o_modulo']="o m�dulo";

$idioma['clique_arraste'] = "Clique e arraste para alterar a posi��o do bloco";



$idioma['sentido'] = "Sentido";

$idioma['vertical'] = "Vertical";

$idioma['horizontal'] = "Horizontal";

$idioma['estilo_css'] = "Classe (Folha de Estilo - CSS)";



$idioma['alerta_caracteres'] = "Sua mensagem deve conter no m�ximo";

$idioma['caracteres'] = "caracteres";

$idioma['caracteres_digitados'] = "Caracteres digitados";

$idioma['maximo'] = "Max";

$idioma['digite_msg'] = "Digite uma mensagem";

$idioma['digite_assunto'] = "Digite um assunto";

$idioma['titulo'] = "Titulo";

$idioma['nome'] = "Nome";

$idioma['texto'] = "Texto";

$idioma['mensagem'] = "Mensagem";

$idioma['assunto'] = "Assunto";



$idioma['deseja_prosseguir'] = "Voc� tem certeza que deseja prosseguir?\\nTodos os dados do formul�rio ser�o perdidos!";

$idioma['tem_certeza'] = "Voc� tem certeza que deseja prosseguir?";

$idioma['confirma_apagar'] = "Deseja realmente excluir o item selecionado?";

$idioma['confirma_fechar'] = "Deseja realmente fechar o item selecionado?";



// Calend�rio

$idioma['dia_domingo'] = "Domingo";

$idioma['dia_segunda'] = "Segunda";

$idioma['dia_terca'] = "Ter�a";

$idioma['dia_quarta'] = "Quarta";

$idioma['dia_quinta'] = "Quinta";

$idioma['dia_sexta'] = "Sexta";

$idioma['dia_sabado'] = "S�bado";

$idioma['dia_domingo'] = "Domingo";



$idioma['dia_domingo_menor'] = "Dom";

$idioma['dia_segunda_menor'] = "Seg";

$idioma['dia_terca_menor'] = "Ter";

$idioma['dia_quarta_menor'] = "Qua";

$idioma['dia_quinta_menor'] = "Qui";

$idioma['dia_sexta_menor'] = "Sex";

$idioma['dia_sabado_menor'] = "Sab";

$idioma['dia_domingo_menor'] = "Dom";



$idioma['mes_janeiro'] = "Janeiro";

$idioma['mes_fevereiro'] = "Fevereiro";

$idioma['mes_marco'] = "Mar�o";

$idioma['mes_abril'] = "Abril";

$idioma['mes_maio'] = "Maio";

$idioma['mes_junho'] = "Junho";

$idioma['mes_julho'] = "Julho";

$idioma['mes_agosto'] = "Agosto";

$idioma['mes_setembro'] = "Setembro";

$idioma['mes_outubro'] = "Outubro";

$idioma['mes_novembro'] = "Novembro";

$idioma['mes_dezembro'] = "Dezembro";



$idioma['mes_janeiro_menor'] = "Jan";

$idioma['mes_fevereiro_menor'] = "Fev";

$idioma['mes_marco_menor'] = "Mar";

$idioma['mes_abril_menor'] = "Abr";

$idioma['mes_maio_menor'] = "Mai";

$idioma['mes_junho_menor'] = "Jun";

$idioma['mes_julho_menor'] = "Jul";

$idioma['mes_agosto_menor'] = "Ago";

$idioma['mes_setembro_menor'] = "Set";

$idioma['mes_outubro_menor'] = "Out";

$idioma['mes_novembro_menor'] = "Nov";

$idioma['mes_dezembro_menor'] = "Dez";



$idioma['info_calendario'] = "Sobre o calend�rio";

$idioma['sobre_calendario'] = "Seletor de Data/Hora DHTML\\n (c) dynarch.com 2002-2005 / Autor: Mihai Bazon / Tradu��o: Alessandro Nunes\\n Para obter a �ltima vers�o visite: http://www.dynarch.com/projects/calendar/\\n Distribu�do sob a licen�a GNU LGPL. Veja http://gnu.org/licenses/lgpl.html para mais detalhes. \\n\\n Sele��o de data:\\n - Utilize os bot�es \xab, \xbb para selecionar o ano\\n - Utilize os bot�es \" + String.fromCharCode(0x2039) + \", \" + String.fromCharCode(0x203a) + \" para selecionar o m�s\\n - Mantenha o bot�o do mouse pressionado sobre qualquer um dos bot�es mencionados para uma sele��o mais r�pida.";



$idioma['sobre_hora'] = "\\n\\n Sele��o de hora:\\n - Clique em qualquer um dos campos da hora para aument�-lo\\n - ou pressione Shift e clique para diminu�-lo\\n - ou clique e arraste para uma sele��o mais r�pida.";



$idioma['ano_anterior'] = "Ano anterior (clique para menu)";

$idioma['mes_anterior'] = "M�s anterior (clique para menu)";

$idioma['data_atual'] = "Ir para a data atual";

$idioma['proximo_mes'] = "Pr�ximo m�s (clique para menu)";

$idioma['proximo_ano'] = "Pr�ximo ano (clique para menu)";

$idioma['selecione_data'] = "Selecione uma data";

$idioma['clique_para_mover'] = "Clique para mover";

$idioma['dia_hoje'] = " (hoje)";

$idioma['exibir_primeiro'] = "Exibir %s primeiro";



// Inicio ne fim da semana -> 0 = domingo, 6 = sabado

$idioma['semana_inicio'] = "0,6";



$idioma['hoje'] = "Hoje";

$idioma['mudar_hora'] = "(Shift-) Clique para mudar o valor";



// date formats

$idioma['formato_data_calendar'] = "%d/%m/%Y";
$idioma['formato_data_desc_calendar'] = "%d de %B de %Y";

if(file_exists($eva['caminho'].'/arquivos/config.php')){
	include_once($eva['caminho'].'/arquivos/config.php');
	$idioma['formato_data_e_seg_mktime'] = $config['formato_data'];
	$d = explode(" ", $config['formato_data']);
	$idioma['formato_data_mktime'] = $d[0];
}


$idioma['semana_menor'] = "sem";

$idioma['hora'] = "Hora:";



$idioma["mais"]="Mais";

$idioma["menos"]="Menos";



$idioma["enviar_email"]="Enviar Email";

$idioma["enviar_mensagem"]="Enviar Mensagem";

$idioma["editar_usuario"]="Editar Usu�rio";





$idioma['eva_secao'] = "Se��es";

$idioma['validar_se_nome'] = "Digite um nome para a se��o";

$idioma['se_nome'] = "Nome";



$idioma['descricao']="Descri��o";

$idioma['validar_campo']="Por favor, preencha corretamente o campo";



$idioma['recarregar_imagem_validacao']="Recarregar imagem de valida��o";



$idioma['validacao_incorreta']="Valida��o incorreta";



$idioma['grupos']="Grupos";

$idioma['arquivo']="Arquivo";



$idioma['conectados'] = "Conectados";

$idioma['desconectados'] = "Desconectados";



$idioma['avancado'] = "Avan�ado";



$idioma['eva_item'] = "�tens";

$idioma['it_cod'] = "�tem";

$idioma['it_pai']="Pai";

$idioma['it_se_cod']="Se��o";

$idioma['it_si_cod']="Sites";

$idioma['it_nome']="Nome";

$idioma['it_desc']="Descri��o";

$idioma['it_autor']="Autor";

$idioma['it_data_criacao']="Data";

$idioma['it_data_publicacao']="Data de publica��o";

$idioma['it_data_validade']="Data de validade";

$idioma['it_data_modificacao']="Data de modifica��o";

$idioma['it_us_cod_criacao']="Criado por";

$idioma['it_us_cod_modificacao']="Modificado por";

$idioma['it_situacao']="Situa��o";

$idioma['it_contador']="Acessos";

$idioma['it_grupo']="Grupos";

$idioma['it_mo_cod']="M�dulo";

$idioma['it_texto']="Texto";





$idioma['selecionar_it_se_cod']="Selecione uma se��o";

$idioma['selecionar_it_pai']="Topo";



$idioma['cadastre_secao']="Por favor cadastre uma se��o.";



// Instalar modulos

$idioma['modulo_instalado'] = "M�dulo instalado com sucesso!";

$idioma['erro_instalar_modulo'] = "Erro ao instalar o m�dulo.";

$idioma['erro_permissoes'] = "Erro ao criar permiss�es de grupos.";

$idioma['erro_blocos'] = "Erro ao tentar exibir blocos neste m�dulo.";

$idioma['erro_criar_tabelas'] = "Erro ao criar tabelas.";

$idioma['erro_bd'] = "Erro ao conectar � base de dados. Por favor, verifique a instala��o do sistema ou entre em contato com o administrador.";

$idioma['atualizado_sucesso'] = "modulo atualizado com sucesso";
$idioma['global_on'] = "Desculpe, por raz�es de seguran�a Eva n�o funcionar� com <strong>register_global = On</strong>, porfavor mude o seu php.ini para <strong>register_global = Off</strong>";

$idioma['base_dn'] = "Base DN";
$idioma['bind_dn'] = "Bind DN";
$idioma['senha_bind'] = "Senha Bind";
$idioma['filtro'] = "filtro";
$idioma['atributo_senha'] = "Atributo da senha";

$idioma['formato_data']="Formato da data";
$idioma['servidor'] = "Servidor";
$idioma['porta'] = "Porta";
$idioma['modulo'] = "M�dulo";
$idioma['grupo'] = "Grupo";
$idioma['exibe_titulo'] = "Exibir titulo";
$idioma['selecionar_desmarcar_todos'] = "Selecionar/Desmarcar Todos";

$idioma['adicionar_novo'] = "Adicionar Novo";
$idioma['adicionar_novo_editar'] = "Adicionar Novo/Editar";

$idioma['login_erro']="Usu�rio e/ou senha inv�lidos. Por favor, verifique os dados digitados e tente novamente";
$idioma['visitantes_e_usuarios']="Visitantes e Usu�rios Espec�ficos";
$idioma['dias'] = "Dias";
$idioma['dia'] = "Dia";
$idioma['minutos'] = 'Minutos';
$idioma['minuto'] = 'Minuto';

$idioma['horas'] = 'Horas';
$idioma['hora'] = 'Hora';
?>