<?php

/*	

+-----------------------------------------------------------------------------+

| EVA - Sistema Gerenciador de Conte�do                                       |

| Copyright (c) 2004 EVA CMS (www.evacms.com.br)                              |

+-----------------------------------------------------------------------------+

| Este programa � de c�digo livre e pode ser redistribu�do ou modificado      |

| sob os termos da GNU General Public License como publicado pela Free        |

| Software Foundation; segundo a vers�o 2 da licen�a ou vers�o atualizada.    |

+-----------------------------------------------------------------------------+

| PHP vers�o 4.3.7                                                            |

+-----------------------------------------------------------------------------+

| M�dulo: Usu�rio                                                             |

| Descri��o: Sistema indispens�vel para o eva onde o mesmo gerencia os        |

| usu�rios e grupos do sistema                                                |

| Data de Cria��o: Setembro de 2004                                           |

| Autores:                                                                    |

| - Alessandro Nunes (alessandro@evacms.com.br, alessandro.rpgrock.net)       |

| - Daniel Neto (daniel@evacms.com.br, www.danielneto.com)                    |

+-----------------------------------------------------------------------------+

| Arquivo: br.php                                                             |

| Descri��o: Arquivo do idioma portugu�s para a biblioteca de funcoes         |

+-----------------------------------------------------------------------------+

| Data de Modifica��o: 30/08/2004                                             |

| Colaboradores:                                                              |

+-----------------------------------------------------------------------------+

*/

?><?php
global $idioma;

$idioma['idioma']="Sprache";



$idioma['sim']="Ja";

$idioma['nao']="Nein";

$idioma['sempre']="Immer";

$idioma['nunca']="Nie";

$idioma['de']="of";

$idioma['do']="of";

$idioma['da']="of";

$idioma['para']="in";

$idioma['em']="in";

$idioma['por']="von";



// A��es para formul�rios

$idioma['formulario']="Formular";

$idioma['novo']="Neu";

$idioma['nova']="Neu";

$idioma['ativo']="Aktiv";

$idioma['inativo']="Inaktiv";

$idioma['cadastrar']="Registrieren";

$idioma['apagar']="L�schen";

$idioma['abrir']="Oeffnen";

$idioma['fechar']="Schlie�en";

$idioma['limpar']="Leeren";

$idioma['recarregar']="Erneut laden";

$idioma['listar']="Liste";

$idioma['buscar'] = "Suche";

$idioma['verificar']="Pr�fen";

$idioma['editar']="Bearbeiten";

$idioma["salvar"]="Speichern";

$idioma['alterar']="Aendern";

$idioma['adicionar']="Hinzuf�gen";

$idioma['remover']="Entfernen";

$idioma['cancelar']="Abbrechen";

$idioma['confirmar']="Bestaetigen";

$idioma['ler'] = "Lesen";

$idioma['ver'] = "Anzeigen";

$idioma['responder'] = "Antworten";

$idioma['encaminhar'] = "Weiterleiten";

$idioma['exibir']="Anzeigen";

$idioma['enviar']="Senden";

$idioma['ativar']="Aktivieren";

$idioma['desativar']="Ausschalten";

$idioma['instalar']="Installieren";

$idioma['desinstalar']="Deinstalieren";

$idioma['inicio']="Anfang";

$idioma['fim']="Ende";

$idioma['avancar']="Vorwaerts";

$idioma['voltar']="Zurueck";

$idioma['primeiro']="Erste";

$idioma['ultimo']="Letzte";

$idioma['proximo']="Naechste";

$idioma['anterior']="Vorherige";

$idioma['opcoes']="Optionen";

$idioma['total']="Gesamt";

$idioma['blocos']="Bloecke";

$idioma['modulos']="Module";

$idioma['sites']="Seiten";

$idioma['site']="Seite";

$idioma['codigo']="ID";

$idioma['numero']="Nummer";

$idioma['dados']="Datum";

$idioma['data']="Daten";

$idioma['entre']="Dazwischen";

$idioma['anterior_a']="Davor";

$idioma['apos']="Danach";



$idioma['operacao_sucesso'] = "Aktion erfolgreich!";

$idioma['operacao_falha'] = "Aktion fehlgeschlagen";



$idioma['erro_verificar_diretorio'] = "Ordner konnte nicht erstellt werden. Bitte erstellen Sie den Ordner \'{pasta}\' mit Lese- und Scheibrechten oder setzen Sie sich mit dem Systemadminsistrator in Verbindung.";



$idioma['secao']="Sektion";

$idioma['secoes']="Sektionen";

$idioma['nao_enviar'] = "Nicht senden";

$idioma['enviar_link'] = "Link senden";

$idioma['enviar_texto'] = "Sende ganzen Text";

$idioma['usuario_escolhe'] = "Benutzer ausw�hlen";

$idioma['exibir_enviar'] = "Einem Freund senden";

$idioma['exibir_imprimir'] = "druckoptimiert";

$idioma['imprimir'] = "Drucken";

$idioma['exibir_data'] = "Datum anzeigen";

$idioma['ordenar_conteudo_por'] = "Ordne nach";

$idioma['exibir_desc'] = "Beschreibung anzeigen";

$idioma['esquerda'] = "Links";

$idioma['direita'] = "Rechts";

$idioma['centralizado'] = "Zentriert";

$idioma['justificado'] = "Blocksatz";

$idioma['secao_pai'] = "Grossbuchstaben";

$idioma['topo'] = "Oben";

$idioma['imagem_secao'] = "Bild";

$idioma['nome']="Name";

$idioma['alinhamento']="Ausrichtung";

$idioma['exibir_conteudo']="Inhalt anzeigen";

$idioma['permissoes_grupos']="Gruppenberechtigung";

$idioma['todos_usuarios']="Alle Benutzer";

$idioma['todos']="Alle";

$idioma['visitantes']="Besucher";

$idioma['visitante']="Besucher";

$idioma['usuarios']="Benutzer";

$idioma['usuario']="Benutzer";

$idioma['administradores']="Administratoren";

$idioma['administrador']="Administrator";

$idioma['contatos_online']="Online Kontakte";

$idioma['nova_secao']="Neu";

$idioma['listar_secoes']="Liste";

$idioma['nenhuma_secao_encontrada'] = "Keine Suchergebnisse";

$idioma['selecione_secao'] = "Auswahl";



$idioma['erro'] = "Fehler";

$idioma['sem_erros'] = "Kein fehler gefunden";

$idioma['exibir_erros']="Fehler anzeigen";

$idioma['erro_desc'] = "Beim Ausfuehren des Skriptes ist ein Fehler aufgetreten. Bitte informieren Sie den <a href=mailto:webmaster@somedomain.com>Webmaster</a>.";

$idioma['erro_informacoes'] = "Die Ausgabe des Skriptes";

$idioma['erro_codigo'] = "Fehlercode";

$idioma['erro_mensagem'] = "Fehlermeldung";

$idioma['erro_linha'] = "Skriptname und Zeilennummer des Fehlers";

$idioma['erro_arquivo'] = "Datei";

$idioma['erro_linha'] = "Zeile";

$idioma['erro_variaveis'] = "Inhalt der Variable beim Auftreten des Fehlers";

$idioma['configurar_blocos'] = "Blockeinstellungen";

$idioma['pagina_criada'] = "Seite generiert in";

$idioma['segundos'] = "Sekunden";



$idioma['codigo_fonte']="Quellcode";



$idioma['abrir_todos'] = "Oeffne alle";

$idioma['fechar_todos'] = "Schliesse alle";

$idioma['selecionar_todos'] = "Alle auswaehlen";



$idioma['editar_ajuda_modulo']="Hilfe f�r dieses Modul bearbeiten";

$idioma['ajuda']="Hilfe";



$idioma['padrao']="Standard";

$idioma['vazio']="Leer";



$idioma['avancar']="Vorwaerts";

$idioma['voltar']="Zurueck";

$idioma['atualizar']="Erneut laden";



$idioma['pagina']="Seite";

$idioma['carregando']="Laden...";

$idioma['nenhum_item']="Keine Daten gefunden";

$idioma['sem_permissao']="Kein Zugriff auf das Modul.";

$idioma['erros_encontrados'] = "Os seguintes erros foram encontrados nas informa��es enviadas";

$idioma['erro_site']="Keine Seite gefunden. Bitte setzen Sie sich mit dem Systemadministrator in Verbindung oder pr�fen Sie die EVA Installation.";


$idioma['deseja']="M�chten Sie";

$idioma['o_bloco']="den Block";

$idioma['o_modulo']="das Modul";

$idioma['clique_arraste'] = "Verschieben Sie den Block mittels 'Drag and drop' ";



$idioma['sentido'] = "Richtung";

$idioma['vertical'] = "Vertikal";

$idioma['horizontal'] = "Horizontal";

$idioma['estilo_css'] = "Klasse (CSS)";



$idioma['alerta_caracteres'] = "Ihre Nachricht sollte nicht mehr als";

$idioma['caracteres'] = "Zeichen enthalten";

$idioma['caracteres_digitados'] = "Zeichen getippt";

$idioma['maximo'] = "Maximal";

$idioma['digite_msg'] = "Tippen Sie ihre Nachricht";

$idioma['digite_assunto'] = "Schreiben Sie einen Betreff";

$idioma['titulo'] = "Titel";

$idioma['nome'] = "Name";

$idioma['texto'] = "Text";

$idioma['mensagem'] = "Nachricht";

$idioma['assunto'] = "Betreff";



$idioma['deseja_prosseguir'] = "Moechten Sie wirklich fortfahren?\\nAlle Daten werden geloescht!";

$idioma['tem_certeza'] = "Moechten Sie wirklich fortfahren?";

$idioma['confirma_apagar'] = "Moechten Sie das ausgew�hlte Item loeschen?";

$idioma['confirma_fechar'] = "Moechten Sie das ausgew�hlte Item schliessen?";





// Calendar

$idioma['dia_domingo'] = "Sonntag";

$idioma['dia_segunda'] = "Montag";

$idioma['dia_terca'] = "Dienstag";

$idioma['dia_quarta'] = "Mittwoch";

$idioma['dia_quinta'] = "Donnerstag";

$idioma['dia_sexta'] = "Freitag";

$idioma['dia_sabado'] = "Samstag";

$idioma['dia_domingo'] = "Sonntag";



$idioma['dia_domingo_menor'] = "So";

$idioma['dia_segunda_menor'] = "Mo";

$idioma['dia_terca_menor'] = "Di";

$idioma['dia_quarta_menor'] = "Mi";

$idioma['dia_quinta_menor'] = "Do";

$idioma['dia_sexta_menor'] = "Fr";

$idioma['dia_sabado_menor'] = "Sa";

 

$idioma['mes_janeiro'] = "Januar";

$idioma['mes_fevereiro'] = "Februar";

$idioma['mes_marco'] = "Maerz";

$idioma['mes_abril'] = "April";

$idioma['mes_maio'] =  "Mai";

$idioma['mes_junho'] = "Juni";

$idioma['mes_julho'] = "Juli";

$idioma['mes_agosto'] = "August";

$idioma['mes_setembro'] = "September";

$idioma['mes_outubro'] = "Oktober";

$idioma['mes_novembro'] = "November";

$idioma['mes_dezembro'] = "Dezember";



$idioma['mes_janeiro_menor'] = "Jan";

$idioma['mes_fevereiro_menor'] = "Feb";

$idioma['mes_marco_menor'] = "Mar";

$idioma['mes_abril_menor'] = "Apr";

$idioma['mes_maio_menor'] = "Mai";

$idioma['mes_junho_menor'] = "Jun";

$idioma['mes_julho_menor'] = "Jul";

$idioma['mes_agosto_menor'] = "Aug";

$idioma['mes_setembro_menor'] = "Sep";

$idioma['mes_outubro_menor'] = "Okt";

$idioma['mes_novembro_menor'] = "Nov";

$idioma['mes_dezembro_menor'] = "Dez";



$idioma['info_calendario'] = "Kalenderinfo ";

$idioma['sobre_calendario'] = "DHTML Datums-/Zeitauswahl\\n 

(c) dynarch.com 2002-2005 / Author: Mihai Bazon\\n 

Neueste Vesion unter  http://www.dynarch.com/projects/calendar/\\n 

Erschienen unter GNU LGPL.  Weitere Informationen finden Sie unter http://gnu.org/licenses/lgpl.html . 

\\n\\n 

Datumsauswahl:\\n 

- Benutzen Sie die \xab, \xbb Tasten, um das Jahr auszuwaehlen\\n 

- Benutzen Sie die \" + String.fromCharCode(0x2039) + \", \" + String.fromCharCode(0x203a) + \" Tasten um den Monat auszuw�hlen\\n 

- Halten Sie den Mausbutton gedr�ckt, um die Auswahl zu beschleunigen.";



$idioma['sobre_hora'] = "\\n\\n 

Zeit einstellen:\\n 

- Klicken Sie auf eine Angabe um einen Wert zu erh�hen\\n 

- oder klicken Sie bei gedr�ckter Shift-Taste um zu erniedrigen\\n 

- oder w�hlen Sie mittels 'Drag and drop' schnell aus";



$idioma['ano_anterior'] = "Fr�heres Jahr (gedrueckt halten fuer das Menu)";

$idioma['mes_anterior'] = "Frueherer Monat (gedrueckt halten fuer das Menu)";

$idioma['data_atual'] = "Heute";

$idioma['proximo_mes'] = "Naechster Monat (gedrueckt halten fuer das Menu)";

$idioma['proximo_ano'] = "Next year (gedrueckt halten fuer das Menu)";

$idioma['selecione_data'] = "Datum auswaehlen";

$idioma['clique_para_mover'] = "Klicken zum Verschieben";

$idioma['dia_hoje'] = " (heute)";

$idioma['exibir_primeiro'] = "Zeige erste %s ";



// Inicio ne fim da semana -> 0 = domingo, 6 = sabado

$idioma['semana_inicio'] = "0,6";



$idioma['hoje'] =  "Heute";

$idioma['mudar_hora'] = "(Shift-)Klicken oder Ziehen um den Wert zu aendern";



// date formats

$idioma['formato_data_calendar'] = "%d.%m.%Y";
$idioma['formato_data_desc_calendar'] = "%a, %b %e";

if(file_exists($eva['caminho'].'/arquivos/config.php')){
	include_once($eva['caminho'].'/arquivos/config.php');
	$idioma['formato_data_e_seg_mktime'] = $config['formato_data'];
	$d = explode(" ", $config['formato_data']);
	$idioma['formato_data_mktime'] = $d[0];
}


$idioma['semana_menor'] = "Wo";

$idioma['hora'] = "Zeit:";



$idioma["mais"]="Mehr";

$idioma["menos"]="Weniger";



$idioma["enviar_email"]="Sende Email";

$idioma["enviar_mensagem"]="Sende Nachricht";

$idioma["editar_usuario"]="Benutzer bearbeiten";



$idioma['descricao']="Beschreibung";

$idioma['validar_campo']="Bitte Feld ueberpruefen: ";

$idioma['recarregar_imagem_validacao']="Validierungsbild neu laden";



$idioma['validacao_incorreta']="Bestaetigung fehlgeschlagen";



$idioma['grupos']="Gruppen";

$idioma['arquivo']="Datei";



$idioma['conectados'] = "Verbunden";

$idioma['desconectados'] = "Getrennt";



$idioma['avancado'] = "Fortgeschritten";



$idioma['eva_item'] = "bibli-de.php-zeile622";

$idioma['it_cod'] = "Item";

$idioma['it_pai']="Pai";

$idioma['it_se_cod']="Se��o";

$idioma['it_si_cod']="Seiten";

$idioma['it_nome']="Name";

$idioma['it_desc']="Beschreibung";

$idioma['it_autor']="Autor";

$idioma['it_data_criacao']="Datum";

$idioma['it_data_publicacao']="Datum der Veroeffentlichung";

$idioma['it_data_validade']="Datum der Pr�fung";

$idioma['it_data_modificacao']="Datum der Aenderung";

$idioma['it_us_cod_criacao']="Erstellt von";

$idioma['it_us_cod_modificacao']="Geaendert von";

$idioma['it_situacao']="Situa��o";

$idioma['it_contador']="Zugriff";

$idioma['it_grupo']="Gruppen";

$idioma['it_mo_cod']="Module";

$idioma['it_texto']="Text";





$idioma['selecionar_it_se_cod']="Sektion auswaehlen";

$idioma['selecionar_it_pai']="Oben";



$idioma['cadastre_secao']="Bitte eine Sektion angeben";



// Instalar modulos

$idioma['modulo_instalado'] = "Modul erfolgreich installiert!";

$idioma['erro_instalar_modulo'] = "Fehler bei der Modulinstallation.";

$idioma['erro_permissoes'] = "Fehler beim Setzen der Gruppenrechte.";

$idioma['erro_blocos'] = "Fehler beim Versuch die Blockberechtigungen anzuzeigen";

$idioma['erro_criar_tabelas'] = "Fehler beim Erstellen der Tabelle";





$idioma['erro_bd'] = "Fehler bei der Datenbankverbindung. Bitte �berpruefen Sie die Installation oder informieren Sie den Systemadministrator.";

$idioma['atualizado_sucesso'] = "Modul erfolgreich aktualisiert";
$idioma['global_on'] = "Entschuldigung, aber aus Sicherheitsgr�nden arbeitet EVA nicht mit der Option <strong>register_global = On</strong>; bitte setzen Sie <strong>register_global = Off</strong> in ihrer php.ini";

$idioma['base_dn'] = "Base DN";
$idioma['bind_dn'] = "Bind DN";
$idioma['senha_bind'] = "Bind Passwort";
$idioma['filtro'] = "filtern";
$idioma['atributo_senha'] = "Password attribute";

$idioma['formato_data']="Datumsformat";
$idioma['servidor'] = "Server";
$idioma['porta'] = "Port";
$idioma['modulo'] = "Module";
$idioma['grupo'] = "Group";
$idioma['exibe_titulo'] = "Show Title";
$idioma['selecionar_desmarcar_todos'] = "Select/Deselect all";

$idioma['adicionar_novo'] = "Add New";
$idioma['adicionar_novo_editar'] = "Add New/Edit";

$idioma['login_erro']="Invalid User and/or Pass. Please, try again";
$idioma['visitantes_e_usuarios']="Specific Guests and users";
$idioma['dias'] = "Days";
$idioma['dia'] = "Dia";

$idioma['minutos'] = 'Minutes';
$idioma['minuto'] = 'Minute';

$idioma['horas'] = 'Hours';
$idioma['hora'] = 'Hour';
?>
